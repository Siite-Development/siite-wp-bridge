<?php
/**
 * Plugin Name: Siite WP Bridge
 * Description: Read-and-edit access to Elementor page data for Siite's tooling.
 *              Authenticated with WordPress Application Passwords; every write
 *              is backed up first and can be restored from the same endpoint.
 * Version:     1.14.4
 * Author:      Siite
 * Update URI:  https://raw.githubusercontent.com/Siite-Development/siite-wp-bridge
 *
 * Install: upload the zip in wp-admin under Plugins > Add New > Upload, and
 * activate it. Updating is the same upload with "Replace current with
 * uploaded" — or nothing at all, once SIITE_BRIDGE_UPDATE_MANIFEST below
 * points at a manifest this site can reach.
 *
 * Remove: deactivate and delete. Nothing is left behind except the backup meta
 * rows, which are harmless and pruned to the last 5 per post, and the ledger
 * option recording what the bridge itself created.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

const SIITE_BRIDGE_VERSION  = '1.14.4';
const SIITE_BRIDGE_NS       = 'siite/v1';

/**
 * Login on hosts that drop the Authorization header before PHP.
 *
 * LiteSpeed and several CGI setups (measured on sandspedition.dk, 16 Sep 2026)
 * remove the header, so WordPress answers "rest_not_logged_in" to a correct
 * application password. The client sends the same credentials a second time as
 * X-Siite-Authorization, which those hosts pass through. It is copied into
 * PHP_AUTH_USER/PW only when no normal credentials arrived, so WordPress' own
 * application-password check runs unchanged: same password, same HTTPS rule,
 * same revocation. It grants nothing a Basic header would not.
 */
/*
 * 1.14.2: sandspedition.dk also dropped X-Siite-Authorization, so the same
 * value is accepted under a name without "authorization" in it and as a
 * cookie. Browsers never hold that cookie; only the CLI sends it.
 */
$siite_bridge_h = '';
foreach ( [ 'HTTP_X_SIITE_AUTHORIZATION', 'HTTP_X_SIITE_KEY' ] as $siite_bridge_k ) {
	if ( ! empty( $_SERVER[ $siite_bridge_k ] ) ) { $siite_bridge_h = (string) $_SERVER[ $siite_bridge_k ]; break; }
}
if ( $siite_bridge_h === '' && ! empty( $_COOKIE['siite_bridge_key'] ) ) {
	$siite_bridge_h = 'Basic ' . (string) $_COOKIE['siite_bridge_key'];
}
if ( empty( $_SERVER['PHP_AUTH_USER'] )
	&& empty( $_SERVER['HTTP_AUTHORIZATION'] )
	&& empty( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] )
	&& $siite_bridge_h !== '' ) {
	if ( stripos( $siite_bridge_h, 'basic ' ) === 0 ) {
		$siite_bridge_pair = base64_decode( substr( $siite_bridge_h, 6 ), true );
		if ( is_string( $siite_bridge_pair ) && strpos( $siite_bridge_pair, ':' ) !== false ) {
			list( $_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW'] ) = explode( ':', $siite_bridge_pair, 2 );
		}
	}
}
/* Which carriers reached PHP, as booleans only — read by /auth-check. */
$GLOBALS['siite_bridge_auth_seen'] = [
	'authorization'          => ! empty( $_SERVER['HTTP_AUTHORIZATION'] ) || ! empty( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ),
	'x_siite_authorization'  => ! empty( $_SERVER['HTTP_X_SIITE_AUTHORIZATION'] ),
	'x_siite_key'            => ! empty( $_SERVER['HTTP_X_SIITE_KEY'] ),
	'cookie'                 => ! empty( $_COOKIE['siite_bridge_key'] ),
	'php_auth_user'          => ! empty( $_SERVER['PHP_AUTH_USER'] ),
];
unset( $siite_bridge_h, $siite_bridge_pair, $siite_bridge_k );

/**
 * Finish the login inside the REST request (1.14.3).
 *
 * Measured on sandspedition.dk: the credentials reached PHP_AUTH_USER, yet
 * WordPress answered rest_not_logged_in with no password error at all, so its
 * application-password check never ran — something on the site had settled the
 * current user as anonymous before the request was known to be a REST call.
 * If that happened, run WordPress' own check here, where REST_REQUEST is set.
 * A wrong or revoked password returns WordPress' own error code, so the client
 * sees "incorrect_password" instead of a silent 401. Nothing is granted that
 * wp_authenticate_application_password() would not grant.
 */
add_filter( 'rest_authentication_errors', function ( $result ) {
	if ( ! empty( $result ) || is_user_logged_in() ) { return $result; }
	if ( empty( $_SERVER['PHP_AUTH_USER'] ) || ! isset( $_SERVER['PHP_AUTH_PW'] ) ) { return $result; }
	if ( ! function_exists( 'wp_authenticate_application_password' ) ) { return $result; }
	$user = wp_authenticate_application_password( null, (string) $_SERVER['PHP_AUTH_USER'], (string) $_SERVER['PHP_AUTH_PW'] );
	if ( $user instanceof WP_User ) {
		wp_set_current_user( $user->ID );
		$GLOBALS['siite_bridge_auth_seen']['late_login'] = true;
		return $result;
	}
	if ( is_wp_error( $user ) ) {
		$GLOBALS['siite_bridge_auth_seen']['late_error'] = $user->get_error_code();
		return new WP_Error( $user->get_error_code(), $user->get_error_message(), [ 'status' => 401 ] );
	}
	$GLOBALS['siite_bridge_auth_seen']['late_error'] = 'no_result';
	return $result;
}, 90 );
const SIITE_BRIDGE_BAK_KEY  = '_siite_bak_';
const SIITE_BRIDGE_BAK_KEEP = 5;

/**
 * Where this plugin looks for a newer version of itself.
 *
 * Empty means the feature is off and the bridge is updated by re-uploading the
 * zip, which is where it starts: the URL has to be set up by a person, and
 * nothing here creates it.
 *
 * It is a CONSTANT in this file, not an option and not something any route can
 * write. An update URL that could be repointed by whoever holds the
 * application password would turn a leaked password into arbitrary code on the
 * client's server; baked in, the trust anchor is the file somebody installed
 * plus TLS to a host we own.
 *
 * The manifest is one JSON object:
 *
 *     { "version": "1.9.0",
 *       "package": "https://raw.githubusercontent.com/Siite-Development/siite-wp-bridge/main/siite-wp-bridge.zip",
 *       "requires": "6.0", "requires_php": "7.4",
 *       "tested": "7.1",
 *       "url": "https://github.com/Siite-Development/siite-wp-bridge" }
 *
 * Why a public repo rather than a host of our own: the plugin code is not
 * secret, raw.githubusercontent.com is already trusted TLS with no server to
 * keep alive, and nothing about this accepts code over the API — WordPress
 * pulls it through its own updater, which is the part that has been reviewed
 * by more people than we ever will. A route that took a zip over the bridge
 * would be remote code execution by design, reachable with the application
 * password.
 */
const SIITE_BRIDGE_UPDATE_MANIFEST =
	'https://raw.githubusercontent.com/Siite-Development/siite-wp-bridge/main/manifest.json';
const SIITE_BRIDGE_UPDATE_HOST     = 'raw.githubusercontent.com';

/** Only these meta keys may ever be written. */
function siite_bridge_writable_meta() {
	return [ '_elementor_data', '_elementor_page_settings' ];
}

/**
 * Caller must be able to edit this specific post.
 *
 * A post that does not exist is answered as 404 rather than 403. WordPress's
 * own map_meta_cap() returns "no" for edit_post on a missing id, so the plain
 * capability check would tell the caller they lack permission — sending
 * whoever reads that message off to look at roles and application passwords
 * for a post id that was simply wrong.
 */
function siite_bridge_can_edit( $req ) {
	$id = (int) $req['id'];
	if ( ! $id || ! get_post( $id ) ) {
		return new WP_Error( 'siite_no_post', "Post $id does not exist", [ 'status' => 404 ] );
	}
	return current_user_can( 'edit_post', $id ) ? true : siite_bridge_forbidden( get_post( $id ) );
}

function siite_bridge_can_read() {
	return current_user_can( 'edit_posts' );
}

/** Creating a page, and putting it in a menu, are their own capabilities. */
function siite_bridge_can_create() {
	return current_user_can( 'publish_pages' );
}

function siite_bridge_can_menu() {
	// The custom capability first, and edit_theme_options only as the fallback.
	// edit_theme_options is an Administrator-only capability in WordPress, so
	// requiring it was the single reason this bridge's account had to be an
	// admin — which handed the application password in wp_sites.json the whole
	// REST API. The role below carries siite_bridge_menus instead, so a menu
	// can be written by an account that cannot install a plugin, edit a user,
	// or delete a page. An existing admin account keeps working.
	return current_user_can( 'siite_bridge_menus' )
		|| current_user_can( 'edit_theme_options' );
}

/* ------------------------------------------------------------------ role --- */

const SIITE_BRIDGE_ROLE     = 'siite_bridge';
const SIITE_BRIDGE_ROLE_VER = 3;

/**
 * The account this bridge is meant to run as: an Editor, minus everything that
 * deletes, minus unfiltered_html, plus the one capability the menu route needs.
 *
 * Derived from the site's own Editor role rather than from a hardcoded list, so
 * a plugin that grants Editors access to its post type (Elementor's template
 * library being the one that matters here) grants it to this role too.
 *
 * Deliberately absent: delete_* of every kind, manage_options, install_plugins,
 * edit_themes, edit_users, upload_files, unfiltered_html. Nothing this bridge
 * does needs them, and the credential sits in a file on a laptop.
 */
function siite_bridge_role_caps() {
	$editor = get_role( 'editor' );
	$caps   = $editor ? (array) $editor->capabilities : [ 'read' => true, 'edit_posts' => true ];

	foreach ( array_keys( $caps ) as $cap ) {
		if ( strpos( $cap, 'delete_' ) === 0 ) { unset( $caps[ $cap ] ); }
	}
	unset( $caps['unfiltered_html'], $caps['upload_files'], $caps['moderate_comments'] );

	$caps['read']               = true;
	$caps['siite_bridge_menus'] = true;
	// 1.13.0: the kit, Additional CSS and Settings > Reading. See siite_bridge_can_design().
	$caps['siite_bridge_design'] = true;
	return $caps;
}

/**
 * Create or refresh the role. Runs on every load but only writes when the
 * version moves, because add_role/remove_role write to the options table and
 * this file has no activation hook to hang off (it is installed as an
 * mu-plugin on some sites).
 */
add_action( 'init', function () {
	if ( (int) get_option( 'siite_bridge_role_ver' ) === SIITE_BRIDGE_ROLE_VER ) { return; }
	remove_role( SIITE_BRIDGE_ROLE );
	add_role( SIITE_BRIDGE_ROLE, 'Siite Bridge', siite_bridge_role_caps() );
	update_option( 'siite_bridge_role_ver', SIITE_BRIDGE_ROLE_VER, false );
}, 20 );

/* --------------------------------------------------- updating itself --- */

/**
 * Tell WordPress where a newer version of this plugin lives.
 *
 * WordPress fires update_plugins_<host> for the host in the plugin's own
 * "Update URI" header, and takes the array we return as the update offer. That
 * means the whole normal machinery — the notice in wp-admin, auto-updates if
 * the site has them on, WP_Upgrader doing the install — works without this
 * plugin implementing any of it.
 *
 * Why it matters: without it, "the site is running an old bridge" is a person
 * remembering to re-upload a zip on every client site, one at a time. That is
 * the step that gets skipped, and the version check then switches features off
 * on a site nobody has looked at in a month.
 *
 * The manifest is fetched at most once an hour and every failure is silent by
 * design: a plugin that makes wp-admin slow, or noisy, because our own host is
 * down is worse than a plugin that is one version behind.
 */
add_filter( 'update_plugins_' . SIITE_BRIDGE_UPDATE_HOST, function ( $update, $plugin_data, $plugin_file, $locales ) {
	if ( SIITE_BRIDGE_UPDATE_MANIFEST === '' ) { return $update; }
	if ( strpos( $plugin_file, 'siite-wp-bridge' ) === false ) { return $update; }

	$cached = get_site_transient( 'siite_bridge_update' );
	if ( is_array( $cached ) ) {
		$manifest = $cached;
	} else {
		$res = wp_remote_get( SIITE_BRIDGE_UPDATE_MANIFEST, [
			'timeout' => 8,
			'headers' => [ 'Accept' => 'application/json' ],
		] );
		if ( is_wp_error( $res ) || (int) wp_remote_retrieve_response_code( $res ) !== 200 ) {
			// Short cache on failure too, so a host that is down is asked once
			// an hour rather than on every admin page load.
			set_site_transient( 'siite_bridge_update', [ 'version' => '0' ], HOUR_IN_SECONDS );
			return $update;
		}
		$manifest = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $manifest ) ) { return $update; }
		set_site_transient( 'siite_bridge_update', $manifest, HOUR_IN_SECONDS );
	}

	$new = (string) ( $manifest['version'] ?? '0' );
	if ( version_compare( $new, SIITE_BRIDGE_VERSION, '<=' ) ) { return $update; }

	// The package must come from the same host as the manifest. A manifest that
	// could point the installer at any URL would make one compromised JSON file
	// into code execution on every client site at once.
	$package = (string) ( $manifest['package'] ?? '' );
	$host    = strtolower( (string) wp_parse_url( $package, PHP_URL_HOST ) );
	$scheme  = strtolower( (string) wp_parse_url( $package, PHP_URL_SCHEME ) );
	if ( $scheme !== 'https' || $host !== SIITE_BRIDGE_UPDATE_HOST ) { return $update; }

	return [
		'id'           => SIITE_BRIDGE_UPDATE_HOST . '/wp-bridge',
		'slug'         => 'siite-wp-bridge',
		'plugin'       => $plugin_file,
		'version'      => $new,
		'url'          => (string) ( $manifest['url'] ?? '' ),
		'package'      => $package,
		'requires'     => (string) ( $manifest['requires'] ?? '' ),
		'requires_php' => (string) ( $manifest['requires_php'] ?? '' ),
		'tested'       => (string) ( $manifest['tested'] ?? '' ),
	];
}, 10, 4 );


add_action( 'rest_api_init', function () {
	$ns = SIITE_BRIDGE_NS;

	/*
	 * Public, no login: says which login carriers arrived (true/false, never a
	 * value), the bridge version, and whether WordPress allows application
	 * passwords here. The answer to "401 with a correct password".
	 */
	register_rest_route( $ns, '/auth-check', [
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function () {
			return [
				'bridge'                => SIITE_BRIDGE_VERSION,
				'seen'                  => $GLOBALS['siite_bridge_auth_seen'] ?? null,
				'logged_in'             => is_user_logged_in(),
				'is_ssl'                => is_ssl(),
				'app_passwords'         => function_exists( 'wp_is_application_passwords_available' ) ? wp_is_application_passwords_available() : null,
			];
		},
	] );

	register_rest_route( $ns, '/ping', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_ping',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/report', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_report',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/inventory', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_inventory',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/kit', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_kit',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/vocabulary', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_vocabulary',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/upload', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_upload',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/media', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_media',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/search', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_search',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/replace/(?P<id>\d+)', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_replace',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/doc/(?P<id>\d+)', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_doc_get',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/doc/(?P<id>\d+)', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_doc_edit',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/insert/(?P<id>\d+)', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_insert',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/duplicate/(?P<id>\d+)', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_duplicate',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/move/(?P<id>\d+)', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_move',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/remove/(?P<id>\d+)', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_remove',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/ledger', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_ledger_get',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/documents/(?P<id>\d+)', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_documents',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/images/(?P<id>\d+)', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_images',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/render/(?P<id>\d+)', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_render',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/element/(?P<id>\d+)/(?P<element>[A-Za-z0-9_-]+)', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_element',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/backups/(?P<id>\d+)', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_backups',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/menus', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_menus',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/menu', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_menu_add',
		'permission_callback' => 'siite_bridge_can_menu',
	] );

	register_rest_route( $ns, '/repeater/(?P<id>\d+)', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_repeater',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/menu-move', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_menu_move',
		'permission_callback' => 'siite_bridge_can_menu',
	] );

	register_rest_route( $ns, '/menu-move-undo', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_menu_move_undo',
		'permission_callback' => 'siite_bridge_can_menu',
	] );

	register_rest_route( $ns, '/menu-restore', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_menu_restore',
		'permission_callback' => 'siite_bridge_can_menu',
	] );

	register_rest_route( $ns, '/page', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_page_create',
		'permission_callback' => 'siite_bridge_can_create',
	] );

	register_rest_route( $ns, '/post/(?P<id>\d+)', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_post_update',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/publish/(?P<id>\d+)', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_page_publish',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	register_rest_route( $ns, '/restore/(?P<id>\d+)', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_restore',
		'permission_callback' => 'siite_bridge_can_edit',
	] );

	/* 1.13.0 */
	register_rest_route( $ns, '/pages', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_pages',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/publish', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_publish_many',
		'permission_callback' => 'siite_bridge_can_create',
	] );

	register_rest_route( $ns, '/trash/(?P<id>\d+)', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_trash',
		'permission_callback' => 'siite_bridge_can_create',
	] );

	register_rest_route( $ns, '/templates', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_templates',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/template', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_template_save',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/kit', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_kit_update',
		'permission_callback' => 'siite_bridge_can_design',
	] );

	register_rest_route( $ns, '/kit-restore', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_kit_restore',
		'permission_callback' => 'siite_bridge_can_design',
	] );

	register_rest_route( $ns, '/options', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_options_get',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/options', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_options_set',
		'permission_callback' => 'siite_bridge_can_design',
	] );

	register_rest_route( $ns, '/css', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_css_get',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/css', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_css_set',
		'permission_callback' => 'siite_bridge_can_design',
	] );

	register_rest_route( $ns, '/flush', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_flush_route',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	register_rest_route( $ns, '/upload-chunk', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_upload_chunk',
		'permission_callback' => 'siite_bridge_can_read',
	] );

	// 1.14.0
	register_rest_route( $ns, '/export', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_export',
		'permission_callback' => 'siite_bridge_can_read',
	] );
	register_rest_route( $ns, '/status/(?P<id>\d+)', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_status_set',
		'permission_callback' => 'siite_bridge_can_edit',
	] );
	register_rest_route( $ns, '/seo/(?P<id>\d+)', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_seo_get',
		'permission_callback' => 'siite_bridge_can_edit',
	] );
	register_rest_route( $ns, '/seo/(?P<id>\d+)', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_seo_set',
		'permission_callback' => 'siite_bridge_can_edit',
	] );
	register_rest_route( $ns, '/redirects', [
		'methods'             => 'GET',
		'callback'            => 'siite_bridge_redirects_get',
		'permission_callback' => 'siite_bridge_can_read',
	] );
	register_rest_route( $ns, '/redirects', [
		'methods'             => 'POST',
		'callback'            => 'siite_bridge_redirects_set',
		'permission_callback' => 'siite_bridge_can_design',
	] );
} );

/* ---------------------------------------------------------------- reading */

function siite_bridge_ping() {
	global $wp_version;

	if ( ! function_exists( 'is_plugin_active' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	$plugins = [];
	foreach ( [ 'elementor/elementor.php', 'elementor-pro/elementor-pro.php',
	            'uicore-framework/uicore-framework.php', 'uicore-elements/uicore-elements.php',
	            'uicore-elements-pro/uicore-elements-pro.php' ] as $p ) {
		if ( is_plugin_active( $p ) ) { $plugins[] = $p; }
	}

	$theme = wp_get_theme();

	return [
		'bridge'        => SIITE_BRIDGE_VERSION,
		'wp'            => $wp_version,
		'php'           => PHP_VERSION,
		'site_url'      => home_url(),
		'theme'         => $theme->get( 'Name' ) . ' ' . $theme->get( 'Version' ),
		'parent_theme'  => $theme->parent() ? $theme->parent()->get( 'Name' ) : null,
		'elementor'     => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : null,
		'elementor_pro' => defined( 'ELEMENTOR_PRO_VERSION' ) ? ELEMENTOR_PRO_VERSION : null,
		'plugins_seen'  => $plugins,
		'caches_seen'   => siite_bridge_caches_available(),
		'compat'        => siite_bridge_compat(),
		'user'          => wp_get_current_user()->user_login,
		'account'       => siite_bridge_account(),
	];
}


/**
 * Everything this plugin depends on, checked one by one. If a WordPress or
 * Elementor release ever moves one of these, it shows up here as a named
 * failure the moment anyone runs a ping, instead of as a surprise mid-edit.
 */
function siite_bridge_compat() {
	$out = [];
	$out['wp_rest']        = function_exists( 'register_rest_route' );
	$out['wp_slash']       = function_exists( 'wp_slash' );
	$out['post_meta']      = function_exists( 'update_post_meta' ) && function_exists( 'add_post_meta' );
	$out['app_passwords']  = class_exists( 'WP_Application_Passwords' );
	// 1.3.0's own dependencies, checked the same way: a WordPress release that
	// moves one of these should surface on the next ping rather than halfway
	// through creating a page on a client's site.
	$out['insert_post']    = function_exists( 'wp_insert_post' ) && function_exists( 'wp_update_post' );
	$out['page_by_path']   = function_exists( 'get_page_by_path' );
	$out['nav_menu_write'] = function_exists( 'wp_update_nav_menu_item' )
		&& function_exists( 'wp_get_nav_menu_items' ) && function_exists( 'wp_get_nav_menus' );
	// Every registered type by name, not 'any'. WP_Query's 'any' silently drops
	// each post type registered with exclude_from_search, and elementor_library
	// is one — so a site whose Elementor documents are all theme-builder
	// templates would be reported as having no Elementor data at all.
	$out['elementor_data'] = (bool) get_posts( [
		'post_type'   => array_values( get_post_types( [], 'names' ) ),
		'numberposts' => 1,
		'fields'      => 'ids',
		'meta_key'    => '_elementor_data',
	] );
	$out['elementor_flush'] = class_exists( '\Elementor\Plugin' )
		&& isset( \Elementor\Plugin::$instance->files_manager )
		&& method_exists( \Elementor\Plugin::$instance->files_manager, 'clear_cache' );
	return $out;
}

/* ------------------------------------------------------------- report --- */

/**
 * Which generation of Elementor a tree is built from.
 *
 * This is not trivia. It decides what a new section has to look like: a
 * section/column site cannot carry a flexbox container, and neither can carry
 * a v4 atomic element. Elementor 4.x registers all three side by side
 * (includes/elements/ plus modules/atomic-widgets/), so one site — one
 * document, even — can hold a mix, and building in the wrong one produces a
 * section that renders as an empty band.
 */
function siite_bridge_format( $nodes, &$seen = null ) {
	if ( $seen === null ) { $seen = []; }
	foreach ( (array) $nodes as $n ) {
		$el  = (string) ( $n['elType'] ?? '' );
		$wid = (string) ( $n['widgetType'] ?? '' );
		if ( $el === 'section' || $el === 'column' ) {
			$seen['section'] = true;
		} elseif ( $el === 'container' ) {
			$seen['container'] = true;
		} elseif ( strpos( $el, 'e-' ) === 0 || strpos( $wid, 'e-' ) === 0 ) {
			$seen['atomic'] = true;
		}
		if ( ! empty( $n['elements'] ) ) { siite_bridge_format( $n['elements'], $seen ); }
	}
	$kinds = array_keys( array_filter( $seen ) );
	if ( ! $kinds )            { return 'empty'; }
	if ( count( $kinds ) > 1 ) { return 'mixed'; }
	return $kinds[0];
}


/** Elementor's own feature flags, each one guarded. */
function siite_bridge_experiments() {
	$out = [];
	try {
		if ( ! class_exists( '\Elementor\Plugin' )
			|| ! isset( \Elementor\Plugin::$instance->experiments ) ) {
			return $out;
		}
		$ex = \Elementor\Plugin::$instance->experiments;
		if ( ! method_exists( $ex, 'is_feature_active' ) ) { return $out; }
		foreach ( [ 'container', 'nested-elements', 'e_atomic_elements',
		            'editor_v2', 'e_optimized_markup', 'e_font_icon_svg' ] as $flag ) {
			$out[ $flag ] = (bool) $ex->is_feature_active( $flag );
		}
	} catch ( \Throwable $e ) {
		$out['_error'] = substr( $e->getMessage(), 0, 120 );
	}
	return $out;
}


/**
 * Every active plugin, by file and name.
 *
 * The full list rather than a handful we recognise. On a real client site the
 * plugin that breaks a write is never the one anybody thought to look for — a
 * security plugin that blocks REST, a second page builder, a translation layer
 * that stores a parallel copy of the tree. A name we do not know is still a
 * name somebody can read.
 */
function siite_bridge_plugins() {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$all  = function_exists( 'get_plugins' ) ? get_plugins() : [];
	$out  = [];
	foreach ( (array) get_option( 'active_plugins', [] ) as $file ) {
		$out[] = [
			'file'    => $file,
			'name'    => $all[ $file ]['Name'] ?? $file,
			'version' => $all[ $file ]['Version'] ?? null,
		];
	}
	if ( is_multisite() && function_exists( 'get_site_option' ) ) {
		foreach ( array_keys( (array) get_site_option( 'active_sitewide_plugins', [] ) ) as $file ) {
			$out[] = [
				'file'    => $file,
				'name'    => ( $all[ $file ]['Name'] ?? $file ) . ' (netværk)',
				'version' => $all[ $file ]['Version'] ?? null,
			];
		}
	}
	return $out;
}


/**
 * What the site is actually built from, counted.
 *
 * One pass over every Elementor document. It is the difference between "this
 * is a WordPress site" and knowing that 16 of its widgets are hand-written
 * html blocks, that four of its headings are fed by dynamic tags, and that the
 * words on the front page live in three other posts.
 */
function siite_bridge_census() {
	$docs = siite_bridge_inventory();
	$out  = [
		'documents'   => count( $docs ),
		'by_type'     => [],
		'by_format'   => [],
		'by_status'   => [],
		'widgets'     => 0,
		'widget_types'=> [],
		'code_widgets'=> 0,
		'elsewhere'   => 0,
		'dynamic'     => 0,
	];
	foreach ( $docs as $d ) {
		$out['by_type'][ $d['type'] ]     = ( $out['by_type'][ $d['type'] ] ?? 0 ) + 1;
		$out['by_status'][ $d['status'] ] = ( $out['by_status'][ $d['status'] ] ?? 0 ) + 1;

		$tree   = siite_bridge_tree( $d['id'] );
		$format = siite_bridge_format( $tree );
		$out['by_format'][ $format ] = ( $out['by_format'][ $format ] ?? 0 ) + 1;

		foreach ( siite_bridge_flatten( $tree ) as $w ) {
			$out['widgets']++;
			$type = $w['widget'] ?: '(uden type)';
			$out['widget_types'][ $type ] = ( $out['widget_types'][ $type ] ?? 0 ) + 1;
			if ( in_array( $type, [ 'html', 'shortcode' ], true ) ) { $out['code_widgets']++; }
			if ( ! empty( $w['elsewhere'] ) ) { $out['elsewhere']++; }
			if ( ! empty( $w['dynamic'] ) )   { $out['dynamic'] += count( $w['dynamic'] ); }
		}
	}
	arsort( $out['widget_types'] );
	arsort( $out['by_format'] );
	return $out;
}


/**
 * The whole site, in one call, with a verdict on each thing that decides what
 * this track may attempt here.
 *
 * A verdict is one of ok / warn / stop and carries the reason in plain Danish,
 * because the person reading it in the app is deciding whether to let an agent
 * write on a client's live site — not debugging WordPress.
 */
function siite_bridge_report() {
	global $wp_version, $wpdb;

	$theme     = wp_get_theme();
	$compat    = siite_bridge_compat();
	$account   = siite_bridge_account();
	$plugins   = siite_bridge_plugins();
	$census    = siite_bridge_census();
	$exp       = siite_bridge_experiments();
	$home      = home_url();
	$site      = site_url();

	$report = [
		'bridge'    => SIITE_BRIDGE_VERSION,
		'generated' => gmdate( 'c' ),
		'wordpress' => [
			'version'    => $wp_version,
			'php'        => PHP_VERSION,
			'db'         => method_exists( $wpdb, 'db_version' ) ? $wpdb->db_version() : null,
			'multisite'  => is_multisite(),
			'home_url'   => $home,
			'site_url'   => $site,
			'https'      => strpos( (string) $home, 'https://' ) === 0,
			'permalinks' => get_option( 'permalink_structure' ) ?: 'plain',
			'locale'     => get_locale(),
			'timezone'   => wp_timezone_string(),
		],
		'elementor' => [
			'version'     => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : null,
			'pro'         => defined( 'ELEMENTOR_PRO_VERSION' ) ? ELEMENTOR_PRO_VERSION : null,
			'license_key' => (bool) get_option( 'elementor_pro_license_key' ),
			'experiments' => $exp,
			'cpt_support' => (array) get_option( 'elementor_cpt_support', [] ),
		],
		'theme' => [
			'name'    => $theme->get( 'Name' ),
			'version' => $theme->get( 'Version' ),
			'parent'  => $theme->parent() ? $theme->parent()->get( 'Name' ) . ' ' . $theme->parent()->get( 'Version' ) : null,
			'child'   => (bool) $theme->parent(),
		],
		'plugins'  => $plugins,
		'caches'   => siite_bridge_caches_available(),
		'updates'  => [
			'manifest' => SIITE_BRIDGE_UPDATE_MANIFEST ?: null,
			'auto'     => SIITE_BRIDGE_UPDATE_MANIFEST !== '',
		],
		'account'  => $account,
		'compat'   => $compat,
		'census'   => $census,
	];

	/* ------------------------------------------------------ verdicts --- */

	$v = [];
	$say = function ( $key, $level, $text ) use ( &$v ) {
		$v[] = [ 'key' => $key, 'level' => $level, 'text' => $text ];
	};

	foreach ( $compat as $key => $ok ) {
		if ( $ok ) { continue; }
		$says = [
			'wp_rest'         => 'WordPress\' REST API svarer ikke som forventet.',
			'wp_slash'        => 'wp_slash mangler — danske tegn ville blive ødelagt.',
			'post_meta'       => 'post meta-funktionerne mangler.',
			'app_passwords'   => 'Application Passwords er slået fra på dette WordPress.',
			'insert_post'     => 'wp_insert_post mangler — der kan ikke oprettes sider.',
			'page_by_path'    => 'get_page_by_path mangler — en optaget slug kan ikke opdages.',
			'nav_menu_write'  => 'menufunktionerne mangler — der kan ikke skrives i menuen.',
			'elementor_data'  => 'Der findes ingen Elementor-dokumenter på sitet.',
			'elementor_flush' => 'Elementors cache-API er flyttet; cachen ryddes ikke automatisk.',
		];
		$say( 'compat.' . $key,
		      in_array( $key, [ 'elementor_flush', 'page_by_path' ], true ) ? 'warn' : 'stop',
		      $says[ $key ] ?? "$key fejler." );
	}

	if ( ! $report['wordpress']['https'] ) {
		// A sandbox on the machine doing the writing is the one case where http
		// costs nothing: the request never leaves the loopback interface. Every
		// other http site is sending an application password in clear text.
		$host  = strtolower( (string) wp_parse_url( $home, PHP_URL_HOST ) );
		$local = in_array( $host, [ '127.0.0.1', 'localhost', '::1' ], true );
		$say( 'https', $local ? 'ok' : 'stop',
			$local
				? 'Sitet kører på http, men på loopback — det forlader ikke maskinen.'
				: 'Sitet kører på http. Adgangskoden sendes i klartekst ved hver rettelse.' );
	}
	if ( $report['wordpress']['permalinks'] === 'plain' ) {
		$say( 'permalinks', 'warn',
			'Permalinks står på "plain", så sidernes adresser er ?page_id=… — '
			. 'et link fra kunden vil ikke kunne slås op på sin sti.' );
	}
	if ( ! $report['elementor']['version'] ) {
		$say( 'elementor', 'stop', 'Elementor er ikke aktivt på sitet.' );
	} elseif ( ! $report['elementor']['pro'] ) {
		$say( 'elementor_pro', 'warn',
			'Elementor Pro er ikke aktivt. Global-widgets, theme builder og '
			. 'Pro-widgets findes ikke her — det er normalt på en sandkasse og '
			. 'usædvanligt på et kundesite.' );
	}

	// The capability that decides whether a hand-written block survives a
	// write. Stated on every report rather than discovered the day a block
	// comes back with its <script> stripped.
	$unfiltered = in_array( 'unfiltered_html', (array) ( $account['can'] ?? [] ), true );
	$say( 'code_writes', 'ok',
		$unfiltered
			? 'Kontoen har unfiltered_html, så kode i html-widgets skrives som den er.'
			: 'Kontoen har ikke unfiltered_html — bevidst. Broen suspenderer selv '
			. 'Elementors saneringsfilter omkring sin egen skrivning, så kode i '
			. 'html-widgets bevares, mens en stjålet adgangskode stadig ikke kan '
			. 'indsætte script gennem wp/v2.' );

	if ( SIITE_BRIDGE_UPDATE_MANIFEST === '' ) {
		$say( 'updates', 'warn',
			'Broen opdaterer ikke sig selv på dette site. En ny version skal '
			. 'uploades i hånden: Plugins > Tilføj nyt > Upload > Erstat '
			. 'nuværende med uploadet.' );
	}

	if ( ! empty( $account ) && empty( $account['dedicated'] ) ) {
		$roles = implode( ', ', (array) ( $account['roles'] ?? [] ) ) ?: 'ingen rolle';
		$say( 'account', 'warn',
			"Broen kører som '{$account['login']}' ({$roles}), ikke som en dedikeret "
			. 'Siite Bridge-bruger.' );
	}
	$risky = array_intersect( (array) ( $account['can'] ?? [] ),
		[ 'manage_options', 'install_plugins', 'edit_users', 'edit_themes',
		  'delete_pages', 'delete_posts' ] );
	if ( $risky ) {
		$say( 'account_caps', 'warn',
			'Kontoen kan også ' . implode( ', ', $risky ) . '. Adgangskoden rækker '
			. 'dermed længere end det broen bruger.' );
	}

	$formats = array_keys( $census['by_format'] );
	$formats = array_values( array_diff( $formats, [ 'empty' ] ) );
	if ( count( $formats ) > 1 ) {
		$last = array_pop( $formats );
		$list = $formats ? implode( ', ', $formats ) . ' og ' . $last : $last;
		$formats[] = $last;
		$say( 'format', 'warn',
			'Sitet blander ' . $list . '. En ny sektion skal '
			. 'bygges i samme format som det dokument den lægges i, ikke i sitets '
			. '"typiske" format.' );
	} elseif ( $formats ) {
		$say( 'format', 'ok', 'Alle dokumenter er bygget som ' . $formats[0] . '.' );
	}

	if ( $census['elsewhere'] ) {
		$say( 'elsewhere', 'warn',
			$census['elsewhere'] . ' widgets henter deres indhold fra et andet '
			. 'indlæg. En rettelse på den side hvor ordene ses ville ikke ændre noget.' );
	}
	if ( $census['dynamic'] ) {
		$say( 'dynamic', 'warn',
			$census['dynamic'] . ' værdier styres af en dynamisk tag og kan ikke rettes her.' );
	}
	if ( $census['code_widgets'] ) {
		$say( 'code', 'ok',
			$census['code_widgets'] . ' html/shortcode-widgets på sitet. De vises i '
			. 'fuld længde og kan skrives om som hele blokke.' );
	}
	if ( $report['caches'] ) {
		$say( 'caches', 'ok',
			'Cache set: ' . implode( ', ', $report['caches'] ) . '. De ryddes efter hver skrivning.' );
	}

	// Can this account actually write to what is on the site? Asked per document
	// type rather than assumed from the role: the role is derived from the
	// site's own Editor, and a theme or plugin that maps its post type's
	// capabilities differently — Elementor Pro's template library being the one
	// that matters — can leave the account able to read a header template and
	// not to save it. Better to know at setup than at the first correction.
	$writable = [];
	foreach ( siite_bridge_inventory() as $doc ) {
		$type = $doc['type'];
		if ( ! isset( $writable[ $type ] ) ) {
			$writable[ $type ] = [ 'total' => 0, 'editable' => 0, 'blocked' => [] ];
		}
		$writable[ $type ]['total']++;
		if ( current_user_can( 'edit_post', $doc['id'] ) ) {
			$writable[ $type ]['editable']++;
		} elseif ( count( $writable[ $type ]['blocked'] ) < 3 ) {
			$writable[ $type ]['blocked'][] = $doc['id'];
		}
	}
	$report['writable'] = $writable;
	foreach ( $writable as $type => $row ) {
		if ( $row['editable'] === $row['total'] ) { continue; }
		$say( 'writable.' . $type, $row['editable'] ? 'warn' : 'stop',
			sprintf( 'Kontoen kan kun rette %d af %d dokumenter af typen %s%s. '
				. 'Rollen er afledt af sitets egen Editor, og et tema eller '
				. 'plugin kan mappe sin posttype anderledes.',
				$row['editable'], $row['total'], $type,
				$row['blocked'] ? ' (fx ' . implode( ', ', $row['blocked'] ) . ')' : '' ) );
	}

	$report['verdicts'] = $v;
	$report['ok'] = ! array_filter( $v, function ( $x ) { return $x['level'] === 'stop'; } );
	return $report;
}


/** Every post of any type that actually carries Elementor data. */
function siite_bridge_inventory() {
	global $wpdb;

	$rows = $wpdb->get_results(
		"SELECT p.ID, p.post_type, p.post_title, p.post_name, p.post_status
		   FROM {$wpdb->postmeta} m
		   JOIN {$wpdb->posts} p ON p.ID = m.post_id
		  WHERE m.meta_key = '_elementor_data'
		    AND p.post_status IN ('publish','draft','private','pending')
		  ORDER BY p.post_type, p.post_title"
	);

	$out = [];
	foreach ( $rows as $r ) {
		$out[] = [
			'id'      => (int) $r->ID,
			'type'    => $r->post_type,
			'status'  => $r->post_status,
			'title'   => $r->post_title,
			'slug'    => $r->post_name,
			'url'     => get_permalink( $r->ID ),
			'widgets' => count( siite_bridge_flatten( siite_bridge_tree( $r->ID ) ) ),
		];
	}
	return $out;
}

function siite_bridge_tree( $id ) {
	$raw = get_post_meta( $id, '_elementor_data', true );
	if ( is_array( $raw ) ) { return $raw; }
	$tree = json_decode( (string) $raw, true );
	return is_array( $tree ) ? $tree : [];
}

/** Flat list of every widget, with a short human-readable preview. */

/**
 * Every string in a widget's settings that is actually content, keyed by the
 * dot-path used to edit it. Repeater rows come out as "icon_list.0.text".
 *
 * Colours, sizes, ids and URLs to uploads are content in the technical sense
 * but never what a correction targets, so they are left out of the list to
 * keep it readable. They can still be edited by naming the path directly.
 */
function siite_bridge_text_leaves( $val, $path = '', &$out = null ) {
	if ( $out === null ) { $out = []; }
	if ( is_string( $val ) ) {
		$trim = trim( wp_strip_all_tags( $val ) );
		$leaf = substr( $path, strrpos( $path, '.' ) === false ? 0 : strrpos( $path, '.' ) + 1 );
		$skip = preg_match( '/^(_|__)/', $leaf )
			|| preg_match( '/^#[0-9a-fA-F]{3,8}$/', $trim )
			|| preg_match( '/(color|size|align|position|width|height|gap|space|type|style|id|key|unit|animation)$/i', $leaf );
		if ( $trim !== '' && ! $skip && mb_strlen( $trim ) > 1 ) {
			$out[ $path ] = $val;
		}
		return $out;
	}
	if ( is_array( $val ) ) {
		foreach ( $val as $k => $v ) {
			if ( $k === '__dynamic__' ) { continue; }
			siite_bridge_text_leaves( $v, $path === '' ? (string) $k : "$path.$k", $out );
		}
	}
	return $out;
}

/**
 * The settings on an element that are DESIGN rather than words.
 *
 * The exact complement of siite_bridge_text_leaves(): that one drops colours,
 * sizes, alignments and units to keep a correction readable, and this one keeps
 * only those. Both are needed, because "the blue background on the front page
 * should be pink" is a perfectly ordinary request and the value it names —
 * `background_color` on the section — is invisible in the text list by design.
 *
 * Private keys stay out, with two named exceptions. Elementor keeps its
 * Advanced-tab settings under a leading underscore, and `_padding` / `_margin`
 * are the two anybody actually asks for. Everything else beginning with an
 * underscore is internal (`_element_id`, `_css_classes`, `_column_size`) and
 * writing it is how a layout gets quietly broken.
 */
function siite_bridge_style_leaves( $val, $path = '', &$out = null ) {
	if ( $out === null ) { $out = []; }

	if ( is_scalar( $val ) ) {
		$root = explode( '.', $path )[0];
		if ( strpos( $root, '_' ) === 0
			&& ! in_array( $root, [ '_padding', '_margin' ], true ) ) {
			return $out;
		}
		$leaf = substr( $path, strrpos( $path, '.' ) === false ? 0 : strrpos( $path, '.' ) + 1 );
		$text = trim( (string) $val );
		if ( $text === '' ) { return $out; }

		$is_colour = (bool) preg_match( '/^#[0-9a-fA-F]{3,8}$/', $text )
			|| preg_match( '/^rgba?\(/i', $text );
		$is_knob   = (bool) preg_match(
			'/(color|colour|size|align|position|width|height|gap|space|type|style|'
			. 'unit|animation|background|border|radius|shadow|opacity|weight|'
			. 'transform|spacing|direction|ratio|top|right|bottom|left|linked)$/i',
			$leaf );
		if ( $is_colour || $is_knob ) {
			$out[ $path ] = [
				'value' => $val,
				'kind'  => $is_colour ? 'colour' : 'setting',
			];
		}
		return $out;
	}

	if ( is_array( $val ) ) {
		foreach ( $val as $k => $v ) {
			// Reported separately by siite_bridge_bound(): a value fed from
			// the kit's global palette ignores whatever is written here.
			if ( $k === '__dynamic__' || $k === '__globals__' ) { continue; }
			siite_bridge_style_leaves( $v, $path === '' ? (string) $k : "$path.$k", $out );
		}
	}
	return $out;
}


/**
 * Which of an element's settings are fed from somewhere else.
 *
 * Two mechanisms, one consequence. `__dynamic__` is an Elementor tag; on an
 * Elementor Pro site with a kit, `__globals__` points a colour or a font at the
 * site's global palette — `globals/colors?id=primary`. Either way the value
 * stored next to it is ignored at render time, so writing it changes nothing a
 * visitor can see and the write reports success.
 */
function siite_bridge_bound( $settings ) {
	$out = [];
	foreach ( (array) ( $settings['__dynamic__'] ?? [] ) as $key => $tag ) {
		$out[ $key ] = [ 'via' => 'dynamic', 'source' => (string) $tag ];
	}
	foreach ( (array) ( $settings['__globals__'] ?? [] ) as $key => $ref ) {
		if ( $ref === '' || $ref === null ) { continue; }
		$out[ $key ] = [ 'via' => 'global', 'source' => (string) $ref ];
	}
	return $out;
}


function siite_bridge_flatten( $nodes, &$out = null, $path = '' ) {
	if ( $out === null ) { $out = []; }
	foreach ( $nodes as $i => $n ) {
		$here = $path === '' ? (string) $i : "$path.$i";
		if ( ( $n['elType'] ?? '' ) === 'widget' ) {
			$s = $n['settings'] ?? [];
			$preview = '';
			foreach ( [ 'title', 'editor', 'text', 'description_text', 'heading_title' ] as $k ) {
				if ( ! empty( $s[ $k ] ) && is_string( $s[ $k ] ) ) {
					$preview = trim( wp_strip_all_tags( $s[ $k ] ) );
					break;
				}
			}
			$texts = siite_bridge_text_leaves( $s );
			$elsewhere = null;
			if ( in_array( $n['widgetType'] ?? '', [ 'global', 'template' ], true ) ) {
				$ref = $s['templateID'] ?? $s['template_id'] ?? ( $n['templateID'] ?? null );
				$elsewhere = $ref ? (int) $ref : true;
			}
			$out[] = [
				'id'        => $n['id'] ?? '',
				'widget'    => $n['widgetType'] ?? '',
				'path'      => $here,
				'preview'   => mb_substr( $preview, 0, 120 ),
				'texts'     => $texts,
				'styles'    => siite_bridge_style_leaves( $s ),
				'bound'     => siite_bridge_bound( $s ),
				'dynamic'   => array_keys( (array) ( $s['__dynamic__'] ?? [] ) ),
				'elsewhere' => $elsewhere,
			];
		}
		if ( ! empty( $n['elements'] ) ) { siite_bridge_flatten( $n['elements'], $out, $here ); }
	}
	return $out;
}

/**
 * Every element in the tree, not only the widgets, with where it sits.
 *
 * siite_bridge_flatten() answers "what text is on this page" and deliberately
 * emits widgets alone. This answers "where would a new section go", which needs
 * the sections and containers too, plus each element's parent and its index
 * among its siblings — an anchor like "after the hero" is meaningless without
 * them.
 *
 * `label` is what a person would call the thing: the first real string inside
 * a widget, or the kind and child count for a container.
 */
function siite_bridge_outline( $nodes, $parent = null, $depth = 0, &$out = null, $path = '' ) {
	if ( $out === null ) { $out = []; }
	foreach ( (array) $nodes as $i => $n ) {
		$here = $path === '' ? (string) $i : "$path.$i";
		$el   = (string) ( $n['elType'] ?? '' );
		$wid  = (string) ( $n['widgetType'] ?? '' );
		$kids = $n['elements'] ?? [];

		$label = '';
		if ( $el === 'widget' ) {
			foreach ( siite_bridge_text_leaves( $n['settings'] ?? [] ) as $val ) {
				$label = trim( wp_strip_all_tags( is_string( $val ) ? $val : '' ) );
				if ( $label !== '' ) { break; }
			}
		}
		if ( $label === '' ) {
			$label = $el . ( $kids ? ' (' . count( $kids ) . ')' : '' );
		}

		$settings = $n['settings'] ?? [];
		$out[] = [
			'id'       => $n['id'] ?? '',
			'elType'   => $el,
			'widget'   => $wid ?: null,
			'path'     => $here,
			'parent'   => $parent,
			'depth'    => $depth,
			'index'    => (int) $i,
			'children' => count( (array) $kids ),
			'label'    => mb_substr( $label, 0, 90 ),
			// The background colour of a page lives on the SECTION, not on any
			// widget, so an outline without these cannot answer "make the blue
			// band pink" — which is an entirely ordinary request.
			'styles'   => siite_bridge_style_leaves( $settings ),
			'bound'    => siite_bridge_bound( $settings ),
		];
		if ( $kids ) {
			siite_bridge_outline( $kids, $n['id'] ?? '', $depth + 1, $out, $here );
		}
	}
	return $out;
}


function siite_bridge_doc_get( $req ) {
	$id   = (int) $req['id'];
	$tree = siite_bridge_tree( $id );
	if ( ! $tree ) {
		return new WP_Error( 'siite_no_elementor', "Post $id has no Elementor data", [ 'status' => 404 ] );
	}
	return [
		'id'       => $id,
		'title'    => get_the_title( $id ),
		'type'     => get_post_type( $id ),
		'status'   => get_post_status( $id ),
		'url'      => get_permalink( $id ),
		// Which generation this document is built from. A new section has to
		// match it, so it is answered per document rather than per site: on a
		// site part way through a rebuild the two differ.
		'format'   => siite_bridge_format( $tree ),
		'widgets'  => siite_bridge_flatten( $tree ),
		'outline'  => siite_bridge_outline( $tree ),
		'data'     => $req->get_param( 'full' ) ? $tree : null,
		'settings' => get_post_meta( $id, '_elementor_page_settings', true ),
	];
}

/**
 * GET /element/<post>/<element> — one element exactly as Elementor stores it.
 *
 * The filtered views (texts, styles) exist to keep a page readable, and they
 * drop a great deal on the way: anything the walkers do not recognise, and
 * every setting Elementor left at its default and therefore never wrote down.
 * That is fine until somebody asks for something the filters do not cover, at
 * which point the only honest answer is "I cannot see it".
 *
 * This is the escape hatch: the raw node, its settings verbatim, and the same
 * document's other element ids for context. What can be read can be written,
 * through the ordinary /doc route with "create": true.
 */
function siite_bridge_element( $req ) {
	$id  = (int) $req['id'];
	$eid = (string) $req['element'];

	$tree = siite_bridge_tree( $id );
	if ( ! $tree ) {
		return new WP_Error( 'siite_no_elementor', "Post $id has no Elementor data", [ 'status' => 404 ] );
	}
	$path = siite_bridge_path_of( $tree, $eid );
	if ( $path === null ) {
		return new WP_Error( 'siite_no_element', "Element $eid is not on this document",
			[ 'status' => 404 ] );
	}
	$node = siite_bridge_node_ref( $tree, $path );

	$parent = null;
	if ( count( $path ) > 1 ) {
		$up     = $path;
		array_pop( $up );
		$parent = siite_bridge_node_ref( $tree, $up )['id'] ?? null;
	}

	return [
		'post'     => $id,
		'id'       => $eid,
		'elType'   => $node['elType'] ?? '',
		'widget'   => $node['widgetType'] ?? null,
		'parent'   => $parent,
		'children' => array_map( function ( $n ) {
			return [ 'id' => $n['id'] ?? '', 'elType' => $n['elType'] ?? '',
			         'widget' => $n['widgetType'] ?? null ];
		}, (array) ( $node['elements'] ?? [] ) ),
		// Verbatim. Every key, including the ones no walker recognises.
		'settings' => $node['settings'] ?? [],
		'bound'    => siite_bridge_bound( $node['settings'] ?? [] ),
	];
}


/**
 * GET /render/<id> — the document's own rendered HTML, from Elementor.
 *
 * Fetching the public URL is not enough, and on a draft it is actively
 * misleading. A new page is created as a draft on purpose, a draft is not
 * publicly viewable, so an anonymous fetch gets the login screen or a 404 —
 * and every single write to it was reported as "the change is in the database
 * but cannot be seen on the page". Measured on a real dev site 23 August 2026:
 * twelve of thirteen correct writes carried that warning.
 *
 * Elementor renders the document here instead, authenticated and server-side.
 * That works for a draft, for a theme-builder template with no URL of its own,
 * and it steps around any page cache in front of the site.
 *
 * The public fetch stays worth doing on a PUBLISHED page — it is the only
 * thing that proves the cache actually cleared — so both are reported and the
 * caller can tell the two apart.
 */
function siite_bridge_render( $req ) {
	$id   = (int) $req['id'];
	$post = get_post( $id );
	if ( ! $post ) {
		return new WP_Error( 'siite_no_post', "Post $id does not exist", [ 'status' => 404 ] );
	}

	$html = '';
	$how  = 'none';
	try {
		if ( class_exists( '\Elementor\Plugin' )
			&& isset( \Elementor\Plugin::$instance->frontend )
			&& method_exists( \Elementor\Plugin::$instance->frontend, 'get_builder_content_for_display' ) ) {
			$html = (string) \Elementor\Plugin::$instance->frontend
				->get_builder_content_for_display( $id, false );
			$how  = 'elementor';
		}
	} catch ( \Throwable $e ) {
		$how = 'failed-' . substr( $e->getMessage(), 0, 80 );
	}
	if ( $html === '' && $how !== 'elementor' ) {
		// Not an Elementor document, or the renderer moved. The post's own
		// content is still better than nothing and still beats a login page.
		$html = apply_filters( 'the_content', $post->post_content );
		$how  = $how === 'none' ? 'post_content' : $how;
	}

	$public = in_array( $post->post_status, [ 'publish' ], true );
	return [
		'post'    => $id,
		'status'  => $post->post_status,
		'public'  => $public,
		'url'     => get_permalink( $id ),
		'preview' => $public ? get_permalink( $id )
		                     : add_query_arg( 'preview', 'true', get_permalink( $id ) ),
		'how'     => $how,
		'html'    => $html,
	];
}


/**
 * GET /images/<id> — every image the document actually uses, and where.
 *
 * A third of all client requests are about a photo, and almost all of them are
 * "swap the one in that section", not "change the media library". Describing
 * which widget holds which picture in words is the slow part; this makes it a
 * list with thumbnails, so the swap becomes point-and-choose.
 *
 * An Elementor image value is { id, url }. It turns up under several keys —
 * `image` on the image widget, `background_image` on a section or container,
 * `image` inside a repeater row — so the tree is searched by SHAPE rather than
 * by a list of key names that would never be complete on a site with
 * third-party widgets.
 */
function siite_bridge_images( $req ) {
	$id   = (int) $req['id'];
	$tree = siite_bridge_tree( $id );
	if ( ! $tree ) {
		return new WP_Error( 'siite_no_elementor', "Post $id has no Elementor data", [ 'status' => 404 ] );
	}

	$out = [];
	$look = function ( $settings, $path, $node ) use ( &$look, &$out ) {
		if ( ! is_array( $settings ) ) { return; }

		// The shape, not the name: { id, url } is an Elementor media value
		// wherever it appears, including inside a repeater row and inside a
		// widget nobody here has heard of.
		if ( array_key_exists( 'url', $settings ) && array_key_exists( 'id', $settings )
			&& ! is_array( $settings['url'] ) ) {
			$url = (string) $settings['url'];
			if ( $url !== '' && preg_match( '/\.(jpe?g|png|gif|webp|avif|svg)(\?|$)/i', $url ) ) {
				$att = (int) ( $settings['id'] ?: 0 );
				$meta = $att ? wp_get_attachment_metadata( $att ) : null;
				$out[] = [
					'element' => $node['id'] ?? '',
					'widget'  => $node['widgetType'] ?? ( $node['elType'] ?? '' ),
					'key'     => $path,
					'id'      => $att ?: null,
					'url'     => $url,
					'alt'     => $att ? (string) get_post_meta( $att, '_wp_attachment_image_alt', true ) : '',
					'title'   => $att ? get_the_title( $att ) : basename( $url ),
					'width'   => $meta['width'] ?? null,
					'height'  => $meta['height'] ?? null,
					// True when the file is not in this site's library — an
					// image left behind by an import, which can be replaced but
					// has no library entry to look up.
					'orphan'  => ! $att,
				];
			}
			return;
		}
		foreach ( $settings as $k => $v ) {
			if ( $k === '__dynamic__' || $k === '__globals__' ) { continue; }
			if ( is_array( $v ) ) {
				$look( $v, $path === '' ? (string) $k : "$path.$k", $node );
			}
		}
	};

	$walk = function ( $nodes ) use ( &$walk, $look ) {
		foreach ( (array) $nodes as $n ) {
			$look( $n['settings'] ?? [], '', $n );
			if ( ! empty( $n['elements'] ) ) { $walk( $n['elements'] ); }
		}
	};
	$walk( $tree );

	// A label somebody can match to what they see on the page. "image" says
	// nothing when a page has four of them; the words next to the picture do.
	$near = [];
	foreach ( siite_bridge_flatten( $tree ) as $w ) {
		if ( ! empty( $w['preview'] ) ) { $near[ $w['id'] ] = $w['preview']; }
	}
	$says = [
		'background_image' => 'baggrundsbillede',
		'image'            => 'billede',
	];
	foreach ( $out as &$row ) {
		$what = $says[ $row['key'] ] ?? $row['key'];
		$row['label'] = $what . ' i ' . $row['widget']
			. ( isset( $near[ $row['element'] ] )
				? ' — "' . mb_substr( $near[ $row['element'] ], 0, 40 ) . '"' : '' );
	}
	unset( $row );

	return [ 'post' => $id, 'title' => get_the_title( $id ),
	         'url' => get_permalink( $id ), 'images' => $out ];
}


/**
 * GET /documents/<id> — every file a document links to, and from where.
 *
 * Documents are 13% of the requests on the web dev board, and the request is
 * almost always "here is the new price list" or "the brochure is out of date".
 * Which is a swap, not an upload — but the link can be in three different
 * shapes, and that is why it needs finding rather than guessing:
 *
 *   link.url on a button or an icon-list row     a link CONTROL
 *   <a href="…"> inside a text-editor or html    markup
 *   url on a widget that takes a file directly   a plain value
 *
 * All three are reported the same way, with `how` saying which, because the
 * swap is written differently for each: a control takes a value, markup takes
 * a substring replacement.
 */
function siite_bridge_documents( $req ) {
	$id   = (int) $req['id'];
	$tree = siite_bridge_tree( $id );
	if ( ! $tree ) {
		return new WP_Error( 'siite_no_elementor', "Post $id has no Elementor data", [ 'status' => 404 ] );
	}

	$ext  = 'pdf|docx?|xlsx?|pptx?|zip|csv|txt|rtf';
	$out  = [];

	$note = function ( $node, $key, $url, $how, $inside = null ) use ( &$out ) {
		$att = attachment_url_to_postid( $url );
		$out[] = [
			'element'  => $node['id'] ?? '',
			'widget'   => $node['widgetType'] ?? ( $node['elType'] ?? '' ),
			'key'      => $key,
			'how'      => $how,          // control | markup | value
			'url'      => $url,
			'filename' => basename( parse_url( $url, PHP_URL_PATH ) ?: $url ),
			'id'       => $att ?: null,
			'title'    => $att ? get_the_title( $att ) : null,
			'external' => ! $att && strpos( $url, home_url() ) !== 0,
			// For a markup hit: the exact string to replace, so a swap does not
			// have to rewrite the whole block.
			'inside'   => $inside,
		];
	};

	$look = function ( $settings, $path, $node ) use ( &$look, $note, $ext ) {
		if ( ! is_array( $settings ) ) { return; }

		// A link control: { url, is_external, nofollow }.
		if ( array_key_exists( 'url', $settings ) && ! is_array( $settings['url'] ) ) {
			$url = (string) $settings['url'];
			if ( $url !== '' && preg_match( '#\.(' . $ext . ')(\?|$)#i', $url ) ) {
				$note( $node, $path === '' ? 'url' : "$path.url", $url,
					array_key_exists( 'is_external', $settings ) ? 'control' : 'value' );
			}
		}

		foreach ( $settings as $k => $v ) {
			if ( $k === '__dynamic__' || $k === '__globals__' ) { continue; }
			if ( is_array( $v ) ) {
				$look( $v, $path === '' ? (string) $k : "$path.$k", $node );
				continue;
			}
			// Markup: a link written by hand inside a text editor or an html
			// block. The href is the thing to swap, not the whole block.
			if ( is_string( $v ) && strpos( $v, 'href' ) !== false ) {
				if ( preg_match_all( '#href=["\']([^"\']+\.(?:' . $ext . '))(?:\?[^"\']*)?["\']#i',
						$v, $hits, PREG_SET_ORDER ) ) {
					foreach ( $hits as $hit ) {
						$note( $node, $path === '' ? (string) $k : "$path.$k",
							$hit[1], 'markup', $hit[1] );
					}
				}
			}
		}
	};

	$walk = function ( $nodes ) use ( &$walk, $look ) {
		foreach ( (array) $nodes as $n ) {
			$look( $n['settings'] ?? [], '', $n );
			if ( ! empty( $n['elements'] ) ) { $walk( $n['elements'] ); }
		}
	};
	$walk( $tree );

	// A label somebody can match to what they see on the page.
	$near = [];
	foreach ( siite_bridge_flatten( $tree ) as $w ) {
		if ( ! empty( $w['preview'] ) ) { $near[ $w['id'] ] = $w['preview']; }
	}
	foreach ( $out as &$row ) {
		$row['label'] = $row['filename']
			. ( isset( $near[ $row['element'] ] )
				? ' i "' . mb_substr( $near[ $row['element'] ], 0, 34 ) . '"'
				: ' i ' . $row['widget'] );
	}
	unset( $row );

	return [ 'post' => $id, 'title' => get_the_title( $id ),
	         'url' => get_permalink( $id ), 'documents' => $out ];
}


/* ------------------------------------------- the site's design system --- */

/**
 * The kit: the client's own colours, fonts and breakpoints.
 *
 * This is the difference between a section that matches the site and one that
 * merely sits on it. Without the kit, anything new is built from colours
 * invented on the spot — which is both worse-looking and, on a client site, a
 * brand the client did not choose (~/.claude/rules/brand-colour-exact.md).
 *
 * A value bound to a global is stored as `globals/colors?id=primary` under the
 * element's `__globals__`, not as a hex next to it, so binding is how new
 * content follows the site when the client later changes their palette.
 */
function siite_bridge_kit() {
	$kit_id = (int) get_option( 'elementor_active_kit' );
	$out = [ 'kit' => $kit_id, 'colors' => [], 'typography' => [],
	         'breakpoints' => [], 'suffixes' => [ '', '_tablet', '_mobile' ] ];

	try {
		if ( $kit_id && isset( \Elementor\Plugin::$instance->documents ) ) {
			$doc = \Elementor\Plugin::$instance->documents->get( $kit_id );
			$s   = $doc ? $doc->get_settings() : [];

			foreach ( [ 'system_colors' => 'system', 'custom_colors' => 'custom' ] as $key => $kind ) {
				foreach ( (array) ( $s[ $key ] ?? [] ) as $row ) {
					if ( empty( $row['_id'] ) ) { continue; }
					$out['colors'][] = [
						'id'    => $row['_id'],
						'name'  => $row['title'] ?? $row['_id'],
						'value' => $row['color'] ?? '',
						'kind'  => $kind,
						'bind'  => 'globals/colors?id=' . $row['_id'],
					];
				}
			}
			foreach ( [ 'system_typography' => 'system', 'custom_typography' => 'custom' ] as $key => $kind ) {
				foreach ( (array) ( $s[ $key ] ?? [] ) as $row ) {
					if ( empty( $row['_id'] ) ) { continue; }
					$out['typography'][] = [
						'id'     => $row['_id'],
						'name'   => $row['title'] ?? $row['_id'],
						'family' => $row['typography_font_family'] ?? null,
						'weight' => $row['typography_font_weight'] ?? null,
						'size'   => $row['typography_font_size'] ?? null,
						'kind'   => $kind,
						'bind'   => 'globals/typography?id=' . $row['_id'],
					];
				}
			}
			// Page-level defaults worth knowing before building: the site's own
			// content width decides whether a new section needs its own.
			foreach ( [ 'container_width', 'space_between_widgets', 'body_typography_font_family',
			            'page_title_selector' ] as $k ) {
				if ( isset( $s[ $k ] ) ) { $out['defaults'][ $k ] = $s[ $k ]; }
			}
		}
	} catch ( \Throwable $e ) {
		$out['error'] = substr( $e->getMessage(), 0, 160 );
	}

	// The responsive suffixes a document may legally use. A site with extra
	// breakpoints has more than _tablet and _mobile, and writing a suffix the
	// site does not have stores fine and renders nowhere.
	try {
		if ( isset( \Elementor\Plugin::$instance->breakpoints ) ) {
			foreach ( \Elementor\Plugin::$instance->breakpoints->get_active_breakpoints() as $name => $bp ) {
				$out['breakpoints'][] = [ 'name' => $name, 'value' => $bp->get_value() ];
			}
			$out['suffixes'] = array_merge( [ '' ],
				array_map( function ( $b ) { return '_' . $b['name']; }, $out['breakpoints'] ) );
		}
	} catch ( \Throwable $e ) {
		$out['breakpoint_error'] = substr( $e->getMessage(), 0, 120 );
	}

	$out['backups'] = $kit_id ? siite_bridge_kit_backups( $kit_id ) : [];
	return $out;
}


/**
 * What this site is actually built from, learned from the site itself.
 *
 * The widget registry cannot answer this: Elementor expands a widget's group
 * controls lazily, so a registry dump gives 176 keys for `heading` and none of
 * them is `title_color`. And on a real client site most widgets are not
 * Elementor's at all — they are UiCore Pro, Element Pack, whatever the theme
 * ships — which no amount of general knowledge covers.
 *
 * So the vocabulary is read off the pages: every widget type in use, the union
 * of the setting keys real instances carry, and one example value each. That is
 * both correct by construction and better than a schema, because it shows how
 * THIS site uses the widget rather than what it theoretically accepts.
 */
function siite_bridge_vocabulary( $req ) {
	$only  = (string) $req->get_param( 'widget' );
	$types = [];

	foreach ( siite_bridge_inventory() as $doc ) {
		$tree = siite_bridge_tree( $doc['id'] );
		foreach ( siite_bridge_outline( $tree ) as $el ) {
			$kind = $el['widget'] ?: $el['elType'];
			if ( $kind === '' ) { continue; }
			if ( $only !== '' && $kind !== $only ) { continue; }

			if ( ! isset( $types[ $kind ] ) ) {
				$types[ $kind ] = [ 'kind' => $kind, 'count' => 0, 'keys' => [],
				                    'where' => [], 'bound' => [] ];
			}
			$types[ $kind ]['count']++;
			if ( count( $types[ $kind ]['where'] ) < 4 ) {
				$types[ $kind ]['where'][] = [ 'post' => $doc['id'], 'element' => $el['id'],
				                               'title' => $doc['title'] ];
			}
			foreach ( (array) ( $el['styles'] ?? [] ) as $key => $meta ) {
				if ( ! isset( $types[ $kind ]['keys'][ $key ] ) ) {
					$types[ $kind ]['keys'][ $key ] = [ 'kind' => $meta['kind'] ?? 'setting',
					                                    'example' => $meta['value'], 'seen' => 0 ];
				}
				$types[ $kind ]['keys'][ $key ]['seen']++;
			}
			foreach ( (array) ( $el['bound'] ?? [] ) as $key => $meta ) {
				$types[ $kind ]['bound'][ $key ] = $meta['source'] ?? true;
			}
		}
	}

	// Text keys too, from the flatten pass, so the vocabulary is the whole
	// widget rather than only its design.
	foreach ( siite_bridge_inventory() as $doc ) {
		foreach ( siite_bridge_flatten( siite_bridge_tree( $doc['id'] ) ) as $w ) {
			$kind = $w['widget'] ?: 'widget';
			if ( $only !== '' && $kind !== $only ) { continue; }
			if ( ! isset( $types[ $kind ] ) ) { continue; }
			foreach ( (array) ( $w['texts'] ?? [] ) as $key => $value ) {
				if ( isset( $types[ $kind ]['keys'][ $key ] ) ) { continue; }
				$types[ $kind ]['keys'][ $key ] = [
					'kind'    => 'text',
					'example' => is_string( $value ) ? mb_substr( $value, 0, 90 ) : $value,
					'seen'    => 1,
				];
			}
		}
	}

	uasort( $types, function ( $a, $b ) { return $b['count'] <=> $a['count']; } );
	return array_values( $types );
}


/**
 * The media library, so an image can be chosen instead of asked for.
 *
 * The bridge's role has no upload_files on purpose, so nothing here adds a
 * file. Picking one that is already there needs no such right, and it is what
 * most requests actually mean: the photo is on the site, in the wrong place.
 */
function siite_bridge_media( $req ) {
	$q = trim( (string) $req->get_param( 'q' ) );
	// Images by default, because that is what most requests are about. `kind`
	// switches to the files a client attaches to a mail instead.
	$kind = (string) $req->get_param( 'kind' );
	$mimes = $kind === 'document'
		? [ 'application/pdf', 'application/msword',
		    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
		    'application/vnd.ms-excel',
		    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
		    'application/vnd.ms-powerpoint',
		    'application/vnd.openxmlformats-officedocument.presentationml.presentation' ]
		: 'image';
	$args = [
		'post_type'      => 'attachment',
		'post_status'    => 'inherit',
		'post_mime_type' => $mimes,
		'posts_per_page' => min( 60, max( 1, (int) ( $req->get_param( 'limit' ) ?: 40 ) ) ),
		'orderby'        => 'date',
		'order'          => 'DESC',
	];
	if ( $q !== '' ) { $args['s'] = $q; }

	$out = [];
	foreach ( get_posts( $args ) as $item ) {
		$meta = wp_get_attachment_metadata( $item->ID );
		$url = wp_get_attachment_url( $item->ID );
		$file = get_attached_file( $item->ID );
		$out[] = [
			'id'       => (int) $item->ID,
			'title'    => $item->post_title,
			'alt'      => (string) get_post_meta( $item->ID, '_wp_attachment_image_alt', true ),
			'url'      => $url,
			'filename' => $url ? basename( $url ) : null,
			'bytes'    => ( $file && file_exists( $file ) ) ? filesize( $file ) : null,
			'width'    => $meta['width'] ?? null,
			'height'   => $meta['height'] ?? null,
			'mime'     => $item->post_mime_type,
			// The shape an Elementor image control expects. Writing only the
			// url leaves Elementor without the id it needs for srcset, and
			// writing only the id leaves nothing for the markup to fall back on.
			// The shape an Elementor image control expects. Writing only the
			// url leaves Elementor without the id it needs for srcset, and
			// writing only the id leaves nothing for the markup to fall back on.
			'set'      => [ 'id' => (int) $item->ID, 'url' => $url ],
			// A document is not set on an image control, it is LINKED to, and
			// a link control is { url, is_external, nofollow }.
			'link'     => [ 'url' => $url, 'is_external' => '', 'nofollow' => '' ],
		];
	}
	return [ 'can_upload' => current_user_can( 'upload_files' ),
	         'kind' => $kind === 'document' ? 'document' : 'image',
	         'images' => $out,
	         'total' => (int) wp_count_posts( 'attachment' )->inherit ];
}


/**
 * POST /upload — put one file in the media library.
 *
 * Images are the single biggest thing clients ask for: of 120 requests on the
 * web dev board, 35% mention a photo, logo, gallery or video and another 13% a
 * PDF. Being able to place an image that was already there, but not to add the
 * one the client just emailed, is half a track.
 *
 * The role still does not hold upload_files, and that is deliberate: it means a
 * stolen application password cannot push files through wp/v2/media or any
 * other WordPress endpoint. The capability is granted for the duration of this
 * one call, on this one request, the same way the kses filter is suspended
 * around our own write — narrow, explicit, and recorded in the ledger.
 *
 * What it will NOT take: anything outside the allowlist. Especially SVG, which
 * WordPress refuses by default for good reason — it is markup, it can carry
 * script, and a media library is exactly where nobody looks for one.
 *
 * Body: { "filename": "tag.jpg", "data": "<base64>", "alt": "...", "title": "..." }
 */
const SIITE_BRIDGE_UPLOAD_MAX  = 20971520;   // 20 MB
const SIITE_BRIDGE_UPLOAD_MIME = [
	'jpg|jpeg|jpe' => 'image/jpeg',
	'png'          => 'image/png',
	'gif'          => 'image/gif',
	'webp'         => 'image/webp',
	'avif'         => 'image/avif',
	'pdf'          => 'application/pdf',
	// 1.13.0. SVG only through Elementor's sanitiser, video only in chunks
	// above 20 MB. See siite_bridge_store_file().
	'svg'          => 'image/svg+xml',
	'mp4|m4v'      => 'video/mp4',
	'webm'         => 'video/webm',
	// The formats a client actually attaches to a mail. Not executed by the
	// server, and allowed by WordPress by default; an office file with a macro
	// is a risk to whoever opens it, exactly as it was in the mail it came in.
	'doc'          => 'application/msword',
	'docx'         => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
	'xls'          => 'application/vnd.ms-excel',
	'xlsx'         => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
	'ppt'          => 'application/vnd.ms-powerpoint',
	'pptx'         => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
];



/* ---------------------------------------------------------------- writing */

/**
 * Turn a value somebody sensibly wrote into the shape Elementor stores.
 *
 * Elementor's control values are structured, and the structure is invisible
 * from outside: a font size is `{unit, size, sizes}`, padding is
 * `{unit, top, right, bottom, left, isLinked}`, an image is `{id, url}` and
 * needs BOTH or it loses either its srcset or its markup. Writing `48` where a
 * slider lives stores 48, renders nothing, and reports success — the worst
 * kind of failure, because every check passes.
 *
 * So the shapes are met here instead of being a rule somebody has to remember.
 * The strongest signal is what the control already holds; the key's name is the
 * fallback when the setting is being created and there is nothing to copy.
 *
 * A value of `globals/colors?id=primary` is not a value at all — it is a
 * binding, and it belongs in the element's `__globals__`. Handled by the caller
 * through $globals, because it is written somewhere else entirely.
 */
function siite_bridge_normalise( $key, $value, $current, &$binding = null ) {
	// A binding to the site's design system. Elementor resolves it from the kit
	// at render time and ignores whatever sits in the plain key.
	if ( is_string( $value ) && strpos( $value, 'globals/' ) === 0 ) {
		$binding = $value;
		return is_array( $current ) ? $current : '';
	}

	// A dot-path means the caller is addressing one field inside the structure
	// and knows exactly what it is doing. Leave it alone.
	if ( strpos( (string) $key, '.' ) !== false ) { return $value; }

	$shape = null;
	if ( is_array( $current ) ) {
		if ( array_key_exists( 'size', $current ) && array_key_exists( 'unit', $current ) ) {
			$shape = 'slider';
		} elseif ( array_key_exists( 'top', $current ) && array_key_exists( 'bottom', $current ) ) {
			$shape = 'dimensions';
		} elseif ( array_key_exists( 'url', $current ) && array_key_exists( 'id', $current ) ) {
			$shape = 'media';
		}
	} elseif ( $current === null ) {
		$leaf = preg_replace( '/_(tablet|mobile|widescreen|laptop|tablet_extra|mobile_extra)$/', '', (string) $key );
		if ( preg_match( '/(^|_)(padding|margin)$/', $leaf ) ) {
			$shape = 'dimensions';
		} elseif ( preg_match( '/(font_size|_size|_width|_height|_space|_gap|_radius|spacing|blur)$/', $leaf ) ) {
			$shape = 'slider';
		} elseif ( preg_match( '/(^|_)image$/', $leaf ) ) {
			$shape = 'media';
		}
	}
	if ( ! $shape ) { return $value; }

	if ( $shape === 'slider' ) {
		if ( is_array( $value ) ) {
			return array_merge( [ 'unit' => 'px', 'size' => '', 'sizes' => [] ], $value );
		}
		// "48px", "3rem", 48, "48"
		if ( preg_match( '/^\s*(-?[\d.]+)\s*(px|%|em|rem|vw|vh|deg|s|ms)?\s*$/i', (string) $value, $m ) ) {
			return [ 'unit' => strtolower( $m[2] ?? '' ) ?: ( is_array( $current ) ? ( $current['unit'] ?? 'px' ) : 'px' ),
			         'size' => 0 + $m[1], 'sizes' => [] ];
		}
		return $value;
	}

	if ( $shape === 'dimensions' ) {
		$base = is_array( $current ) ? $current
			: [ 'unit' => 'px', 'top' => '', 'right' => '', 'bottom' => '', 'left' => '', 'isLinked' => false ];
		if ( is_array( $value ) ) {
			$out = array_merge( $base, $value );
			// A partial dimensions value must not leave the other sides empty:
			// Elementor writes `padding: 40px  40px ` and the browser drops
			// the whole declaration.
			foreach ( [ 'top', 'right', 'bottom', 'left' ] as $side ) {
				if ( ! isset( $out[ $side ] ) || $out[ $side ] === '' ) { $out[ $side ] = '0'; }
			}
			$out['unit'] = $out['unit'] ?? 'px';
			$out['isLinked'] = ! empty( $out['isLinked'] );
			return $out;
		}
		if ( preg_match( '/^\s*(-?[\d.]+)\s*(px|%|em|rem|vw|vh)?\s*$/i', (string) $value, $m ) ) {
			$n = (string) ( 0 + $m[1] );
			return [ 'unit' => strtolower( $m[2] ?? '' ) ?: 'px', 'top' => $n, 'right' => $n,
			         'bottom' => $n, 'left' => $n, 'isLinked' => true ];
		}
		return $value;
	}

	if ( $shape === 'media' ) {
		if ( is_array( $value ) ) {
			$id = (int) ( $value['id'] ?? 0 );
			if ( $id && empty( $value['url'] ) ) { $value['url'] = wp_get_attachment_url( $id ); }
			return array_merge( [ 'id' => '', 'url' => '' ], $value );
		}
		if ( is_numeric( $value ) ) {
			$id = (int) $value;
			$url = wp_get_attachment_url( $id );
			return $url ? [ 'id' => $id, 'url' => $url ] : $value;
		}
		if ( is_string( $value ) && preg_match( '#^https?://#i', $value ) ) {
			$id = attachment_url_to_postid( $value );
			return [ 'id' => $id ?: '', 'url' => $value ];
		}
		return $value;
	}

	return $value;
}


/** Read a dot-path out of a settings array: "link.url". */
function siite_bridge_path_get( $arr, $path ) {
	foreach ( explode( '.', $path ) as $seg ) {
		if ( ! is_array( $arr ) || ! array_key_exists( $seg, $arr ) ) { return null; }
		$arr = $arr[ $seg ];
	}
	return $arr;
}

/**
 * Write a dot-path into a settings array, creating the branch if it is not
 * there. Elementor stores only non-default settings, so "typography_font_size"
 * on a heading nobody resized has no branch to write into yet.
 */
function siite_bridge_path_set( &$arr, $path, $value, $create = false ) {
	$segs = explode( '.', $path );
	$ref  = &$arr;
	foreach ( $segs as $seg ) {
		if ( ! is_array( $ref ) ) {
			if ( ! $create ) { return false; }
			$ref = [];
		}
		if ( ! array_key_exists( $seg, $ref ) ) {
			if ( ! $create ) { return false; }
			$ref[ $seg ] = [];
		}
		$ref = &$ref[ $seg ];
	}
	$ref = $value;
	return true;
}

/**
 * Apply a list of targeted edits.
 *
 * Body: { "dry_run": true, "edits": [
 *          { "id":"heroh01", "key":"title",  "from":"Aarhuz", "to":"Aarhus" },
 *          { "id":"foott01", "key":"editor", "to":"<p>ny tekst</p>" }
 *        ] }
 *
 * "from" present  -> substring replace, and the edit is SKIPPED if not found.
 * "from" absent   -> the value is replaced outright.
 * Element ids are never touched, and no node is added or removed.
 */
function siite_bridge_doc_edit( $req ) {
	$id      = (int) $req['id'];
	$body    = $req->get_json_params();
	$edits   = $body['edits'] ?? null;
	$dry_run = ! empty( $body['dry_run'] );

	if ( ! is_array( $edits ) || ! $edits ) {
		return new WP_Error( 'siite_no_edits', 'Body must carry a non-empty "edits" array', [ 'status' => 400 ] );
	}

	$tree = siite_bridge_tree( $id );
	if ( ! $tree ) {
		return new WP_Error( 'siite_no_elementor', "Post $id has no Elementor data", [ 'status' => 404 ] );
	}

	$ids_before = array_map( 'strval', array_column( siite_bridge_flatten( $tree ), 'id' ) );
	$log        = [];
	$changed    = 0;

	$walk = function ( &$nodes ) use ( &$walk, $edits, &$log, &$changed ) {
		foreach ( $nodes as &$node ) {
			foreach ( $edits as $e ) {
				if ( ( $node['id'] ?? '' ) !== ( $e['id'] ?? '' ) ) { continue; }
				$key = (string) ( $e['key'] ?? '' );
				if ( $key === '' || strpos( $key, '_' ) === 0 ) {
					$log[] = [ 'status' => 'skipped', 'id' => $e['id'], 'key' => $key, 'why' => 'key empty or private' ];
					continue;
				}
				$root = explode( '.', $key )[0];
				if ( isset( $node['settings']['__dynamic__'][ $root ] ) ) {
					$log[] = [ 'status' => 'skipped', 'id' => $e['id'], 'key' => $key,
					           'why' => 'a dynamic tag supplies this value; editing it here changes nothing' ];
					continue;
				}
				// The same trap wearing different clothes, and the common one on
				// an Elementor Pro site with a kit: a colour or a font bound to
				// the global palette renders from `globals/colors?id=…` and
				// ignores whatever sits next to it. Writing it reports success
				// and changes nothing on the page.
				$global   = $node['settings']['__globals__'][ $root ] ?? '';
				$rebinding = is_string( $e['to'] ?? null ) && strpos( $e['to'], 'globals/' ) === 0;
				if ( $global !== '' && ! $rebinding && empty( $e['unbind'] ) ) {
					// Writing a literal over a bound value is the silent no-op:
					// Elementor renders from the kit and ignores what is stored
					// beside it. But swapping one global for another, and
					// deliberately unbinding, are both ordinary things to want —
					// refusing those made "use the accent colour instead" fail
					// for a reason that reads as a limitation.
					$log[] = [ 'status' => 'skipped', 'id' => $e['id'], 'key' => $key,
					           'why' => "this value comes from the site's global palette "
					                    . "($global). Send another globals/… value to rebind it, "
					                    . '"unbind": true to write a literal instead, or change '
					                    . 'the global colour itself' ];
					continue;
				}
				if ( $global !== '' && ! empty( $e['unbind'] ) && ! $rebinding ) {
					unset( $node['settings']['__globals__'][ $root ] );
					if ( ! $node['settings']['__globals__'] ) {
						unset( $node['settings']['__globals__'] );
					}
				}
				$cur = siite_bridge_path_get( $node['settings'] ?? [], $key );
				if ( $cur === null && empty( $e['create'] ) ) {
					// Elementor stores only what differs from the widget's
					// defaults, so on a real page most settings are simply
					// absent — the font size of a heading nobody resized, the
					// background of a section that never had one. Refusing an
					// absent key therefore refuses almost every design change
					// there is, which reads as "the tool cannot do that" and is
					// really "the tool can only change what somebody already
					// changed once in Elementor".
					//
					// "create": true says the caller means to add it. Everything
					// else still applies: private keys, dynamic tags and globals
					// are refused above, the document is backed up, the write is
					// read back, and a person approves it.
					$log[] = [ 'status' => 'skipped', 'id' => $e['id'], 'key' => $key,
					           'why' => 'setting not present; send "create": true to add it' ];
					continue;
				}
				if ( $cur === null && array_key_exists( 'from', $e ) && $e['from'] !== null ) {
					$log[] = [ 'status' => 'skipped', 'id' => $e['id'], 'key' => $key,
					           'why' => 'cannot replace text in a setting that does not exist yet' ];
					continue;
				}
				// Meet the shape Elementor stores, and lift a design-system
				// binding out into __globals__ where it belongs.
				$binding = null;
				if ( ! array_key_exists( 'from', $e ) || $e['from'] === null ) {
					$e['to'] = siite_bridge_normalise( $key, $e['to'], $cur, $binding );
				}
				if ( $binding !== null ) {
					if ( ! isset( $node['settings']['__globals__'] ) || ! is_array( $node['settings']['__globals__'] ) ) {
						$node['settings']['__globals__'] = [];
					}
					$node['settings']['__globals__'][ $root ] = $binding;
					$log[] = [ 'status' => 'changed', 'id' => $e['id'], 'key' => $key,
					           'before' => is_string( $cur ) ? $cur : null, 'after' => $binding,
					           'also' => 'bundet til sitets designsystem' ];
					$changed++;
					if ( $cur === null ) { continue; }
				}

				if ( array_key_exists( 'from', $e ) && $e['from'] !== null ) {
					if ( ! is_string( $cur ) || strpos( $cur, (string) $e['from'] ) === false ) {
						$log[] = [ 'status' => 'skipped', 'id' => $e['id'], 'key' => $key, 'why' => 'text "' . $e['from'] . '" not found' ];
						continue;
					}
					$new = str_replace( (string) $e['from'], (string) $e['to'], $cur );
				} else {
					$new = $e['to'];
				}
				// A media value naming an attachment that is not in the library
				// renders as a broken image — and it renders the url, so a
				// check that looks for the value on the page confirms it. The
				// only place to catch it is before the write.
				if ( is_array( $new ) && array_key_exists( 'url', $new )
					&& ! empty( $new['id'] ) ) {
					$att = (int) $new['id'];
					if ( get_post_type( $att ) !== 'attachment' ) {
						$log[] = [ 'status' => 'skipped', 'id' => $e['id'], 'key' => $key,
						           'why' => "billed-id $att findes ikke i mediebiblioteket" ];
						continue;
					}
				}

				if ( $new === $cur ) {
					$log[] = [ 'status' => 'nochange', 'id' => $e['id'], 'key' => $key ];
					continue;
				}
				if ( ! isset( $node['settings'] ) || ! is_array( $node['settings'] ) ) {
					$node['settings'] = [];
				}
				siite_bridge_path_set( $node['settings'], $key, $new, ! empty( $e['create'] ) );
				$changed++;
				$row = [
					'status' => $cur === null ? 'created' : 'changed',
					'id' => $e['id'], 'key' => $key,
					'before' => is_string( $cur ) ? mb_substr( $cur, 0, 200 ) : $cur,
					'after'  => is_string( $new ) ? mb_substr( $new, 0, 200 ) : $new,
				];

				// Elementor paints a background colour only when the matching
				// background TYPE is set to classic. A section that never had a
				// background has the colour key and not the type, so setting
				// the colour alone stores fine, verifies fine, and paints
				// nothing. Set the companion and say so, rather than leaving
				// somebody to wonder why the band is still white.
				$pairs = [ 'background_color' => 'background_background',
				           'background_overlay_color' => 'background_overlay_background' ];
				if ( isset( $pairs[ $key ] ) && empty( $node['settings'][ $pairs[ $key ] ] ) ) {
					$node['settings'][ $pairs[ $key ] ] = 'classic';
					$row['also'] = $pairs[ $key ] . ' = classic';
				}
				$log[] = $row;
			}
			if ( ! empty( $node['elements'] ) ) { $walk( $node['elements'] ); }
		}
	};
	$walk( $tree );

	// Structural guard: the same widget ids, in the same order, must survive.
	$ids_after = array_map( 'strval', array_column( siite_bridge_flatten( $tree ), 'id' ) );
	if ( $ids_before !== $ids_after ) {
		return new WP_Error( 'siite_structure_changed', 'Widget ids changed; refusing to write', [ 'status' => 500 ] );
	}

	$result = [
		'id'         => $id,
		'dry_run'    => $dry_run,
		'changed'    => $changed,
		'log'        => $log,
		'widget_ids' => count( $ids_after ),
	];

	if ( $dry_run || ! $changed ) {
		$result['written'] = false;
		return $result;
	}

	$stamp = siite_bridge_backup( $id );
	$wrote = siite_bridge_write_data( $id, $tree );
	if ( is_wp_error( $wrote ) ) { return $wrote; }
	if ( ! $wrote['ok'] ) {
		siite_bridge_restore_stamp( $id, $stamp );
		return new WP_Error( 'siite_verify_failed',
			'Readback mismatch; the backup was restored', [ 'status' => 500 ] );
	}

	$result['written']   = true;
	$result['backup']    = $stamp;
	$result['kept_code'] = $wrote['kept_code'];
	$result['caches']    = siite_bridge_flush( $id );
	return $result;
}


/**
 * Which document actually holds a piece of text? On a site built with global
 * widgets and Elementor Pro templates the words on a page routinely live in a
 * different post, and editing the page they appear on changes nothing.
 */
function siite_bridge_search( $req ) {
	$needle = (string) $req->get_param( 'q' );
	if ( mb_strlen( $needle ) < 2 ) {
		return new WP_Error( 'siite_short_query', 'q must be at least 2 characters', [ 'status' => 400 ] );
	}
	$hits = [];
	foreach ( siite_bridge_inventory() as $doc ) {
		foreach ( siite_bridge_flatten( siite_bridge_tree( $doc['id'] ) ) as $w ) {
			foreach ( $w['texts'] as $path => $val ) {
				if ( mb_stripos( $val, $needle ) === false ) { continue; }
				$plain = trim( wp_strip_all_tags( $val ) );
				$at    = mb_stripos( $plain, $needle );
				$hits[] = [
					'post'    => $doc['id'],
					'type'    => $doc['type'],
					'title'   => $doc['title'],
					'url'     => $doc['url'],
					'widget'  => $w['id'],
					'type_of' => $w['widget'],
					'key'     => $path,
					'snippet' => mb_substr( $plain, max( 0, $at - 40 ), 140 ),
				];
			}
		}
	}
	return $hits;
}


/* ----------------------------------------------------------- writing --- */

/**
 * The one place _elementor_data is written. Everything goes through here.
 *
 * Elementor registers sanitize_elementor_data() as the sanitize_callback for
 * this meta key (modules/wp-rest/classes/elementor-post-meta.php). For any user
 * without unfiltered_html it runs kses over the WHOLE decoded tree, so writing
 * one heading strips <script> and <style> out of every html widget on the same
 * document. It answers 200 while doing it.
 *
 * Measured on the sandbox 2026-08-21: writing a single html widget as the
 * bridge's own role turned
 *     <style>.a{color:red}</style>
 * into
 *     .a{color:red}
 * and the same happened on restore — so a rollback destroyed the code it was
 * supposed to be putting back. The readback compare below is what caught it.
 *
 * The bridge therefore suspends that one callback around its own write, by
 * adding a last-priority filter that hands the value back unchanged. This is
 * not a way around the role. The account still holds no unfiltered_html, so a
 * stolen application password cannot inject a script through wp/v2 or any
 * other WordPress endpoint — only through this route, which backs the document
 * up first, compares the readback, and records what it did in the ledger.
 *
 * Pass $allow_code = false to let the sanitiser run, for a write where code is
 * not expected and stripping it is the safer outcome.
 *
 * Returns [ 'ok' => bool, 'json' => string, 'kept_code' => bool ] or WP_Error.
 */
function siite_bridge_write_data( $id, $tree, $allow_code = true ) {
	$json = is_string( $tree ) ? $tree : wp_json_encode( $tree );
	if ( ! is_string( $json ) || $json === '' ) {
		return new WP_Error( 'siite_encode_failed', 'Could not encode the tree', [ 'status' => 500 ] );
	}

	// Both hook names, because sanitize_meta() runs ONE of them: if a
	// subtype-specific filter exists it returns from that and never applies the
	// generic one. Elementor registers the meta with object_subtype set to each
	// post type, so on a page the live hook is the _for_page variant and
	// filtering only the generic name changes nothing at all.
	$type  = get_post_type( $id ) ?: 'page';
	$hooks = [
		'sanitize_post_meta__elementor_data',
		'sanitize_post_meta__elementor_data_for_' . $type,
	];
	$kept_code = false;
	$keep      = null;

	if ( $allow_code ) {
		$keep = function ( $value ) use ( $json, &$kept_code ) {
			// $value is what the sanitiser left. Comparing tells us whether it
			// actually removed anything, which is worth reporting rather than
			// silently undoing.
			if ( is_string( $value ) && $value !== $json ) { $kept_code = true; }
			return $json;
		};
		foreach ( $hooks as $hook ) {
			add_filter( $hook, $keep, PHP_INT_MAX );
		}
	}

	try {
		update_post_meta( $id, '_elementor_data', wp_slash( $json ) );
	} finally {
		if ( $keep ) {
			foreach ( $hooks as $hook ) {
				remove_filter( $hook, $keep, PHP_INT_MAX );
			}
		}
	}

	// A 200 from update_post_meta is not evidence. Compare the whole document,
	// not just the widget ids: slash mangling and kses both change the text
	// while leaving the structure intact, and that is the failure that would
	// otherwise ship unnoticed.
	$back = wp_json_encode( siite_bridge_tree( $id ) );
	return [
		'ok'        => $back === $json,
		'json'      => $json,
		'kept_code' => $kept_code,
		'readback'  => $back === $json ? null : mb_substr( (string) $back, 0, 400 ),
	];
}


/* --------------------------------------------------------------- backups */

function siite_bridge_backup( $id ) {
	// One second is not fine enough. Two writes to the same document inside the
	// same second produced the same key, add_post_meta() then held two rows
	// under it, and get_post_meta(..., true) returns whichever came first — so
	// a restore to that stamp could hand back the wrong one of the two. The
	// suffix keeps the shape a restore validates (\d{8}-\d{6}(-\d+)?) while
	// making the key unique.
	$stamp = gmdate( 'Ymd-His' );
	$base  = $stamp;
	for ( $n = 2; metadata_exists( 'post', $id, SIITE_BRIDGE_BAK_KEY . $stamp ); $n++ ) {
		$stamp = $base . '-' . $n;
		if ( $n > 60 ) { break; }
	}
	// update_post_meta/add_post_meta run wp_unslash() on the value, so a raw
	// JSON string loses every backslash: "\u00f8" becomes "u00f8" and every
	// Danish character is destroyed on restore. Slash it going in.
	$current = get_post_meta( $id, '_elementor_data', true );
	add_post_meta( $id, SIITE_BRIDGE_BAK_KEY . $stamp, wp_slash( is_string( $current ) ? $current : wp_json_encode( $current ) ) );

	$all = [];
	foreach ( get_post_meta( $id ) as $k => $v ) {
		if ( strpos( $k, SIITE_BRIDGE_BAK_KEY ) === 0 ) { $all[] = $k; }
	}
	sort( $all );
	while ( count( $all ) > SIITE_BRIDGE_BAK_KEEP ) {
		delete_post_meta( $id, array_shift( $all ) );
	}
	return $stamp;
}

function siite_bridge_backups( $req ) {
	$id  = (int) $req['id'];
	$out = [];
	foreach ( get_post_meta( $id ) as $k => $v ) {
		if ( strpos( $k, SIITE_BRIDGE_BAK_KEY ) !== 0 ) { continue; }
		$out[] = [
			'stamp' => substr( $k, strlen( SIITE_BRIDGE_BAK_KEY ) ),
			'bytes' => strlen( (string) ( $v[0] ?? '' ) ),
		];
	}
	sort( $out );
	return $out;
}

function siite_bridge_restore_stamp( $id, $stamp ) {
	$old = get_post_meta( $id, SIITE_BRIDGE_BAK_KEY . $stamp, true );
	if ( $old === '' || $old === false ) { return false; }
	// Through the same write path as everything else. A restore that runs the
	// meta sanitiser would hand back the document with its <script> and
	// <style> stripped — a rollback that destroys exactly what it is being
	// asked to put back.
	$wrote = siite_bridge_write_data( $id, is_string( $old ) ? $old : wp_json_encode( $old ) );
	if ( is_wp_error( $wrote ) || ! $wrote['ok'] ) { return false; }
	siite_bridge_flush( $id );
	return true;
}

function siite_bridge_restore( $req ) {
	$id    = (int) $req['id'];
	$stamp = (string) ( $req->get_json_params()['stamp'] ?? '' );
	if ( ! preg_match( '/^\d{8}-\d{6}(-\d+)?$/', $stamp ) ) {
		return new WP_Error( 'siite_bad_stamp', 'stamp must look like 20260821-114500', [ 'status' => 400 ] );
	}
	if ( ! siite_bridge_restore_stamp( $id, $stamp ) ) {
		return new WP_Error( 'siite_no_backup', "No backup $stamp on post $id", [ 'status' => 404 ] );
	}
	return [ 'id' => $id, 'restored' => $stamp ];
}

/* ---------------------------------------------------------------- caches */

function siite_bridge_caches_available() {
	$seen = [];
	if ( function_exists( 'rocket_clean_domain' ) )        { $seen[] = 'wp-rocket'; }
	if ( has_action( 'litespeed_purge_all' ) )             { $seen[] = 'litespeed'; }
	if ( function_exists( 'w3tc_flush_all' ) )             { $seen[] = 'w3-total-cache'; }
	if ( function_exists( 'wp_cache_clear_cache' ) )       { $seen[] = 'wp-super-cache'; }
	if ( class_exists( 'autoptimizeCache' ) )              { $seen[] = 'autoptimize'; }
	if ( class_exists( '\WpeCommon' ) )                    { $seen[] = 'wp-engine'; }
	if ( defined( 'ELEMENTOR_VERSION' ) )                  { $seen[] = 'elementor-css'; }
	return $seen;
}

function siite_bridge_flush( $id ) {
	$done = [];

	// The post meta is Elementor's documented cache location and is safe to
	// delete on its own. The object call below is Elementor INTERNAL API, so it
	// is fully guarded: an Elementor release that renames it must degrade to a
	// missing cache flush, never to a fatal error on a client's site.
	delete_post_meta( $id, '_elementor_css' );
	$done[] = 'elementor-css-meta';
	try {
		if ( class_exists( '\Elementor\Plugin' )
			&& isset( \Elementor\Plugin::$instance->files_manager )
			&& method_exists( \Elementor\Plugin::$instance->files_manager, 'clear_cache' ) ) {
			\Elementor\Plugin::$instance->files_manager->clear_cache();
			$done[] = 'elementor-css';
		} else {
			$done[] = 'elementor-css-SKIPPED-api-moved';
		}
	} catch ( \Throwable $e ) {
		$done[] = 'elementor-css-FAILED-' . substr( $e->getMessage(), 0, 60 );
	}
	try {
	if ( function_exists( 'rocket_clean_domain' ) )  { rocket_clean_domain();  $done[] = 'wp-rocket'; }
	if ( has_action( 'litespeed_purge_all' ) )       { do_action( 'litespeed_purge_all' ); $done[] = 'litespeed'; }
	if ( function_exists( 'w3tc_flush_all' ) )       { w3tc_flush_all();       $done[] = 'w3-total-cache'; }
	if ( function_exists( 'wp_cache_clear_cache' ) ) { wp_cache_clear_cache(); $done[] = 'wp-super-cache'; }
	if ( class_exists( 'autoptimizeCache' ) )        { \autoptimizeCache::clearall(); $done[] = 'autoptimize'; }
	if ( class_exists( '\WpeCommon' ) && method_exists( '\WpeCommon', 'purge_varnish_cache' ) ) {
		\WpeCommon::purge_varnish_cache(); $done[] = 'wp-engine';
	}
	} catch ( \Throwable $e ) {
		$done[] = 'cache-plugin-FAILED-' . substr( $e->getMessage(), 0, 60 );
	}

	// UiCore and other themes commonly listen for this.
	do_action( 'siite_bridge_after_write', $id );

	return $done;
}

/* ---------------------------------------------------- structure (1.4.0) --- */

/**
 * A fresh Elementor element id: seven lowercase hex characters.
 *
 * Elementor only guarantees these are unique inside one document, so $taken is
 * that document's ids — including the ones minted earlier in the same call.
 * Reusing an id is not a cosmetic problem: the editor treats two elements with
 * the same id as the same element and drops one of them on the next save.
 */
function siite_bridge_mint_id( array &$taken ) {
	for ( $i = 0; $i < 1000; $i++ ) {
		$id = substr( bin2hex( random_bytes( 4 ) ), 0, 7 );
		if ( ! isset( $taken[ $id ] ) ) {
			$taken[ $id ] = true;
			return $id;
		}
	}
	// 16^7 is 268 million; a thousand collisions in a row is not chance.
	throw new \RuntimeException( 'Could not mint a free element id' );
}


/**
 * Every element id in a tree, as a plain list of strings.
 *
 * Through array_keys() and NOT the map below, on purpose. An Elementor id is
 * seven hex characters, so roughly one in twenty-seven is all digits — and PHP
 * turns an all-digit string used as an array key into an integer. The set then
 * held int 1234567 where the minted list held the string "1234567", the two
 * arrays compared unequal while array_diff() (which compares as strings) found
 * nothing wrong, and the structural check failed on about a third of calls with
 * both diffs empty.
 */
function siite_bridge_id_list( $nodes ) {
	return array_map( 'strval', array_keys( siite_bridge_ids( $nodes ) ) );
}


/** Every element id in a tree, as a lookup for collision checks. */
function siite_bridge_ids( $nodes, &$out = null ) {
	if ( $out === null ) { $out = []; }
	foreach ( (array) $nodes as $n ) {
		if ( ! empty( $n['id'] ) ) { $out[ $n['id'] ] = true; }
		if ( ! empty( $n['elements'] ) ) { siite_bridge_ids( $n['elements'], $out ); }
	}
	return $out;
}


/**
 * Give every element in a subtree a new id.
 *
 * Always, for every insert and every duplicate. Whatever ids arrived in the
 * body are thrown away: a caller that copies a section and posts it back keeps
 * the original's ids, and two elements sharing an id is the one corruption
 * Elementor does not recover from.
 */
function siite_bridge_remint( &$nodes, array &$taken, array &$created ) {
	foreach ( $nodes as &$n ) {
		$id        = siite_bridge_mint_id( $taken );
		$n['id']   = $id;
		$created[] = $id;
		if ( ! empty( $n['elements'] ) ) {
			siite_bridge_remint( $n['elements'], $taken, $created );
		}
	}
	unset( $n );
}


/** The index path to an element, e.g. [0, 0, 2]. Null if it is not there. */
function siite_bridge_path_of( $nodes, $id, $prefix = [] ) {
	foreach ( (array) $nodes as $i => $n ) {
		$here = array_merge( $prefix, [ (int) $i ] );
		if ( ( $n['id'] ?? '' ) === $id ) { return $here; }
		if ( ! empty( $n['elements'] ) ) {
			$deep = siite_bridge_path_of( $n['elements'], $id, $here );
			if ( $deep !== null ) { return $deep; }
		}
	}
	return null;
}


/** A reference to the element at an index path. */
function &siite_bridge_node_ref( &$tree, $path ) {
	$node =& $tree[ array_shift( $path ) ];
	foreach ( $path as $idx ) {
		$node =& $node['elements'][ $idx ];
	}
	return $node;
}


/** A reference to the array an element's children live in. [] means the root. */
function &siite_bridge_children_ref( &$tree, $path ) {
	if ( ! $path ) { return $tree; }
	$node =& siite_bridge_node_ref( $tree, $path );
	if ( ! isset( $node['elements'] ) || ! is_array( $node['elements'] ) ) {
		$node['elements'] = [];
	}
	return $node['elements'];
}


/**
 * May this kind of element sit inside that one?
 *
 * Elementor will happily store an illegal nesting and then render nothing, so
 * the refusal has to happen here. '' as the parent means the document root.
 */
function siite_bridge_may_contain( $parent, $child ) {
	$atomic_box = [ 'e-flexbox', 'e-div-block', 'e-grid' ];
	$is_widget  = ( $child === 'widget' );

	if ( $parent === '' ) {
		return in_array( $child, array_merge( [ 'section', 'container' ], $atomic_box ), true );
	}
	if ( $parent === 'section' )   { return $child === 'column'; }
	if ( $parent === 'column' )    { return $is_widget || $child === 'section' || $child === 'container'; }
	if ( $parent === 'container' ) { return $is_widget || $child === 'container'; }
	if ( in_array( $parent, $atomic_box, true ) ) {
		return $is_widget || in_array( $child, $atomic_box, true );
	}
	return false;   // a widget holds no elements
}


/**
 * The ledger: what this bridge has created on this site, newest last.
 *
 * It is a positive list, and it is the ONLY thing /remove will act on. An undo
 * built by diffing against a snapshot deletes whatever a human added between
 * our write and their click — see ~/.claude/rules/undo-removes-only-what-we-made.md.
 */
const SIITE_BRIDGE_LEDGER     = 'siite_bridge_ledger';
const SIITE_BRIDGE_LEDGER_MAX = 300;

function siite_bridge_ledger_add( $entry ) {
	$log   = get_option( SIITE_BRIDGE_LEDGER );
	$log   = is_array( $log ) ? $log : [];
	$entry = array_merge( [
		'stamp' => gmdate( 'Ymd-His' ),
		'actor' => wp_get_current_user()->user_login,
	], $entry );
	$log[] = $entry;
	while ( count( $log ) > SIITE_BRIDGE_LEDGER_MAX ) { array_shift( $log ); }
	update_option( SIITE_BRIDGE_LEDGER, $log, false );
	return $entry;
}

function siite_bridge_ledger_get( $req = null ) {
	$log = get_option( SIITE_BRIDGE_LEDGER );
	$log = is_array( $log ) ? $log : [];
	if ( $req && $req->get_param( 'post' ) ) {
		$post = (int) $req->get_param( 'post' );
		$log  = array_values( array_filter( $log, function ( $e ) use ( $post ) {
			return (int) ( $e['post'] ?? 0 ) === $post;
		} ) );
	}
	return array_reverse( $log );
}

/** Did this bridge create that element, and is it still on that document? */
function siite_bridge_ledger_made( $post, $id ) {
	foreach ( siite_bridge_ledger_get() as $e ) {
		if ( (int) ( $e['post'] ?? 0 ) !== (int) $post ) { continue; }
		if ( in_array( $id, (array) ( $e['created'] ?? [] ), true ) ) { return $e; }
	}
	return null;
}


/**
 * Put a subtree into a document, and write it if this is not a dry run.
 *
 * Every structural route funnels through here, so the id delta is declared
 * once and checked once: what came back must be exactly the ids that were
 * there before plus the ones we said we were adding, minus the ones we said we
 * were taking away. A structural route that quietly rewrote a paragraph, or a
 * text correction that grew a section, both fail this.
 */
function siite_bridge_structure_write( $id, $tree, $expect_ids, $dry_run, $entry ) {
	// SORT_STRING, not the default. An Elementor id is seven hex characters, and
	// a hex id like "2663e85" is a valid PHP numeric string in exponential
	// notation — so the default comparison sorts it as 2663 x 10^85 against
	// ordinary strings. Two arrays holding exactly the same ids then came out
	// in different orders and this check failed with nothing in either diff.
	$got = siite_bridge_id_list( $tree );
	$expect_ids = array_values( array_unique( $expect_ids ) );
	sort( $expect_ids, SORT_STRING );
	sort( $got, SORT_STRING );
	if ( $expect_ids !== $got ) {
		return new WP_Error( 'siite_id_delta', 'The document did not change the way this route declared', [
			'status'     => 500,
			'unexpected' => array_values( array_diff( $got, $expect_ids ) ),
			'lost'       => array_values( array_diff( $expect_ids, $got ) ),
			'counted'    => [ 'expected' => count( $expect_ids ), 'got' => count( $got ) ],
		] );
	}

	$result = array_merge( $entry, [
		'post'    => $id,
		'dry_run' => (bool) $dry_run,
		'widgets' => count( siite_bridge_flatten( $tree ) ),
		'elements'=> count( $got ),
	] );

	if ( $dry_run ) {
		$result['written'] = false;
		return $result;
	}

	$stamp = siite_bridge_backup( $id );
	$wrote = siite_bridge_write_data( $id, $tree );
	if ( is_wp_error( $wrote ) ) { return $wrote; }
	if ( ! $wrote['ok'] ) {
		siite_bridge_restore_stamp( $id, $stamp );
		return new WP_Error( 'siite_verify_failed',
			'Readback mismatch; the backup was restored', [ 'status' => 500 ] );
	}

	$result['written']   = true;
	$result['backup']    = $stamp;
	$result['kept_code'] = $wrote['kept_code'];
	$result['caches']    = siite_bridge_flush( $id );
	$result['ledger']    = siite_bridge_ledger_add( [
		'post'    => $id,
		'route'   => $entry['route'] ?? 'structure',
		'created' => $entry['created'] ?? [],
		'removed' => $entry['removed'] ?? [],
		'note'    => $entry['note'] ?? '',
		'backup'  => $stamp,
	] );
	return $result;
}


/**
 * Where a subtree goes, resolved against the document as it is now.
 *
 * Returns [ $children_path, $index, $parent_type ] or a WP_Error. `after` and
 * `before` are relative to a sibling; `append` and `prepend` are inside the
 * named element; no anchor at all means the end of the document.
 */
function siite_bridge_anchor( $tree, $anchor ) {
	$mode = (string) ( $anchor['mode'] ?? 'append' );
	$id   = (string) ( $anchor['id'] ?? '' );

	if ( $id === '' ) {
		if ( ! in_array( $mode, [ 'append', 'prepend' ], true ) ) {
			return new WP_Error( 'siite_bad_anchor',
				"Anchor mode '$mode' needs an element id", [ 'status' => 400 ] );
		}
		return [ [], $mode === 'prepend' ? 0 : count( $tree ), '' ];
	}

	$path = siite_bridge_path_of( $tree, $id );
	if ( $path === null ) {
		return new WP_Error( 'siite_no_anchor', "Element $id is not on this document", [ 'status' => 404 ] );
	}
	$node = siite_bridge_node_ref( $tree, $path );

	if ( $mode === 'after' || $mode === 'before' ) {
		$parent_path = $path;
		$index       = (int) array_pop( $parent_path );
		$parent_type = $parent_path
			? (string) ( siite_bridge_node_ref( $tree, $parent_path )['elType'] ?? '' )
			: '';
		return [ $parent_path, $mode === 'after' ? $index + 1 : $index, $parent_type ];
	}
	if ( $mode === 'append' || $mode === 'prepend' ) {
		$kids = (array) ( $node['elements'] ?? [] );
		return [ $path, $mode === 'prepend' ? 0 : count( $kids ),
		         (string) ( $node['elType'] ?? '' ) ];
	}
	return new WP_Error( 'siite_bad_anchor', "Unknown anchor mode '$mode'", [ 'status' => 400 ] );
}


/**
 * Put a subtree into a document. The plain function both routes call.
 *
 * Not driven off the WP_REST_Request: /duplicate used to build a second
 * request object and hand it to the route, which does not work — set_body()
 * clears the parsed JSON and get_json_params() does not re-parse it, so the
 * copy arrived with no body at all. Two callers, one function, no request
 * objects passed around.
 */
function siite_bridge_insert_tree( $id, $sub, $anchor, $dry_run, $entry = [] ) {
	if ( ! is_array( $sub ) || ! $sub ) {
		return new WP_Error( 'siite_no_tree', 'Nothing to insert', [ 'status' => 400 ] );
	}
	$tree = siite_bridge_tree( $id );
	if ( ! $tree ) {
		return new WP_Error( 'siite_no_elementor', "Post $id has no Elementor data", [ 'status' => 404 ] );
	}

	$where = siite_bridge_anchor( $tree, (array) $anchor );
	if ( is_wp_error( $where ) ) { return $where; }
	list( $parent_path, $index, $parent_type ) = $where;

	// The format of the document decides what a new element may be. A flexbox
	// container dropped into a section/column page stores fine and renders as
	// an empty band, which is the kind of failure nobody reports as a bug —
	// they just say the section "didn't come out right".
	$doc_format = siite_bridge_format( $tree );
	$sub_format = siite_bridge_format( $sub );
	if ( $doc_format !== 'empty' && $sub_format !== 'empty'
		&& $sub_format !== $doc_format && $doc_format !== 'mixed' ) {
		return new WP_Error( 'siite_format_mismatch',
			"This document is built as '$doc_format' and the subtree is '$sub_format'. "
			. "Build it in the document's own format instead of converting it here.",
			[ 'status' => 409, 'document' => $doc_format, 'subtree' => $sub_format ] );
	}

	foreach ( $sub as $n ) {
		$child = (string) ( $n['elType'] ?? '' );
		if ( ! siite_bridge_may_contain( $parent_type, $child ) ) {
			return new WP_Error( 'siite_bad_nesting',
				"A '$child' cannot sit inside " . ( $parent_type ?: 'the document root' ) . '.',
				[ 'status' => 409 ] );
		}
	}

	$before  = siite_bridge_id_list( $tree );
	$taken   = siite_bridge_ids( $tree );
	$created = [];
	try {
		siite_bridge_remint( $sub, $taken, $created );
	} catch ( \RuntimeException $e ) {
		return new WP_Error( 'siite_no_ids', $e->getMessage(), [ 'status' => 500 ] );
	}

	$kids =& siite_bridge_children_ref( $tree, $parent_path );
	array_splice( $kids, $index, 0, $sub );
	unset( $kids );

	return siite_bridge_structure_write( $id, $tree, array_merge( $before, $created ),
		$dry_run, array_merge( [
			'route'   => 'insert',
			'created' => $created,
			'anchor'  => $anchor,
			'format'  => $doc_format,
		], $entry ) );
}


/** POST /insert/<id> — a new subtree at a named place. */
function siite_bridge_insert( $req ) {
	$body = $req->get_json_params();
	return siite_bridge_insert_tree(
		(int) $req['id'],
		$body['tree'] ?? null,
		$body['anchor'] ?? [],
		! empty( $body['dry_run'] ),
		[ 'note' => (string) ( $body['note'] ?? '' ) ]
	);
}


/** POST /duplicate/<id> — copy an element, from here or from another document. */
function siite_bridge_duplicate( $req ) {
	$id   = (int) $req['id'];
	$body = $req->get_json_params();
	$src  = (string) ( $body['element'] ?? '' );
	$from = (int) ( $body['from'] ?? $id );
	if ( $src === '' ) {
		return new WP_Error( 'siite_no_element', 'Body must name an "element" to copy', [ 'status' => 400 ] );
	}
	if ( $from !== $id && ! current_user_can( 'edit_post', $from ) ) {
		return new WP_Error( 'siite_no_source', "Not allowed to read post $from", [ 'status' => 403 ] );
	}

	$source = $from === $id ? siite_bridge_tree( $id ) : siite_bridge_tree( $from );
	if ( ! $source ) {
		return new WP_Error( 'siite_no_elementor', "Post $from has no Elementor data", [ 'status' => 404 ] );
	}
	$path = siite_bridge_path_of( $source, $src );
	if ( $path === null ) {
		return new WP_Error( 'siite_no_element', "Element $src is not on post $from", [ 'status' => 404 ] );
	}

	$node = siite_bridge_node_ref( $source, $path );

	// The ids of the thing being copied, in the order remint() will walk it.
	// Both siite_bridge_ids() and siite_bridge_remint() are depth-first
	// pre-order, so zipping the two lists gives source id -> new id. Without
	// that map a copy is unusable until somebody re-reads the page: the copy's
	// widgets have ids nobody has seen, so nothing can be said about them in
	// the same breath as making the copy.
	$source_ids = siite_bridge_id_list( [ $node ] );

	$out = siite_bridge_insert_tree( $id, [ $node ],
		$body['anchor'] ?? [], ! empty( $body['dry_run'] ), [
			'route'  => 'duplicate',
			'note'   => (string) ( $body['note'] ?? '' ),
			'copied' => [ 'post' => $from, 'element' => $src ],
		] );
	if ( ! is_wp_error( $out ) && ! empty( $out['created'] ) ) {
		$out['map'] = array_combine(
			array_slice( $source_ids, 0, count( $out['created'] ) ),
			$out['created'] );
	}
	return $out;
}


/** POST /move/<id> — the same elements, in a different order. */
function siite_bridge_move( $req ) {
	$id   = (int) $req['id'];
	$body = $req->get_json_params();
	$what = (string) ( $body['element'] ?? '' );
	$tree = siite_bridge_tree( $id );
	if ( ! $tree ) { return new WP_Error( 'siite_no_elementor', "Post $id has no Elementor data", [ 'status' => 404 ] ); }

	$path = siite_bridge_path_of( $tree, $what );
	if ( $path === null ) {
		return new WP_Error( 'siite_no_element', "Element $what is not on this document", [ 'status' => 404 ] );
	}
	$before = siite_bridge_id_list( $tree );

	$anchor = (array) ( $body['anchor'] ?? [] );
	$target = (string) ( $anchor['id'] ?? '' );
	// Moving something into its own subtree detaches the whole branch from the
	// document and loses it. It is also the one mistake an agent reliably makes
	// when it is reordering by eye.
	if ( $target !== '' ) {
		$node = siite_bridge_node_ref( $tree, $path );
		if ( $target === $what || in_array( $target, siite_bridge_id_list( [ $node ] ), true ) ) {
			return new WP_Error( 'siite_move_into_self',
				"$what cannot be moved inside itself", [ 'status' => 409 ] );
		}
	}

	// Detach first, then resolve the anchor against the tree as it is without
	// the moved element — otherwise "after the section above me" lands one
	// place off, because the indexes shifted when the element left.
	$parent_path = $path;
	$index       = (int) array_pop( $parent_path );
	$kids        =& siite_bridge_children_ref( $tree, $parent_path );
	$moved       = array_splice( $kids, $index, 1 );
	unset( $kids );

	$where = siite_bridge_anchor( $tree, $anchor );
	if ( is_wp_error( $where ) ) { return $where; }
	list( $to_path, $to_index, $parent_type ) = $where;

	if ( ! siite_bridge_may_contain( $parent_type, (string) ( $moved[0]['elType'] ?? '' ) ) ) {
		return new WP_Error( 'siite_bad_nesting',
			"A '" . ( $moved[0]['elType'] ?? '?' ) . "' cannot sit inside "
			. ( $parent_type ?: 'the document root' ) . '.', [ 'status' => 409 ] );
	}

	$dest =& siite_bridge_children_ref( $tree, $to_path );
	array_splice( $dest, $to_index, 0, $moved );
	unset( $dest );

	return siite_bridge_structure_write( $id, $tree, $before, ! empty( $body['dry_run'] ), [
		'route'   => 'move',
		'created' => [],
		'note'    => (string) ( $body['note'] ?? '' ),
		'moved'   => $what,
	] );
}


/**
 * POST /remove/<id> — take out an element THIS BRIDGE created.
 *
 * Never anything else, and never on the strength of a snapshot. The ledger is
 * the positive list; an element that is not in it is somebody's own work, and
 * the answer is that it has to be removed in Elementor by a person.
 */
function siite_bridge_remove( $req ) {
	$id   = (int) $req['id'];
	$body = $req->get_json_params();
	$what = (string) ( $body['element'] ?? '' );
	$tree = siite_bridge_tree( $id );
	if ( ! $tree ) { return new WP_Error( 'siite_no_elementor', "Post $id has no Elementor data", [ 'status' => 404 ] ); }

	// Two different things wear the word "remove", and conflating them was a
	// mistake. Undo — taking back something the bridge put there — must work off
	// the ledger and nothing else, or it deletes whatever a person added in the
	// meantime (~/.claude/rules/undo-removes-only-what-we-made.md). But deleting
	// a section BECAUSE SOMEBODY ASKED is an ordinary edit, and refusing it just
	// meant the answer to "remove the footer" was "do it yourself in Elementor".
	// So: the ledger path is the default, and touching the client's own content
	// takes an explicit "anything": true, which the app only sends from a
	// confirmed, human-pressed delete.
	$made = siite_bridge_ledger_made( $id, $what );
	$ours = (bool) $made;
	if ( ! $ours && empty( $body['anything'] ) ) {
		return new WP_Error( 'siite_not_ours',
			"$what was not created by this bridge. Send \"anything\": true to remove "
			. 'the client\'s own element, which takes a backup first.',
			[ 'status' => 409 ] );
	}

	$path = siite_bridge_path_of( $tree, $what );
	if ( $path === null ) {
		return [ 'post' => $id, 'written' => false, 'skipped' => $what,
		         'why' => 'already gone' ];
	}

	$node    = siite_bridge_node_ref( $tree, $path );
	$removed = siite_bridge_id_list( [ $node ] );
	$before  = siite_bridge_id_list( $tree );
	$expect  = array_values( array_diff( $before, $removed ) );

	$parent_path = $path;
	$index       = (int) array_pop( $parent_path );
	$kids        =& siite_bridge_children_ref( $tree, $parent_path );
	array_splice( $kids, $index, 1 );
	unset( $kids );

	return siite_bridge_structure_write( $id, $tree, $expect, ! empty( $body['dry_run'] ), [
		'route'   => 'remove',
		'created' => [],
		'removed' => $removed,
		'ours'    => $ours,
		'note'    => (string) ( $body['note'] ?? '' ),
		'was'     => $made['stamp'] ?? null,
		// The whole subtree, so the ledger can put back a section that was the
		// client's own. A backup of the document exists either way, but a
		// document-wide rollback also undoes everything else done since.
		'subtree' => $ours ? null : $node,
	] );
}


/* ------------------------------------------------- repeater rows (1.5.0) --- */

/**
 * Add, remove or reorder a row in an Elementor repeater.
 *
 * A repeater is how Elementor stores every list: icon lists, tabs, accordions,
 * testimonials, slides, pricing tables. Correcting a row that exists was always
 * possible through the ordinary dot-path (`icon_list.0.text`), but there was no
 * way to add a fourth row — and "add another line to the price list" is about as
 * ordinary as a request gets.
 *
 * A new row is CLONED from an existing one and then overwritten, never built
 * from nothing. A row carries far more than its text — the icon, its colour,
 * its size, the per-row settings — and a row assembled from scratch renders
 * without any of it, next to three rows that have it.
 *
 * Body: { "element": "prisl01", "key": "icon_list",
 *         "op": "add",    "from_row": 2, "at": 3, "values": { "text": "…" } }
 *       { "element": "prisl01", "key": "icon_list", "op": "remove", "row": 0 }
 *       { "element": "prisl01", "key": "icon_list", "op": "move", "row": 2, "at": 0 }
 */
function siite_bridge_repeater( $req ) {
	$id   = (int) $req['id'];
	$body = $req->get_json_params();
	$eid  = (string) ( $body['element'] ?? '' );
	$key  = (string) ( $body['key'] ?? '' );
	$op   = (string) ( $body['op'] ?? '' );
	if ( $eid === '' || $key === '' ) {
		return new WP_Error( 'siite_repeater_args',
			'Body must carry "element" and "key"', [ 'status' => 400 ] );
	}
	if ( ! in_array( $op, [ 'add', 'remove', 'move' ], true ) ) {
		return new WP_Error( 'siite_repeater_op',
			'"op" must be add, remove or move', [ 'status' => 400 ] );
	}
	if ( strpos( $key, '_' ) === 0 ) {
		return new WP_Error( 'siite_private_key', 'Private keys are not writable',
			[ 'status' => 400 ] );
	}

	$tree = siite_bridge_tree( $id );
	if ( ! $tree ) {
		return new WP_Error( 'siite_no_elementor', "Post $id has no Elementor data", [ 'status' => 404 ] );
	}
	$path = siite_bridge_path_of( $tree, $eid );
	if ( $path === null ) {
		return new WP_Error( 'siite_no_element', "Element $eid is not on this document", [ 'status' => 404 ] );
	}
	$node = siite_bridge_node_ref( $tree, $path );

	$root = explode( '.', $key )[0];
	if ( isset( $node['settings']['__dynamic__'][ $root ] )
		|| ! empty( $node['settings']['__globals__'][ $root ] ) ) {
		return new WP_Error( 'siite_bound',
			'This list is fed from somewhere else; editing it here changes nothing',
			[ 'status' => 409 ] );
	}

	$rows = siite_bridge_path_get( $node['settings'] ?? [], $key );
	if ( ! is_array( $rows ) || ( $rows && ! is_array( reset( $rows ) ) ) ) {
		return new WP_Error( 'siite_not_repeater',
			"'$key' on $eid is not a list of rows", [ 'status' => 409 ] );
	}
	$rows  = array_values( $rows );
	$count = count( $rows );
	$was   = $rows;

	if ( $op === 'add' ) {
		$from = isset( $body['from_row'] ) ? (int) $body['from_row'] : $count - 1;
		if ( $count === 0 ) {
			return new WP_Error( 'siite_empty_repeater',
				"'$key' has no row to copy the shape from; add the first one in Elementor",
				[ 'status' => 409 ] );
		}
		if ( ! isset( $rows[ $from ] ) ) {
			return new WP_Error( 'siite_no_row',
				"Row $from does not exist (there are $count)", [ 'status' => 404 ] );
		}
		$row = $rows[ $from ];
		foreach ( (array) ( $body['values'] ?? [] ) as $field => $value ) {
			if ( strpos( (string) $field, '_' ) === 0 ) { continue; }
			siite_bridge_path_set( $row, (string) $field, $value );
		}
		// Elementor keys a repeater row by its own _id and dedupes on it, so a
		// clone that kept the original's id is dropped on the next save.
		$taken = [];
		foreach ( $rows as $r ) { if ( ! empty( $r['_id'] ) ) { $taken[ $r['_id'] ] = true; } }
		$row['_id'] = siite_bridge_mint_id( $taken );

		$at = isset( $body['at'] ) ? max( 0, min( $count, (int) $body['at'] ) ) : $count;
		array_splice( $rows, $at, 0, [ $row ] );
		$note = "row added at $at, cloned from $from";
	} elseif ( $op === 'remove' ) {
		$at = (int) ( $body['row'] ?? -1 );
		if ( ! isset( $rows[ $at ] ) ) {
			return new WP_Error( 'siite_no_row',
				"Row $at does not exist (there are $count)", [ 'status' => 404 ] );
		}
		if ( $count === 1 ) {
			return new WP_Error( 'siite_last_row',
				'That is the only row left. An empty list renders as an empty block; '
				. 'remove the widget in Elementor instead.', [ 'status' => 409 ] );
		}
		array_splice( $rows, $at, 1 );
		$note = "row $at removed";
	} else {
		$at   = (int) ( $body['row'] ?? -1 );
		$to   = (int) ( $body['at'] ?? 0 );
		if ( ! isset( $rows[ $at ] ) ) {
			return new WP_Error( 'siite_no_row',
				"Row $at does not exist (there are $count)", [ 'status' => 404 ] );
		}
		$moved = array_splice( $rows, $at, 1 );
		array_splice( $rows, max( 0, min( count( $rows ), $to ) ), 0, $moved );
		$note = "row $at moved to $to";
	}

	siite_bridge_path_set( $node['settings'], $key, $rows );

	// Put the mutated node back into the tree.
	$target =& siite_bridge_node_ref( $tree, $path );
	$target = $node;
	unset( $target );

	$summary = function ( $list ) {
		return array_map( function ( $r ) {
			foreach ( [ 'text', 'title', 'tab_title', 'name', 'content' ] as $k ) {
				if ( ! empty( $r[ $k ] ) && is_string( $r[ $k ] ) ) {
					return mb_substr( wp_strip_all_tags( $r[ $k ] ), 0, 70 );
				}
			}
			return '(række)';
		}, $list );
	};

	$result = [
		'id'      => $id,
		'element' => $eid,
		'key'     => $key,
		'op'      => $op,
		'note'    => $note,
		'was'     => $summary( $was ),
		'now'     => $summary( $rows ),
		'rows'    => count( $rows ),
		'dry_run' => ! empty( $body['dry_run'] ),
	];
	if ( ! empty( $body['dry_run'] ) ) {
		$result['written'] = false;
		return $result;
	}

	$stamp = siite_bridge_backup( $id );
	$wrote = siite_bridge_write_data( $id, $tree );
	if ( is_wp_error( $wrote ) ) { return $wrote; }
	if ( ! $wrote['ok'] ) {
		siite_bridge_restore_stamp( $id, $stamp );
		return new WP_Error( 'siite_verify_failed',
			'Readback mismatch; the backup was restored', [ 'status' => 500 ] );
	}
	$result['written'] = true;
	$result['backup']  = $stamp;
	$result['caches']  = siite_bridge_flush( $id );
	siite_bridge_ledger_add( [ 'post' => $id, 'route' => 'repeater',
	                           'created' => [], 'note' => $note, 'backup' => $stamp ] );
	return $result;
}


/* ------------------------------------------------- menus, pages (1.3.0) --- */

/**
 * Every registered nav menu, its items, and which theme location it is shown
 * in. Read-only, and the shape is what the app needs to say "this page is not
 * in any menu yet" without a second call.
 */
function siite_bridge_menus() {
	$locations = get_nav_menu_locations();
	$by_menu   = [];
	foreach ( $locations as $slot => $menu_id ) {
		$by_menu[ (int) $menu_id ][] = $slot;
	}

	$out = [];
	foreach ( wp_get_nav_menus() as $menu ) {
		$items = [];
		foreach ( (array) wp_get_nav_menu_items( $menu->term_id ) as $item ) {
			$items[] = [
				'item_id'   => (int) $item->ID,
				'title'     => $item->title,
				'url'       => $item->url,
				'object'    => $item->object,
				'object_id' => (int) $item->object_id,
				'parent'    => (int) $item->menu_item_parent,
				'order'     => (int) $item->menu_order,
			];
		}
		$out[] = [
			'menu_id'   => (int) $menu->term_id,
			'name'      => $menu->name,
			'slug'      => $menu->slug,
			'locations' => $by_menu[ (int) $menu->term_id ] ?? [],
			'count'     => count( $items ),
			'items'     => $items,
		];
	}
	return $out;
}

/** The item ids of a menu, as they are right now. Used as the undo record. */
function siite_bridge_menu_ids( $menu_id ) {
	$ids = [];
	foreach ( (array) wp_get_nav_menu_items( $menu_id ) as $item ) {
		$ids[] = (int) $item->ID;
	}
	return $ids;
}

/**
 * Add ONE item to a menu. There is deliberately no route that removes or
 * reorders an item: an automation that can empty a client's navigation is a
 * different risk class from one that can append to it, and appending is the
 * whole of what this track needs.
 *
 * Body: { "menu": 12, "post": 2419 }            an existing page
 *       { "menu": 12, "title": "…", "url": "…" }  a plain link
 *       optional: "parent" (item_id), "position" (menu_order), "dry_run"
 *
 * The menu's item ids are stored as an option before the write, so
 * /menu-restore can put the menu back exactly as it was.
 */
/**
 * The menu's items in the order they are shown, as ids.
 *
 * Top level only when $top_only: a positioned insert reasons about siblings,
 * and a child item's menu_order sits in the same flat sequence as its parent's,
 * so mixing the two makes "between Priser and Kontakt" land somewhere nobody
 * asked for.
 */
function siite_bridge_menu_order( $menu_id, $parent = 0 ) {
	$rows = [];
	foreach ( (array) wp_get_nav_menu_items( $menu_id ) as $item ) {
		if ( (int) $item->menu_item_parent !== (int) $parent ) { continue; }
		$rows[] = (int) $item->ID;
	}
	return $rows;
}


/**
 * Write a menu's order back as 1..n.
 *
 * Directly on menu_order via wp_update_post(), not through
 * wp_update_nav_menu_item(): that function rebuilds the item from the args it
 * is given, so calling it to move something means restating every field the
 * item had, and anything forgotten is silently blanked.
 *
 * This is also why "menu-item-position" alone does not work. WordPress stores
 * whatever number it is handed without touching the siblings, so inserting at
 * position 2 in a menu that already has a 2 gives two items claiming the same
 * slot and an order that depends on the id tiebreak. Inserting BETWEEN two
 * items means renumbering the run.
 */
function siite_bridge_menu_renumber( $ordered_ids ) {
	$done = [];
	foreach ( array_values( $ordered_ids ) as $i => $id ) {
		wp_update_post( [ 'ID' => (int) $id, 'menu_order' => $i + 1 ] );
		$done[ (int) $id ] = $i + 1;
	}
	return $done;
}


/** Where a new or moved item should sit, as an index into the sibling list. */
function siite_bridge_menu_slot( $siblings, $body, $skip = 0 ) {
	$ids = array_values( array_filter( $siblings,
		function ( $id ) use ( $skip ) { return (int) $id !== (int) $skip; } ) );

	if ( ! empty( $body['after'] ) ) {
		$at = array_search( (int) $body['after'], $ids, true );
		if ( $at === false ) {
			return new WP_Error( 'siite_no_menu_item',
				"Menu item {$body['after']} is not in this menu", [ 'status' => 404 ] );
		}
		return $at + 1;
	}
	if ( ! empty( $body['before'] ) ) {
		$at = array_search( (int) $body['before'], $ids, true );
		if ( $at === false ) {
			return new WP_Error( 'siite_no_menu_item',
				"Menu item {$body['before']} is not in this menu", [ 'status' => 404 ] );
		}
		return $at;
	}
	if ( isset( $body['position'] ) ) {
		// 1-based, the way it reads in wp-admin and the way anybody says it.
		return max( 0, min( count( $ids ), (int) $body['position'] - 1 ) );
	}
	return count( $ids );
}


function siite_bridge_menu_add( $req ) {
	$body    = $req->get_json_params();
	$menu_id = (int) ( $body['menu'] ?? 0 );
	$menu    = $menu_id ? wp_get_nav_menu_object( $menu_id ) : null;
	if ( ! $menu ) {
		return new WP_Error( 'siite_no_menu', 'Unknown menu', [ 'status' => 404 ] );
	}

	$post_id = (int) ( $body['post'] ?? 0 );
	$title   = trim( (string) ( $body['title'] ?? '' ) );
	$url     = trim( (string) ( $body['url'] ?? '' ) );

	if ( ! $post_id && ( $title === '' || $url === '' ) ) {
		return new WP_Error( 'siite_menu_target',
			'Give either "post", or both "title" and "url"', [ 'status' => 400 ] );
	}
	if ( $post_id && ! get_post( $post_id ) ) {
		return new WP_Error( 'siite_no_post', "Post $post_id does not exist", [ 'status' => 404 ] );
	}

	// Already there? Say so instead of adding a duplicate nobody asked for.
	foreach ( (array) wp_get_nav_menu_items( $menu->term_id ) as $item ) {
		$same = $post_id ? ( (int) $item->object_id === $post_id && $item->type === 'post_type' )
		                 : ( untrailingslashit( $item->url ) === untrailingslashit( $url ) );
		if ( $same ) {
			return [
				'added'    => false,
				'why'      => 'already-in-menu',
				'item_id'  => (int) $item->ID,
				'menu'     => $menu->name,
			];
		}
	}

	$args = $post_id
		? [
			'menu-item-object-id' => $post_id,
			'menu-item-object'    => get_post_type( $post_id ),
			'menu-item-type'      => 'post_type',
			'menu-item-title'     => $title !== '' ? $title : get_the_title( $post_id ),
			'menu-item-status'    => 'publish',
		]
		: [
			'menu-item-type'   => 'custom',
			'menu-item-title'  => $title,
			'menu-item-url'    => esc_url_raw( $url ),
			'menu-item-status' => 'publish',
		];
	$parent = (int) ( $body['parent'] ?? 0 );
	if ( $parent ) { $args['menu-item-parent-id'] = $parent; }

	// Where it goes, worked out against the siblings it will actually sit
	// among. "after"/"before" take a menu ITEM id from /menus; "position" is
	// 1-based the way wp-admin shows it.
	$siblings = siite_bridge_menu_order( $menu->term_id, $parent );
	$slot     = siite_bridge_menu_slot( $siblings, $body );
	if ( is_wp_error( $slot ) ) { return $slot; }

	$titles = [];
	foreach ( (array) wp_get_nav_menu_items( $menu->term_id ) as $item ) {
		$titles[ (int) $item->ID ] = $item->title;
	}
	$preview = array_map( function ( $id ) use ( $titles ) { return $titles[ $id ] ?? $id; }, $siblings );
	array_splice( $preview, $slot, 0, [ ( $args['menu-item-title'] ?? '?' ) . '  <- ny' ] );

	if ( ! empty( $body['dry_run'] ) ) {
		return [
			'added'     => false,
			'why'       => 'dry-run',
			'would_add' => $args,
			'menu'      => $menu->name,
			'slot'      => $slot + 1,
			'order'     => $preview,
		];
	}

	$before  = siite_bridge_menu_ids( $menu->term_id );
	$orders  = [];
	foreach ( (array) wp_get_nav_menu_items( $menu->term_id ) as $item ) {
		$orders[ (int) $item->ID ] = (int) $item->menu_order;
	}
	$stamp   = gmdate( 'Ymd-His' );
	$item_id = wp_update_nav_menu_item( $menu->term_id, 0, $args );
	if ( is_wp_error( $item_id ) ) { return $item_id; }

	// Slot it in and renumber the run. Without this the new item keeps the
	// order WordPress gave it — the end — and "between Priser and Kontakt"
	// silently becomes "after Kontakt".
	$wanted = $siblings;
	array_splice( $wanted, $slot, 0, [ (int) $item_id ] );
	siite_bridge_menu_renumber( $wanted );

	// Undo is an allowlist of what THIS bridge created, never a diff against a
	// snapshot. A snapshot-diff deletes everything that is not in the stored
	// list, which includes every item a person added in wp-admin after the
	// snapshot was taken — so the undo for our one item would quietly take
	// their three with it. Each added item is recorded by id instead, and
	// /menu-restore removes only ids on that list.
	$mine   = get_option( 'siite_bridge_menu_mine_' . $menu->term_id );
	$mine   = is_array( $mine ) ? $mine : [];
	// The orders as they were, so undoing the insert also puts the run back to
	// 1..n instead of leaving the gap our item used to fill.
	$mine[] = [ 'item' => (int) $item_id, 'stamp' => $stamp,
	            'was' => count( $before ), 'orders' => $orders ];
	update_option( 'siite_bridge_menu_mine_' . $menu->term_id, $mine, false );

	$now = [];
	foreach ( (array) wp_get_nav_menu_items( $menu->term_id ) as $item ) {
		if ( (int) $item->menu_item_parent !== $parent ) { continue; }
		$now[] = $item->title;
	}

	return [
		'added'   => true,
		'item_id' => (int) $item_id,
		'menu'    => $menu->name,
		'menu_id' => (int) $menu->term_id,
		'backup'  => $stamp,
		'slot'    => $slot + 1,
		'order'   => $now,
		'before'  => count( $before ),
		'after'   => count( siite_bridge_menu_ids( $menu->term_id ) ),
	];
}

/**
 * POST /menu-move — put an existing item somewhere else in its own menu.
 *
 * Reordering was left out of 1.3.0 on the reasoning that a menu is the
 * client's navigation and we only ever append to it. That was the wrong line:
 * appending and then telling somebody to drag the item up in wp-admin is not
 * "not touching their menu", it is doing half the job. Nothing is deleted, no
 * item changes its target, and the order it had is recorded so it can be put
 * straight back.
 *
 * Body: { "menu": 12, "item": 247, "after": 246 }
 *       { "menu": 12, "item": 247, "before": 248 }
 *       { "menu": 12, "item": 247, "position": 2 }
 */
function siite_bridge_menu_move( $req ) {
	$body    = $req->get_json_params();
	$menu_id = (int) ( $body['menu'] ?? 0 );
	$item_id = (int) ( $body['item'] ?? 0 );
	$menu    = $menu_id ? wp_get_nav_menu_object( $menu_id ) : null;
	if ( ! $menu ) {
		return new WP_Error( 'siite_no_menu', 'Unknown menu', [ 'status' => 404 ] );
	}

	$item = $item_id ? get_post( $item_id ) : null;
	if ( ! $item || $item->post_type !== 'nav_menu_item' ) {
		return new WP_Error( 'siite_no_menu_item', "Item $item_id is not a menu item",
			[ 'status' => 404 ] );
	}
	$all = siite_bridge_menu_ids( $menu->term_id );
	if ( ! in_array( $item_id, $all, true ) ) {
		return new WP_Error( 'siite_no_menu_item', "Item $item_id is not in this menu",
			[ 'status' => 404 ] );
	}

	$parent   = (int) get_post_meta( $item_id, '_menu_item_menu_item_parent', true );
	$siblings = siite_bridge_menu_order( $menu->term_id, $parent );
	$slot     = siite_bridge_menu_slot( $siblings, $body, $item_id );
	if ( is_wp_error( $slot ) ) { return $slot; }

	$titles = [];
	$orders = [];
	foreach ( (array) wp_get_nav_menu_items( $menu->term_id ) as $row ) {
		$titles[ (int) $row->ID ] = $row->title;
		$orders[ (int) $row->ID ] = (int) $row->menu_order;
	}

	$wanted = array_values( array_filter( $siblings,
		function ( $id ) use ( $item_id ) { return $id !== $item_id; } ) );
	array_splice( $wanted, $slot, 0, [ $item_id ] );
	$named = array_map( function ( $id ) use ( $titles, $item_id ) {
		return ( $titles[ $id ] ?? $id ) . ( $id === $item_id ? '  <- flyttet' : '' );
	}, $wanted );

	if ( ! empty( $body['dry_run'] ) ) {
		return [ 'moved' => false, 'why' => 'dry-run', 'menu' => $menu->name,
		         'slot' => $slot + 1, 'order' => $named,
		         'was' => array_map( function ( $id ) use ( $titles ) {
			         return $titles[ $id ] ?? $id; }, $siblings ) ];
	}

	siite_bridge_menu_renumber( $wanted );

	$mine   = get_option( 'siite_bridge_menu_moved_' . $menu->term_id );
	$mine   = is_array( $mine ) ? $mine : [];
	$mine[] = [ 'item' => $item_id, 'stamp' => gmdate( 'Ymd-His' ), 'orders' => $orders ];
	update_option( 'siite_bridge_menu_moved_' . $menu->term_id, $mine, false );

	return [ 'moved' => true, 'item_id' => $item_id, 'menu' => $menu->name,
	         'menu_id' => (int) $menu->term_id, 'slot' => $slot + 1,
	         'order' => array_map( function ( $id ) use ( $titles ) {
		         return $titles[ $id ] ?? $id; }, $wanted ) ];
}


/** POST /menu-move-undo — put the order back the way the last move found it. */
function siite_bridge_menu_move_undo( $req ) {
	$menu_id = (int) ( $req->get_json_params()['menu'] ?? 0 );
	$mine    = get_option( 'siite_bridge_menu_moved_' . $menu_id );
	$mine    = is_array( $mine ) ? $mine : [];
	if ( ! $mine ) {
		return new WP_Error( 'siite_no_menu_backup',
			'This bridge has not moved anything in that menu', [ 'status' => 404 ] );
	}
	$row  = array_pop( $mine );
	$back = [];
	foreach ( (array) ( $row['orders'] ?? [] ) as $id => $order ) {
		// Only items that are still menu items in this menu. One a person has
		// deleted since is skipped and said so, never recreated.
		if ( get_post_type( (int) $id ) === 'nav_menu_item' ) {
			wp_update_post( [ 'ID' => (int) $id, 'menu_order' => (int) $order ] );
			$back[] = (int) $id;
		}
	}
	update_option( 'siite_bridge_menu_moved_' . $menu_id, $mine, false );
	return [ 'restored' => true, 'items' => $back, 'left' => count( $mine ) ];
}


/**
 * Undo: remove the menu items THIS bridge added, newest first, and nothing
 * else. Only ids on the recorded list are considered, each one is checked to
 * still be a nav_menu_item in this menu before it is touched, and an id a
 * person has already deleted by hand is skipped rather than treated as an
 * error.
 *
 * Body: { "menu": 12 }            undo the most recent addition
 *       { "menu": 12, "all": true }  undo every addition this bridge made
 */
function siite_bridge_menu_restore( $req ) {
	$body    = $req->get_json_params();
	$menu_id = (int) ( $body['menu'] ?? 0 );
	$mine    = get_option( 'siite_bridge_menu_mine_' . $menu_id );
	$mine    = is_array( $mine ) ? $mine : [];
	if ( ! $mine ) {
		return new WP_Error( 'siite_no_menu_backup',
			'This bridge has not added anything to that menu', [ 'status' => 404 ] );
	}

	$take = empty( $body['all'] ) ? [ array_pop( $mine ) ] : $mine;
	if ( ! empty( $body['all'] ) ) { $mine = []; }

	$live    = siite_bridge_menu_ids( $menu_id );
	$removed = [];
	$skipped = [];
	foreach ( $take as $row ) {
		$id   = (int) ( $row['item'] ?? 0 );
		$post = $id ? get_post( $id ) : null;
		if ( ! $post || $post->post_type !== 'nav_menu_item' || ! in_array( $id, $live, true ) ) {
			$skipped[] = $id;
			continue;
		}
		wp_delete_post( $id, true );
		$removed[] = $id;
		// Put the run back the way it was found. Deleting our item on its own
		// leaves 1,2,4 behind, which reads as unchanged in wp-admin and sorts
		// fine — until the next insert computes a slot from it.
		foreach ( (array) ( $row['orders'] ?? [] ) as $was_id => $was_order ) {
			if ( get_post_type( (int) $was_id ) === 'nav_menu_item' ) {
				wp_update_post( [ 'ID' => (int) $was_id, 'menu_order' => (int) $was_order ] );
			}
		}
	}
	update_option( 'siite_bridge_menu_mine_' . $menu_id, $mine, false );

	return [
		'restored' => true,
		'removed'  => $removed,
		'skipped'  => $skipped,
		'left'     => count( $mine ),
	];
}

/**
 * Create a page. It is PUBLISHED, because that is what "make me a page" means
 * to the person asking: a draft is an extra step in wp-admin that somebody has
 * to remember, and the page they were told about is not there until they do.
 * The creation itself is already approved by a human in the app before this
 * route is reached, so the client seeing it is the intent, not a surprise.
 *
 * Send "status": "draft" to get the old behaviour for a page that genuinely
 * should be staged first. /publish then takes it live.
 *
 * Body: { "title": "Priser", "slug": "priser", "parent": 0,
 *         "copy_from": 2419,          // clone this page's Elementor layout
 *         "status": "draft",          // optional, default "publish"
 *         "dry_run": true }
 *
 * copy_from is how a new page ends up in the site's own design instead of
 * blank: the Elementor tree of an existing page is duplicated, so the new page
 * is a real page of that archetype from the first second. Its TEXT is then
 * corrected through the ordinary /doc route, which is the only path that has a
 * backup and a verify behind it.
 */
function siite_bridge_page_create( $req ) {
	$body  = $req->get_json_params();
	$title = trim( (string) ( $body['title'] ?? '' ) );
	if ( $title === '' ) {
		return new WP_Error( 'siite_no_title', 'A page needs a title', [ 'status' => 400 ] );
	}

	$slug = sanitize_title( (string) ( $body['slug'] ?? $title ) );
	$copy = (int) ( $body['copy_from'] ?? 0 );
	// Anything other than an explicit "draft" publishes. An unknown value must
	// not quietly stage the page: that is the failure this route just stopped
	// having.
	$status = ( (string) ( $body['status'] ?? 'publish' ) ) === 'draft' ? 'draft' : 'publish';
	if ( $copy && ! get_post( $copy ) ) {
		return new WP_Error( 'siite_no_source', "Page $copy does not exist", [ 'status' => 404 ] );
	}

	// A slug already in use would silently become "priser-2", and the link the
	// person is about to paste somewhere would be wrong. Say it instead.
	// Guarded rather than called outright: if this ever disappears, refusing to
	// create the page is the right failure. Creating it blind would hand back a
	// URL that WordPress had silently turned into "priser-2".
	if ( ! function_exists( 'get_page_by_path' ) ) {
		return new WP_Error( 'siite_no_path_lookup',
			'get_page_by_path is missing, so a slug clash cannot be ruled out',
			[ 'status' => 500 ] );
	}
	$clash = get_page_by_path( $slug, OBJECT, 'page' );
	if ( $clash ) {
		return [
			'created' => false,
			'why'     => 'slug-taken',
			'slug'    => $slug,
			'post'    => (int) $clash->ID,
			'url'     => get_permalink( $clash ),
			'title'   => $clash->post_title,
		];
	}

	if ( ! empty( $body['dry_run'] ) ) {
		return [
			'created'   => false,
			'why'       => 'dry-run',
			'title'     => $title,
			'slug'      => $slug,
			'status'    => $status,
			'copy_from' => $copy ?: null,
			'copy_title'=> $copy ? get_the_title( $copy ) : null,
		];
	}

	$id = wp_insert_post( [
		'post_title'   => $title,
		'post_name'    => $slug,
		'post_type'    => 'page',
		'post_status'  => $status,
		'post_parent'  => (int) ( $body['parent'] ?? 0 ),
		'post_content' => '',
	], true );
	if ( is_wp_error( $id ) ) { return $id; }

	$copied = [];
	if ( $copy ) {
		foreach ( siite_bridge_writable_meta() as $key ) {
			$val = get_post_meta( $copy, $key, true );
			if ( $val === '' || $val === null ) { continue; }
			update_post_meta( $id, $key, wp_slash( is_array( $val ) ? $val : (string) $val ) );
			$copied[] = $key;
		}
		// These two are outside siite_bridge_writable_meta(). That allowlist
		// guards writes to a post that already existed and is somebody's live
		// page; $id here can only be the page wp_insert_post() returned four
		// lines up, in this same request. Do not reuse this block against an
		// id that came in from outside.
		// Without _elementor_edit_mode, Elementor renders the page with the
		// theme's editor instead of the tree that was just copied, and the
		// page looks empty.
		update_post_meta( $id, '_elementor_edit_mode', 'builder' );
		$tpl = get_post_meta( $copy, '_wp_page_template', true );
		if ( $tpl ) { update_post_meta( $id, '_wp_page_template', $tpl ); }
		$copied[] = '_elementor_edit_mode';
		siite_bridge_flush( $id );
	}

	// A page built from scratch rather than copied still has to be an
	// Elementor document, or Elementor renders post_content — which is empty —
	// and the page that was just written looks blank. The three meta keys below
	// are the whole of "this post is an Elementor page"; without them a tree
	// written by /replace is stored correctly and never drawn. Measured on the
	// sandbox 2026-09-12: 15 sections stored, nothing on the page.
	// Default on from 1.13.0: a page the bridge creates is always going to
	// be written with an Elementor tree. Send "elementor": false to opt out.
	if ( ! $copy && ( $body['elementor'] ?? true ) ) {
		update_post_meta( $id, '_elementor_edit_mode', 'builder' );
		update_post_meta( $id, '_elementor_template_type', 'wp-page' );
		if ( defined( 'ELEMENTOR_VERSION' ) ) {
			update_post_meta( $id, '_elementor_version', ELEMENTOR_VERSION );
		}
		$tpl = (string) ( $body['page_template'] ?? '' );
		if ( $tpl !== '' ) { update_post_meta( $id, '_wp_page_template', $tpl ); }
		$copied[] = '_elementor_edit_mode';
		$copied[] = '_elementor_template_type';
		siite_bridge_flush( $id );
	}

	siite_bridge_ledger_add( [ 'post' => (int) $id, 'route' => 'page', 'created' => [ 'page:' . $id ],
	                           'note' => "created page $slug" ] );

	return [
		'created'  => true,
		'post'     => (int) $id,
		'title'    => $title,
		'slug'     => $slug,
		'status'   => $status,
		'url'      => get_permalink( $id ),
		'edit_url' => admin_url( "post.php?post=$id&action=edit" ),
		'copied'   => $copied,
		'widgets'  => count( siite_bridge_flatten( siite_bridge_tree( $id ) ) ),
	];
}

/**
 * POST /post/<id> — the WordPress page itself: its title, and its address.
 *
 * Not Elementor data at all, which is why it had no route and why "the page
 * should be called Priser og pakker" came back as "that is outside what the
 * bridge can touch". It is one wp_update_post().
 *
 * The slug is separate and guarded. Changing it changes the page's URL, and
 * nothing here writes redirects — every existing link to the old address
 * breaks, including ones printed on something. So it moves only when the
 * caller says so outright, and the old address comes back in the answer so it
 * can be written down.
 *
 * Body: { "title": "Priser og pakker" }
 *       { "slug": "priser-og-pakker", "allow_slug": true }
 */
function siite_bridge_post_update( $req ) {
	$id   = (int) $req['id'];
	$body = $req->get_json_params();
	$post = get_post( $id );
	if ( ! $post ) {
		return new WP_Error( 'siite_no_post', "Post $id does not exist", [ 'status' => 404 ] );
	}

	$title = array_key_exists( 'title', $body ) ? trim( (string) $body['title'] ) : null;
	$slug  = array_key_exists( 'slug', $body )  ? sanitize_title( (string) $body['slug'] ) : null;
	if ( $title === null && $slug === null ) {
		return new WP_Error( 'siite_nothing', 'Nothing to change', [ 'status' => 400 ] );
	}
	if ( $title !== null && $title === '' ) {
		return new WP_Error( 'siite_empty_title', 'A page needs a title', [ 'status' => 400 ] );
	}
	if ( $slug !== null && empty( $body['allow_slug'] ) ) {
		return new WP_Error( 'siite_slug_guard',
			'Changing the slug changes the page address and breaks every existing '
			. 'link to it. Send "allow_slug": true if that is intended.',
			[ 'status' => 409, 'current' => $post->post_name,
			  'url' => get_permalink( $id ) ] );
	}
	if ( $slug !== null && $slug !== $post->post_name ) {
		$clash = get_page_by_path( $slug, OBJECT, $post->post_type );
		if ( $clash && (int) $clash->ID !== $id ) {
			return [ 'changed' => false, 'why' => 'slug-taken', 'slug' => $slug,
			         'post' => (int) $clash->ID, 'title' => $clash->post_title ];
		}
	}

	$was = [ 'title' => $post->post_title, 'slug' => $post->post_name,
	         'url' => get_permalink( $id ) ];

	if ( ! empty( $body['dry_run'] ) ) {
		return [ 'changed' => false, 'why' => 'dry-run', 'post' => $id,
		         'was' => $was,
		         'would' => [ 'title' => $title ?? $was['title'],
		                      'slug'  => $slug ?? $was['slug'] ] ];
	}

	$args = [ 'ID' => $id ];
	if ( $title !== null ) { $args['post_title'] = $title; }
	if ( $slug !== null )  { $args['post_name']  = $slug; }
	$done = wp_update_post( $args, true );
	if ( is_wp_error( $done ) ) { return $done; }

	$now = [ 'title' => get_the_title( $id ), 'slug' => get_post( $id )->post_name,
	         'url' => get_permalink( $id ) ];
	siite_bridge_ledger_add( [
		'post' => $id, 'route' => 'post', 'created' => [],
		'note' => 'title/slug: ' . wp_json_encode( $was ) . ' -> ' . wp_json_encode( $now ),
	] );
	siite_bridge_flush( $id );

	return [ 'changed' => true, 'post' => $id, 'was' => $was, 'now' => $now,
	         'url_changed' => $was['url'] !== $now['url'] ];
}


/** Draft to live. Separate on purpose: this is the step the client sees. */
function siite_bridge_page_publish( $req ) {
	$id   = (int) $req['id'];
	$post = get_post( $id );
	if ( ! $post ) {
		return new WP_Error( 'siite_no_post', "Post $id does not exist", [ 'status' => 404 ] );
	}
	if ( $post->post_status === 'publish' ) {
		return [ 'published' => false, 'why' => 'already-published', 'url' => get_permalink( $id ) ];
	}
	$was = $post->post_status;
	wp_update_post( [ 'ID' => $id, 'post_status' => 'publish' ], true );
	siite_bridge_flush( $id );
	return [
		'published' => true,
		'post'      => $id,
		'was'       => $was,
		'url'       => get_permalink( $id ),
	];
}

/**
 * Who the bridge is authenticated as, and how much that account can do. Read
 * by check() so an over-privileged account is reported the same way an old
 * plugin version is: visibly, on every check, instead of once in a setup
 * document nobody re-reads.
 */
function siite_bridge_account() {
	$user = wp_get_current_user();
	$able = [];
	foreach ( [ 'manage_options', 'install_plugins', 'edit_users', 'edit_themes',
	            'delete_pages', 'delete_posts', 'upload_files', 'unfiltered_html',
	            'edit_theme_options', 'siite_bridge_menus', 'siite_bridge_design' ] as $cap ) {
		if ( user_can( $user, $cap ) ) { $able[] = $cap; }
	}
	return [
		'login'      => $user->user_login,
		'roles'      => array_values( (array) $user->roles ),
		'dedicated'  => in_array( SIITE_BRIDGE_ROLE, (array) $user->roles, true ),
		'role_ready' => (bool) get_role( SIITE_BRIDGE_ROLE ),
		'can'        => $able,
	];
}

/* ================================================================ 1.13.0 ===
 *
 * Bridge 1.13.0, 15 September 2026. Two things drove it.
 *
 * The WordPress work moved from the app into the terminal: Claude Code runs the
 * CLI against a client's site, so every capability has to be a route a command
 * can reach, not a tool only the app's agent knew about.
 *
 * And the PowerCurve job (September 2026) listed what still had to be done
 * around the bridge with wp-cli or by hand in wp-admin: a page lookup by path,
 * saved templates (header/footer), the kit's global colours and typography,
 * the front page and permalinks, bulk publishing, site CSS, SVG and video
 * uploads, and a 403 that did not say why. A hosted client site has no wp-cli,
 * so each of those is a route now, with the same backup / readback / ledger
 * rules as every other write.
 */

/* ---------------------------------------------------------- permissions --- */

/**
 * Site-wide design: the kit, Additional CSS and the Reading settings.
 *
 * Its own capability for the same reason as siite_bridge_menus: the WordPress
 * capabilities that normally guard these (manage_options, edit_css) are
 * Administrator-only, and requiring them would force the bridge account back
 * to being an admin — which hands the application password the whole REST API.
 */
function siite_bridge_can_design() {
	return current_user_can( 'siite_bridge_design' ) || current_user_can( 'manage_options' );
}

/**
 * A 403 that says why.
 *
 * WordPress answers a refused edit_post as a bare rest_forbidden, which reads
 * like a broken application password. Measured on PowerCurve: "replace/3 ->
 * 403" was the privacy policy page, which WordPress only lets administrators
 * edit — nothing to do with the credentials at all.
 */
function siite_bridge_forbidden( $post ) {
	$why = [];
	if ( (int) get_option( 'wp_page_for_privacy_policy' ) === (int) $post->ID ) {
		$why[] = "it is the site's privacy policy page, which WordPress lets only administrators edit";
	}
	$pt = get_post_type_object( $post->post_type );
	if ( $pt ) {
		if ( ! current_user_can( $pt->cap->edit_posts ) ) {
			$why[] = "the account cannot edit {$post->post_type} at all";
		} else {
			if ( (int) $post->post_author !== get_current_user_id()
				&& ! current_user_can( $pt->cap->edit_others_posts ) ) {
				$why[] = 'it belongs to another user';
			}
			if ( $post->post_status === 'publish' && ! current_user_can( $pt->cap->edit_published_posts ) ) {
				$why[] = 'it is published';
			}
			if ( $post->post_status === 'private' && ! current_user_can( $pt->cap->edit_private_posts ) ) {
				$why[] = 'it is private';
			}
		}
	}
	return new WP_Error( 'siite_forbidden',
		sprintf( "The bridge account '%s' may not edit %s %d (\"%s\"): %s.",
			wp_get_current_user()->user_login, $post->post_type, $post->ID, $post->post_title,
			$why ? implode( '; ', $why ) : 'WordPress refused edit_post for it' ),
		[ 'status' => 403, 'post' => (int) $post->ID, 'post_type' => $post->post_type,
		  'reasons' => $why ] );
}

/** Ids of posts the bridge itself created through the given routes. */
function siite_bridge_made_ids( $routes ) {
	$ids = [];
	foreach ( siite_bridge_ledger_get() as $e ) {
		if ( in_array( $e['route'] ?? '', (array) $routes, true ) && ! empty( $e['post'] ) ) {
			$ids[ (int) $e['post'] ] = true;
		}
	}
	return $ids;
}

/* ---------------------------------------------------------------- pages --- */

/**
 * Every page with its path.
 *
 * The terminal starts from a URL somebody pasted, and a re-run starts from the
 * pages it built last time. /inventory only lists documents that already carry
 * Elementor data, so a page that was never built with Elementor — or one whose
 * parent is missing — was invisible to both. Measured on PowerCurve: the id map
 * had to be rebuilt by paging wp/v2/pages, and /404/ was not in it.
 */
function siite_bridge_pages( $req ) {
	$made       = siite_bridge_made_ids( [ 'page' ] );
	$front      = (int) get_option( 'page_on_front' );
	$posts_page = (int) get_option( 'page_for_posts' );
	$out        = [];
	$all = get_posts( [
		'post_type'        => 'page',
		'post_status'      => [ 'publish', 'draft', 'pending', 'private', 'future' ],
		'numberposts'      => -1,
		'orderby'          => 'menu_order title',
		'order'            => 'ASC',
		'suppress_filters' => true,
	] );
	foreach ( $all as $p ) {
		$uri   = trim( (string) get_page_uri( $p ), '/' );
		$out[] = [
			'id'             => (int) $p->ID,
			'title'          => $p->post_title,
			'slug'           => $p->post_name,
			'path'           => $uri === '' ? null : "/$uri/",
			'parent'         => (int) $p->post_parent,
			'status'         => $p->post_status,
			'template'       => get_post_meta( $p->ID, '_wp_page_template', true ) ?: 'default',
			'elementor'      => get_post_meta( $p->ID, '_elementor_edit_mode', true ) === 'builder',
			'url'            => get_permalink( $p ),
			'front'          => (int) $p->ID === $front,
			'posts_page'     => (int) $p->ID === $posts_page,
			'editable'       => current_user_can( 'edit_post', $p->ID ),
			'made_by_bridge' => isset( $made[ (int) $p->ID ] ),
		];
	}
	return [
		'pages'          => $out,
		'count'          => count( $out ),
		'show_on_front'  => get_option( 'show_on_front' ),
		'page_on_front'  => $front,
		'page_for_posts' => $posts_page,
	];
}

/**
 * Publish several pages in one call, parents first.
 *
 * A child published while its parent is still a draft gets a URL under a page
 * nobody can reach. PowerCurve published 56 pages one call at a time, and a
 * wp-cli loop over all the ids in one go left 404s behind.
 */
function siite_bridge_publish_many( $req ) {
	$b   = (array) $req->get_json_params();
	$ids = array_values( array_filter( array_unique( array_map( 'intval', (array) ( $b['ids'] ?? [] ) ) ) ) );
	if ( ! $ids ) {
		return new WP_Error( 'siite_no_ids', 'Send "ids": a list of page ids', [ 'status' => 400 ] );
	}
	if ( count( $ids ) > 300 ) {
		return new WP_Error( 'siite_too_many', 'At most 300 pages per call', [ 'status' => 400 ] );
	}
	$tpl = isset( $b['page_template'] ) ? (string) $b['page_template'] : null;
	if ( $tpl !== null ) {
		$known = array_merge( [ 'default', 'elementor_canvas', 'elementor_header_footer', 'elementor_theme' ],
			array_keys( (array) wp_get_theme()->get_page_templates( null, 'page' ) ) );
		if ( ! in_array( $tpl, $known, true ) ) {
			return new WP_Error( 'siite_bad_template',
				"'$tpl' is not a page template on this site. Known: " . implode( ', ', $known ),
				[ 'status' => 422 ] );
		}
	}
	$dry = ! empty( $b['dry_run'] );

	usort( $ids, function ( $a, $c ) {
		return count( get_post_ancestors( $a ) ) - count( get_post_ancestors( $c ) );
	} );

	$done = [];
	foreach ( $ids as $id ) {
		$p = get_post( $id );
		if ( ! $p || $p->post_type !== 'page' ) {
			$done[] = [ 'id' => $id, 'published' => false, 'why' => 'not-a-page' ];
			continue;
		}
		if ( ! current_user_can( 'edit_post', $id ) || ! current_user_can( 'publish_pages' ) ) {
			$done[] = [ 'id' => $id, 'published' => false,
						'why' => siite_bridge_forbidden( $p )->get_error_message() ];
			continue;
		}
		if ( $dry ) {
			$done[] = [ 'id' => $id, 'published' => false, 'why' => 'dry-run', 'was' => $p->post_status,
						'title' => $p->post_title ];
			continue;
		}
		$was = $p->post_status;
		if ( $tpl !== null ) { update_post_meta( $id, '_wp_page_template', $tpl ); }
		if ( $was !== 'publish' ) {
			$r = wp_update_post( [ 'ID' => $id, 'post_status' => 'publish' ], true );
			if ( is_wp_error( $r ) ) {
				$done[] = [ 'id' => $id, 'published' => false, 'why' => $r->get_error_message() ];
				continue;
			}
		}
		delete_post_meta( $id, '_elementor_css' );
		$done[] = [ 'id' => $id, 'published' => get_post_status( $id ) === 'publish', 'was' => $was,
					'title' => $p->post_title, 'url' => get_permalink( $id ) ];
	}

	$ok = array_values( array_filter( $done, function ( $d ) { return ! empty( $d['published'] ); } ) );
	$caches = [];
	if ( ! $dry && $ok ) {
		siite_bridge_ledger_add( [ 'post' => 0, 'route' => 'publish', 'created' => [],
			'note' => 'published ' . implode( ',', array_column( $ok, 'id' ) ) ] );
		$caches = siite_bridge_flush( 0 );
	}
	return [ 'pages' => $done, 'published' => count( $ok ),
			 'failed' => count( array_filter( $done, function ( $d ) {
				 return empty( $d['published'] ) && ( $d['why'] ?? '' ) !== 'dry-run'; } ) ),
			 'caches' => $caches ];
}

/**
 * Move a page or template the bridge created to the trash.
 *
 * Only ever something in the ledger, and only ever the trash — a person can
 * restore it in wp-admin. PowerCurve's first push built 28 pages with flat URLs
 * and there was no way to take them back out except a wp-cli script.
 */
function siite_bridge_trash( $req ) {
	$id = (int) $req['id'];
	$p  = get_post( $id );
	if ( ! $p ) {
		return new WP_Error( 'siite_no_post', "Post $id does not exist", [ 'status' => 404 ] );
	}
	$routes = [ 'page' => 'page', 'elementor_library' => 'template' ];
	if ( ! isset( $routes[ $p->post_type ] ) ) {
		return new WP_Error( 'siite_trash_type', 'Only pages and templates can be trashed here',
			[ 'status' => 422 ] );
	}
	$made = siite_bridge_made_ids( [ $routes[ $p->post_type ] ] );
	if ( ! isset( $made[ $id ] ) ) {
		return new WP_Error( 'siite_not_ours',
			"{$p->post_type} $id (\"{$p->post_title}\") was not created by the bridge, so it is not "
			. "the bridge's to remove. Trash it in wp-admin if that is the intent.",
			[ 'status' => 403 ] );
	}
	if ( (int) get_option( 'page_on_front' ) === $id ) {
		return new WP_Error( 'siite_trash_front', "Page $id is the site's front page", [ 'status' => 409 ] );
	}
	$kids = get_posts( [ 'post_parent' => $id, 'post_type' => 'page', 'fields' => 'ids', 'numberposts' => -1,
						 'post_status' => [ 'publish', 'draft', 'pending', 'private', 'future' ] ] );
	if ( $kids ) {
		return new WP_Error( 'siite_trash_children',
			"Page $id has child pages (" . implode( ', ', $kids ) . '). Trash those first.',
			[ 'status' => 409, 'children' => array_map( 'intval', $kids ) ] );
	}
	if ( ! empty( $req->get_json_params()['dry_run'] ) ) {
		return [ 'trashed' => false, 'why' => 'dry-run', 'id' => $id, 'title' => $p->post_title,
				 'type' => $p->post_type ];
	}
	if ( ! wp_trash_post( $id ) ) {
		return new WP_Error( 'siite_trash_failed', "WordPress did not trash $id", [ 'status' => 500 ] );
	}
	siite_bridge_ledger_add( [ 'post' => $id, 'route' => 'trash', 'created' => [],
							   'note' => "trashed {$p->post_type} \"{$p->post_title}\"" ] );
	siite_bridge_flush( 0 );
	return [ 'trashed' => true, 'id' => $id, 'title' => $p->post_title, 'type' => $p->post_type,
			 'undo' => 'wp-admin > Trash > Restore' ];
}

/* ------------------------------------------------------------ templates --- */

/** Elementor document types that live in the template library on this site. */
function siite_bridge_library_types() {
	$out = [];
	try {
		if ( isset( \Elementor\Plugin::$instance->documents ) ) {
			foreach ( \Elementor\Plugin::$instance->documents->get_document_types() as $name => $class ) {
				if ( in_array( $name, [ 'kit', 'not-supported', 'wp-page', 'wp-post' ], true ) ) { continue; }
				$cpt = (array) $class::get_property( 'cpt' );
				if ( in_array( 'elementor_library', $cpt, true ) || $class::get_property( 'show_in_library' ) ) {
					$out[] = $name;
				}
			}
		}
	} catch ( \Throwable $e ) {
		$out[] = 'section';
	}
	return array_values( array_unique( $out ) );
}

function siite_bridge_conditions_available() {
	return class_exists( '\ElementorPro\Modules\ThemeBuilder\Module' );
}

function siite_bridge_conditions_of( $id ) {
	$c = get_post_meta( $id, '_elementor_conditions', true );
	return is_array( $c ) ? array_values( $c ) : [];
}

/** Every saved template: header, footer, sections, theme-builder documents. */
function siite_bridge_templates() {
	$made = siite_bridge_made_ids( [ 'template' ] );
	$kit  = (int) get_option( 'elementor_active_kit' );
	$out  = [];
	$all  = get_posts( [
		'post_type'        => 'elementor_library',
		'post_status'      => [ 'publish', 'draft', 'pending', 'private' ],
		'numberposts'      => -1,
		'orderby'          => 'title',
		'order'            => 'ASC',
		'suppress_filters' => true,
	] );
	foreach ( $all as $p ) {
		$type = (string) get_post_meta( $p->ID, '_elementor_template_type', true );
		if ( $type === 'kit' || (int) $p->ID === $kit ) { continue; }
		$tree  = siite_bridge_tree( $p->ID );
		$out[] = [
			'id'             => (int) $p->ID,
			'title'          => $p->post_title,
			'slug'           => $p->post_name,
			'type'           => $type,
			'status'         => $p->post_status,
			'conditions'     => siite_bridge_conditions_of( $p->ID ),
			'elements'       => count( $tree ),
			'widgets'        => count( siite_bridge_flatten( $tree ) ),
			'editable'       => current_user_can( 'edit_post', $p->ID ),
			'made_by_bridge' => isset( $made[ (int) $p->ID ] ),
		];
	}
	return [
		'templates'  => $out,
		'types'      => siite_bridge_library_types(),
		'pro'        => defined( 'ELEMENTOR_PRO_VERSION' ) ? ELEMENTOR_PRO_VERSION : null,
		'conditions' => siite_bridge_conditions_available(),
	];
}

function siite_bridge_parse_conditions( $raw ) {
	if ( ! is_array( $raw ) ) {
		return new WP_Error( 'siite_bad_conditions', '"conditions" must be a list like ["include/general"]',
			[ 'status' => 400 ] );
	}
	$out = [];
	foreach ( $raw as $c ) {
		$c = trim( (string) $c, " /" );
		if ( ! preg_match( '#^(include|exclude)(/[A-Za-z0-9_-]+){1,3}$#', $c ) ) {
			return new WP_Error( 'siite_bad_conditions',
				"'$c' is not a display condition. Shape: include/general, include/singular/page, "
				. 'exclude/singular/page/42', [ 'status' => 400 ] );
		}
		$out[] = $c;
	}
	return $out;
}

/**
 * Display conditions through Elementor Pro's own conditions manager, so its
 * cache is regenerated with them.
 *
 * NOT verified against Elementor Pro on this machine — no Pro install exists in
 * the sandbox. The call is guarded, and the stored meta is read back, so a Pro
 * release that moves the API answers with an error instead of a silent success.
 */
function siite_bridge_save_conditions( $id, $conditions ) {
	try {
		$mod = \ElementorPro\Modules\ThemeBuilder\Module::instance();
		$mgr = method_exists( $mod, 'get_conditions_manager' ) ? $mod->get_conditions_manager() : null;
		if ( ! $mgr || ! method_exists( $mgr, 'save_conditions' ) ) {
			return new WP_Error( 'siite_conditions_api',
				"Elementor Pro is active, but its conditions API has moved. Set the conditions in "
				. 'Theme Builder; the template itself was saved.', [ 'status' => 500 ] );
		}
		$rows = [];
		foreach ( $conditions as $c ) {
			$parts  = explode( '/', $c );
			$rows[] = array_combine( array_slice( [ 'type', 'name', 'sub_name', 'sub_id' ], 0, count( $parts ) ), $parts );
		}
		$mgr->save_conditions( $id, $rows );
	} catch ( \Throwable $e ) {
		return new WP_Error( 'siite_conditions_failed', substr( $e->getMessage(), 0, 200 ), [ 'status' => 500 ] );
	}
	$now = siite_bridge_conditions_of( $id );
	return [ 'saved' => $now === array_values( $conditions ), 'now' => $now ];
}

/**
 * Create or update a saved template, found by slug.
 *
 * The header and footer of a client site usually live here, which makes this
 * the place where a change shows on every page at once. Updating keeps the
 * type; changing a template's type in place is refused, because a section that
 * becomes a footer is a different document to Elementor.
 */
function siite_bridge_template_save( $req ) {
	$b    = (array) $req->get_json_params();
	$slug = sanitize_title( (string) ( $b['slug'] ?? '' ) );
	if ( $slug === '' ) {
		return new WP_Error( 'siite_no_slug',
			'A template needs a "slug" — it is how the theme and the next run find it again',
			[ 'status' => 400 ] );
	}
	$tree = array_key_exists( 'data', $b ) ? $b['data'] : null;
	if ( $tree !== null && ! is_array( $tree ) ) {
		return new WP_Error( 'siite_bad_tree', '"data" must be an element array', [ 'status' => 400 ] );
	}
	$title     = trim( (string) ( $b['title'] ?? '' ) );
	$want_type = isset( $b['type'] ) ? sanitize_key( (string) $b['type'] ) : null;
	$status    = ( (string) ( $b['status'] ?? 'publish' ) ) === 'draft' ? 'draft' : 'publish';
	$dry       = ! empty( $b['dry_run'] );

	// Validate the conditions before anything is written, so a site without
	// Pro does not end up with half a request carried out.
	$conditions = null;
	if ( array_key_exists( 'conditions', $b ) ) {
		$conditions = siite_bridge_parse_conditions( $b['conditions'] );
		if ( is_wp_error( $conditions ) ) { return $conditions; }
		if ( ! siite_bridge_conditions_available() ) {
			return new WP_Error( 'siite_conditions_need_pro',
				'Display conditions are an Elementor Pro Theme Builder feature, and Elementor Pro is '
				. 'not active here. Nothing was written. Without Pro, the theme prints the template '
				. 'itself (get_builder_content_for_display with its id).', [ 'status' => 422 ] );
		}
	}

	$existing = get_page_by_path( $slug, OBJECT, 'elementor_library' );
	if ( $existing && $existing->post_status === 'trash' ) {
		return new WP_Error( 'siite_template_trashed',
			"A template with the slug '$slug' is in the trash (post {$existing->ID}). Restore it or pick another slug.",
			[ 'status' => 409 ] );
	}

	$stamp = null;
	if ( $existing ) {
		$id = (int) $existing->ID;
		if ( ! current_user_can( 'edit_post', $id ) ) { return siite_bridge_forbidden( $existing ); }
		$type = (string) get_post_meta( $id, '_elementor_template_type', true );
		if ( $want_type && $want_type !== $type ) {
			return new WP_Error( 'siite_template_type',
				"Template '$slug' exists as type '$type', not '$want_type'. A type is not changed in "
				. 'place — pick another slug.', [ 'status' => 409, 'post' => $id ] );
		}
		if ( $dry ) {
			return [ 'saved' => false, 'why' => 'dry-run', 'created' => false, 'id' => $id, 'slug' => $slug,
					 'type' => $type, 'elements_now' => count( siite_bridge_tree( $id ) ),
					 'elements_new' => $tree === null ? null : count( $tree ),
					 'conditions_now' => siite_bridge_conditions_of( $id ), 'conditions_new' => $conditions ];
		}
		if ( $tree !== null ) {
			siite_bridge_make_elementor( $id );
			$stamp = siite_bridge_backup( $id );
			$wrote = siite_bridge_write_data( $id, $tree );
			if ( is_wp_error( $wrote ) ) { return $wrote; }
			if ( ! $wrote['ok'] ) {
				siite_bridge_restore_stamp( $id, $stamp );
				return new WP_Error( 'siite_verify_failed', 'Readback mismatch; the backup was restored',
					[ 'status' => 500 ] );
			}
		}
		if ( $title !== '' && $title !== $existing->post_title ) {
			wp_update_post( [ 'ID' => $id, 'post_title' => $title ] );
		}
		$created = false;
	} else {
		$type  = $want_type ?: 'section';
		$types = siite_bridge_library_types();
		if ( ! in_array( $type, $types, true ) ) {
			return new WP_Error( 'siite_template_type',
				"'$type' is not a template type on this site. Available: " . implode( ', ', $types ),
				[ 'status' => 422 ] );
		}
		if ( $dry ) {
			return [ 'saved' => false, 'why' => 'dry-run', 'created' => false, 'would_create' => true,
					 'slug' => $slug, 'type' => $type, 'elements_new' => $tree === null ? 0 : count( $tree ),
					 'conditions_new' => $conditions ];
		}
		try {
			$doc = \Elementor\Plugin::$instance->documents->create( $type, [
				'post_title'  => $title !== '' ? $title : $slug,
				'post_name'   => $slug,
				'post_status' => $status,
				'post_type'   => 'elementor_library',
			] );
		} catch ( \Throwable $e ) {
			return new WP_Error( 'siite_template_create', substr( $e->getMessage(), 0, 200 ), [ 'status' => 500 ] );
		}
		if ( is_wp_error( $doc ) ) { return $doc; }
		if ( ! $doc ) {
			return new WP_Error( 'siite_template_create', 'Elementor did not create the document', [ 'status' => 500 ] );
		}
		$id = (int) $doc->get_main_id();
		if ( get_post( $id )->post_name !== $slug ) {
			wp_update_post( [ 'ID' => $id, 'post_name' => $slug ] );
		}
		if ( taxonomy_exists( 'elementor_library_type' ) ) {
			wp_set_object_terms( $id, $type, 'elementor_library_type' );
		}
		siite_bridge_ledger_add( [ 'post' => $id, 'route' => 'template', 'created' => [ 'template:' . $id ],
								   'note' => "created template $slug ($type)" ] );
		if ( $tree !== null ) {
			$wrote = siite_bridge_write_data( $id, $tree );
			if ( is_wp_error( $wrote ) ) { return $wrote; }
			if ( ! $wrote['ok'] ) {
				return new WP_Error( 'siite_verify_failed',
					"Template created as post $id, but its elements did not read back as written",
					[ 'status' => 500, 'post' => $id ] );
			}
		}
		$created = true;
	}

	$cond = null;
	if ( $conditions !== null ) {
		$cond = siite_bridge_save_conditions( $id, $conditions );
		if ( is_wp_error( $cond ) ) { return $cond; }
	}
	if ( ! $created ) {
		siite_bridge_ledger_add( [ 'post' => $id, 'route' => 'template-update', 'created' => [],
			'note' => "updated template $slug" . ( $stamp ? " (backup $stamp)" : '' ) ] );
	}
	return [
		'saved'         => true,
		'created'       => $created,
		'id'            => $id,
		'slug'          => $slug,
		'type'          => $type,
		'status'        => get_post_status( $id ),
		'backup'        => $stamp,
		'conditions'    => $cond,
		'elements'      => count( siite_bridge_tree( $id ) ),
		'missing_media' => $tree === null ? [] : siite_bridge_missing_media( $tree ),
		'edit_url'      => admin_url( "post.php?post=$id&action=elementor" ),
		'caches'        => siite_bridge_flush( $id ),
	];
}

/* ------------------------------------------------------------------ kit --- */

const SIITE_BRIDGE_KIT_BAK  = '_siite_kitbak_';
const SIITE_BRIDGE_KIT_KEEP = 5;

/** Elementor options a kit change may carry, with the values they may take. */
const SIITE_BRIDGE_KIT_OPTIONS = [
	'elementor_disable_color_schemes'      => [ '', 'yes' ],
	'elementor_disable_typography_schemes' => [ '', 'yes' ],
	'elementor_google_font'                => [ '0', '1' ],
	'elementor_font_display'               => [ 'auto', 'block', 'swap', 'fallback', 'optional' ],
	'elementor_css_print_method'           => [ 'external', 'internal' ],
];

/**
 * Kit settings the bridge writes: the global palette and type, and the site
 * defaults for text, headings, links, buttons, forms, images, the container
 * and breakpoints. Not the site identity, custom code or anything that loads
 * a script.
 */
function siite_bridge_kit_key_ok( $key ) {
	if ( in_array( $key, [ 'system_colors', 'custom_colors', 'system_typography', 'custom_typography',
						   'space_between_widgets', 'page_title_selector', 'active_breakpoints',
						   'default_generic_fonts', 'stretched_section_container' ], true ) ) {
		return true;
	}
	return (bool) preg_match(
		'/^(body|h[1-6]|link_normal|link_hover|button|form_field|form_label|image|container)_[a-z0-9_]+$|^viewport_[a-z_]+$/',
		(string) $key );
}

function siite_bridge_kit_doc() {
	$kit_id = (int) get_option( 'elementor_active_kit' );
	if ( ! $kit_id || ! get_post( $kit_id ) || ! class_exists( '\Elementor\Plugin' )
		|| ! isset( \Elementor\Plugin::$instance->documents ) ) {
		return new WP_Error( 'siite_no_kit', 'This site has no active Elementor kit', [ 'status' => 404 ] );
	}
	$doc = \Elementor\Plugin::$instance->documents->get( $kit_id, false );
	if ( ! $doc ) {
		return new WP_Error( 'siite_no_kit', "Kit $kit_id could not be loaded", [ 'status' => 404 ] );
	}
	return $doc;
}

function siite_bridge_kit_backups( $kit_id ) {
	$out = [];
	foreach ( array_keys( (array) get_post_meta( $kit_id ) ) as $k ) {
		if ( strpos( $k, SIITE_BRIDGE_KIT_BAK ) === 0 ) { $out[] = substr( $k, strlen( SIITE_BRIDGE_KIT_BAK ) ); }
	}
	rsort( $out );
	return $out;
}

/**
 * Change the site's design system: global colours and typography, and the
 * defaults every element falls back to.
 *
 * This is the one write that changes every page at once, which is exactly what
 * a request like "make the green a little darker everywhere" needs, and exactly
 * why the whole previous kit is kept as a backup on the kit itself and read
 * back after the save.
 *
 * `colors` is the short form: { "primary": "#295D37", "brand_tint": {"title":
 * "Tint", "color": "#DCF1DE"} }. An id that exists is recoloured wherever it is
 * (system or custom palette); a new id is added to the custom palette.
 */
function siite_bridge_kit_update( $req ) {
	$b        = (array) $req->get_json_params();
	$settings = $b['settings'] ?? [];
	$colors   = $b['colors'] ?? [];
	$options  = $b['options'] ?? [];
	if ( ! is_array( $settings ) || ! is_array( $colors ) || ! is_array( $options ) ) {
		return new WP_Error( 'siite_kit_args', '"settings", "colors" and "options" must be objects',
			[ 'status' => 400 ] );
	}
	if ( ! $settings && ! $colors && ! $options ) {
		return new WP_Error( 'siite_kit_args', 'Nothing to change: send "settings", "colors" or "options"',
			[ 'status' => 400 ] );
	}
	$bad = [];
	foreach ( array_keys( $settings ) as $k ) {
		if ( ! siite_bridge_kit_key_ok( (string) $k ) ) { $bad[] = $k; }
	}
	if ( $bad ) {
		return new WP_Error( 'siite_kit_key',
			'Not a kit setting the bridge writes: ' . implode( ', ', $bad ) . '. Allowed: system/custom '
			. 'colours and typography, body_/h1_-h6_/link_/button_/form_/image_/container_ settings, '
			. 'viewport_ breakpoints, space_between_widgets, page_title_selector.', [ 'status' => 400 ] );
	}
	foreach ( $options as $k => $v ) {
		if ( ! isset( SIITE_BRIDGE_KIT_OPTIONS[ $k ] ) || ! in_array( (string) $v, SIITE_BRIDGE_KIT_OPTIONS[ $k ], true ) ) {
			return new WP_Error( 'siite_kit_option',
				"Option '$k' => '$v' is not allowed. Allowed: " . wp_json_encode( SIITE_BRIDGE_KIT_OPTIONS ),
				[ 'status' => 400 ] );
		}
	}

	$doc = siite_bridge_kit_doc();
	if ( is_wp_error( $doc ) ) { return $doc; }
	$kit_id = (int) $doc->get_main_id();
	if ( ! current_user_can( 'edit_post', $kit_id ) ) { return siite_bridge_forbidden( get_post( $kit_id ) ); }

	$before = get_post_meta( $kit_id, '_elementor_page_settings', true );
	$before = is_array( $before ) ? $before : [];
	$after  = $before;
	foreach ( $settings as $k => $v ) { $after[ $k ] = $v; }

	$color_log = [];
	if ( $colors ) {
		// A kit that has never been saved in the editor stores no palette at
		// all; Elementor serves the defaults. Start from what it serves, or
		// "primary" would be added as a new custom colour instead of recoloured.
		foreach ( [ 'system_colors', 'custom_colors' ] as $list ) {
			if ( ! isset( $after[ $list ] ) || ! is_array( $after[ $list ] ) ) {
				$served        = $doc->get_settings( $list );
				$after[ $list ] = is_array( $served ) ? $served : [];
			}
		}
		foreach ( $colors as $cid => $val ) {
			$cid   = sanitize_key( (string) $cid );
			$hex   = is_array( $val ) ? (string) ( $val['color'] ?? '' ) : (string) $val;
			$label = is_array( $val ) ? trim( (string) ( $val['title'] ?? '' ) ) : '';
			if ( $cid === '' ) { continue; }
			if ( ! preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $hex ) ) {
				return new WP_Error( 'siite_kit_color', "Colour '$cid' must be a hex value like #295D37, got '$hex'",
					[ 'status' => 400 ] );
			}
			$found = false;
			foreach ( [ 'system_colors', 'custom_colors' ] as $list ) {
				foreach ( $after[ $list ] as $i => $row ) {
					if ( ( $row['_id'] ?? '' ) !== $cid ) { continue; }
					$color_log[] = [ 'id' => $cid, 'was' => $row['color'] ?? null, 'now' => $hex, 'list' => $list ];
					$after[ $list ][ $i ]['color'] = $hex;
					if ( $label !== '' ) { $after[ $list ][ $i ]['title'] = $label; }
					$found = true;
					break 2;
				}
			}
			if ( ! $found ) {
				$after['custom_colors'][] = [ '_id' => $cid, 'title' => $label !== '' ? $label : $cid, 'color' => $hex ];
				$color_log[] = [ 'id' => $cid, 'was' => null, 'now' => $hex, 'list' => 'custom_colors' ];
			}
		}
	}

	$changed = [];
	foreach ( $after as $k => $v ) {
		if ( ! array_key_exists( $k, $before ) || wp_json_encode( $before[ $k ] ) !== wp_json_encode( $v ) ) {
			$changed[] = $k;
		}
	}
	$opt_log = [];
	foreach ( $options as $k => $v ) {
		$was = get_option( $k, null );
		if ( (string) $was !== (string) $v || $was === null ) {
			$opt_log[ $k ] = [ 'was' => $was, 'now' => (string) $v ];
		}
	}

	if ( ! empty( $b['dry_run'] ) ) {
		return [ 'saved' => false, 'why' => 'dry-run', 'kit' => $kit_id, 'changed' => $changed,
				 'colors' => $color_log, 'options' => $opt_log ];
	}
	if ( ! $changed && ! $opt_log ) {
		return [ 'saved' => false, 'why' => 'no-change', 'kit' => $kit_id ];
	}

	$stamp = gmdate( 'Ymd-His' );
	$base  = $stamp;
	for ( $n = 2; metadata_exists( 'post', $kit_id, SIITE_BRIDGE_KIT_BAK . $stamp ) && $n < 60; $n++ ) {
		$stamp = $base . '-' . $n;
	}
	$prev_opts = [];
	foreach ( array_keys( $opt_log ) as $k ) { $prev_opts[ $k ] = $opt_log[ $k ]['was']; }
	add_post_meta( $kit_id, SIITE_BRIDGE_KIT_BAK . $stamp,
		wp_slash( wp_json_encode( [ 'settings' => $before, 'options' => $prev_opts ] ) ) );
	$all = siite_bridge_kit_backups( $kit_id );
	foreach ( array_slice( $all, SIITE_BRIDGE_KIT_KEEP ) as $old ) {
		delete_post_meta( $kit_id, SIITE_BRIDGE_KIT_BAK . $old );
	}

	if ( $changed ) {
		// Straight to the meta Elementor's own settings manager writes. Called as
		// the bridge account, the kit's Document::save() stored nothing and
		// reported nothing (measured on the sandbox 15 September 2026): the kit
		// is only editable by administrators, and the Siite Bridge role is
		// deliberately not one. The readback below proves the write landed;
		// siite_bridge_flush() regenerates the kit CSS.
		update_post_meta( $kit_id, '_elementor_page_settings', wp_slash( $after ) );
		$back = get_post_meta( $kit_id, '_elementor_page_settings', true );
		$back = is_array( $back ) ? $back : [];
		$off  = [];
		foreach ( $changed as $k ) {
			if ( ! array_key_exists( $k, $back ) || wp_json_encode( $back[ $k ] ) !== wp_json_encode( $after[ $k ] ) ) {
				$off[] = $k;
			}
		}
		if ( $off ) {
			update_post_meta( $kit_id, '_elementor_page_settings', wp_slash( $before ) );
			return new WP_Error( 'siite_kit_verify',
				'The kit did not read back as written (' . implode( ', ', $off ) . '); the previous settings were put back.',
				[ 'status' => 500 ] );
		}
	}
	foreach ( $opt_log as $k => $row ) { update_option( $k, $row['now'] ); }

	siite_bridge_ledger_add( [ 'post' => $kit_id, 'route' => 'kit', 'created' => [],
		'note' => 'kit: ' . implode( ', ', $changed )
			. ( $opt_log ? '; options: ' . implode( ', ', array_keys( $opt_log ) ) : '' ) . " (backup $stamp)" ] );
	return [ 'saved' => true, 'kit' => $kit_id, 'backup' => $stamp, 'changed' => $changed,
			 'colors' => $color_log, 'options' => $opt_log, 'caches' => siite_bridge_flush( $kit_id ) ];
}

/** Put the kit back to a backup: the newest, or the one named by "stamp". */
function siite_bridge_kit_restore( $req ) {
	$b   = (array) $req->get_json_params();
	$doc = siite_bridge_kit_doc();
	if ( is_wp_error( $doc ) ) { return $doc; }
	$kit_id = (int) $doc->get_main_id();
	if ( ! current_user_can( 'edit_post', $kit_id ) ) { return siite_bridge_forbidden( get_post( $kit_id ) ); }

	$stamps = siite_bridge_kit_backups( $kit_id );
	$stamp  = (string) ( $b['stamp'] ?? ( $stamps[0] ?? '' ) );
	if ( $stamp === '' || ! in_array( $stamp, $stamps, true ) ) {
		return new WP_Error( 'siite_no_backup',
			'No kit backup with that stamp. Available: ' . ( $stamps ? implode( ', ', $stamps ) : 'none' ),
			[ 'status' => 404 ] );
	}
	$bak = json_decode( (string) get_post_meta( $kit_id, SIITE_BRIDGE_KIT_BAK . $stamp, true ), true );
	if ( ! is_array( $bak ) || ! isset( $bak['settings'] ) || ! is_array( $bak['settings'] ) ) {
		return new WP_Error( 'siite_bad_backup', "Kit backup $stamp could not be read", [ 'status' => 500 ] );
	}
	if ( ! empty( $b['dry_run'] ) ) {
		return [ 'restored' => false, 'why' => 'dry-run', 'stamp' => $stamp,
				 'options' => array_keys( (array) ( $bak['options'] ?? [] ) ) ];
	}
	update_post_meta( $kit_id, '_elementor_page_settings', wp_slash( $bak['settings'] ) );
	foreach ( (array) ( $bak['options'] ?? [] ) as $k => $v ) {
		if ( ! isset( SIITE_BRIDGE_KIT_OPTIONS[ $k ] ) ) { continue; }
		if ( $v === null ) { delete_option( $k ); } else { update_option( $k, $v ); }
	}
	$back = get_post_meta( $kit_id, '_elementor_page_settings', true );
	siite_bridge_ledger_add( [ 'post' => $kit_id, 'route' => 'kit-restore', 'created' => [],
							   'note' => "kit restored to $stamp" ] );
	return [ 'restored' => true, 'stamp' => $stamp,
			 'verified' => wp_json_encode( $back ) === wp_json_encode( $bak['settings'] ),
			 'caches' => siite_bridge_flush( $kit_id ) ];
}

/* -------------------------------------------------------------- options --- */

/** The permalink structures the bridge will set. */
const SIITE_BRIDGE_PERMALINKS = [ '/%postname%/' ];

function siite_bridge_options_get() {
	$front = (int) get_option( 'page_on_front' );
	$posts = (int) get_option( 'page_for_posts' );
	return [
		'show_on_front'       => get_option( 'show_on_front' ),
		'page_on_front'       => $front,
		'page_on_front_title' => $front ? get_the_title( $front ) : null,
		'page_for_posts'      => $posts,
		'page_for_posts_title'=> $posts ? get_the_title( $posts ) : null,
		'permalink_structure' => (string) get_option( 'permalink_structure' ),
		'blog_public'         => (string) get_option( 'blog_public' ),
		'blogname'            => get_option( 'blogname' ),
		'home'                => home_url(),
	];
}

/**
 * Settings > Reading and Settings > Permalinks, the parts a build or a
 * correction actually needs.
 *
 * `blog_public` is the "discourage search engines" box: 0 on a devsite, 1 when
 * the client goes live. A permalink structure is only ever set to one of the
 * values above, and an existing non-plain structure is only replaced when the
 * caller says so — changing it moves every URL on the site that is not a page.
 */
function siite_bridge_options_set( $req ) {
	$b       = (array) $req->get_json_params();
	$allowed = [ 'show_on_front', 'page_on_front', 'page_for_posts', 'permalink_structure', 'blog_public' ];
	$extra   = array_diff( array_keys( $b ), array_merge( $allowed, [ 'dry_run', 'allow_permalink_change' ] ) );
	if ( $extra ) {
		return new WP_Error( 'siite_option_key',
			'Not an option the bridge writes: ' . implode( ', ', $extra ) . '. Allowed: ' . implode( ', ', $allowed ),
			[ 'status' => 400 ] );
	}
	$want = array_intersect_key( $b, array_flip( $allowed ) );
	if ( ! $want ) {
		return new WP_Error( 'siite_nothing', 'Nothing to change', [ 'status' => 400 ] );
	}

	if ( isset( $want['show_on_front'] ) && ! in_array( $want['show_on_front'], [ 'page', 'posts' ], true ) ) {
		return new WP_Error( 'siite_option_value', 'show_on_front is "page" or "posts"', [ 'status' => 400 ] );
	}
	foreach ( [ 'page_on_front', 'page_for_posts' ] as $k ) {
		if ( ! isset( $want[ $k ] ) ) { continue; }
		$want[ $k ] = (int) $want[ $k ];
		if ( $want[ $k ] === 0 ) { continue; }
		$p = get_post( $want[ $k ] );
		if ( ! $p || $p->post_type !== 'page' || $p->post_status !== 'publish' ) {
			return new WP_Error( 'siite_option_value', "$k: {$want[$k]} is not a published page", [ 'status' => 422 ] );
		}
	}
	$front = $want['page_on_front'] ?? (int) get_option( 'page_on_front' );
	$posts = $want['page_for_posts'] ?? (int) get_option( 'page_for_posts' );
	if ( $front && $front === $posts ) {
		return new WP_Error( 'siite_option_value', 'The front page and the posts page cannot be the same page',
			[ 'status' => 422 ] );
	}
	if ( ( $want['show_on_front'] ?? get_option( 'show_on_front' ) ) === 'page' && ! $front ) {
		return new WP_Error( 'siite_option_value', 'A static front page needs page_on_front', [ 'status' => 422 ] );
	}
	if ( isset( $want['permalink_structure'] ) ) {
		$want['permalink_structure'] = (string) $want['permalink_structure'];
		$current = (string) get_option( 'permalink_structure' );
		if ( ! in_array( $want['permalink_structure'], SIITE_BRIDGE_PERMALINKS, true ) ) {
			return new WP_Error( 'siite_option_value',
				'permalink_structure can be set to: ' . implode( ', ', SIITE_BRIDGE_PERMALINKS ), [ 'status' => 400 ] );
		}
		if ( $current !== '' && $current !== $want['permalink_structure'] && empty( $b['allow_permalink_change'] ) ) {
			return new WP_Error( 'siite_permalink_guard',
				"The site already uses '$current'. Changing it moves every URL that is not a page and "
				. 'breaks links to them. Send "allow_permalink_change": true if that is intended.',
				[ 'status' => 409, 'current' => $current ] );
		}
	}
	if ( isset( $want['blog_public'] ) ) {
		$want['blog_public'] = (string) (int) $want['blog_public'];
		if ( ! in_array( $want['blog_public'], [ '0', '1' ], true ) ) {
			return new WP_Error( 'siite_option_value', 'blog_public is 0 or 1', [ 'status' => 400 ] );
		}
	}

	$was = [];
	// Typed like the request: WordPress hands blog_public back as an int.
	foreach ( $want as $k => $v ) { $was[ $k ] = is_int( $v ) ? (int) get_option( $k ) : (string) get_option( $k ); }
	if ( ! empty( $b['dry_run'] ) ) {
		return [ 'changed' => false, 'why' => 'dry-run', 'was' => $was, 'would' => $want ];
	}

	foreach ( $want as $k => $v ) { update_option( $k, $v ); }
	$flushed = false;
	if ( isset( $want['permalink_structure'] ) && (string) $was['permalink_structure'] !== $want['permalink_structure'] ) {
		if ( ! function_exists( 'save_mod_rewrite_rules' ) && file_exists( ABSPATH . 'wp-admin/includes/misc.php' ) ) {
			require_once ABSPATH . 'wp-admin/includes/misc.php';
		}
		global $wp_rewrite;
		if ( $wp_rewrite ) { $wp_rewrite->set_permalink_structure( $want['permalink_structure'] ); }
		flush_rewrite_rules( true );
		$flushed = true;
	}
	$now = [];
	foreach ( $want as $k => $v ) { $now[ $k ] = is_int( $v ) ? (int) get_option( $k ) : (string) get_option( $k ); }
	$verified = true;
	foreach ( $want as $k => $v ) {
		if ( (string) $now[ $k ] !== (string) $v ) { $verified = false; }
	}
	siite_bridge_ledger_add( [ 'post' => 0, 'route' => 'options', 'created' => [],
							   'note' => 'options ' . wp_json_encode( $was ) . ' -> ' . wp_json_encode( $now ) ] );
	return [ 'changed' => true, 'was' => $was, 'now' => $now, 'verified' => $verified,
			 'rewrite_flushed' => $flushed, 'caches' => siite_bridge_flush( 0 ) ];
}

/* ------------------------------------------------------------------ css --- */

const SIITE_BRIDGE_CSS_BAK  = 'siite_bridge_css_backups';
const SIITE_BRIDGE_CSS_KEEP = 5;
const SIITE_BRIDGE_CSS_MAX  = 300000;

/**
 * The site's Additional CSS — Appearance > Customize > Additional CSS, the one
 * place for site CSS that survives a theme update and that the client can see.
 *
 * Named sections, marked with comments, let the bridge own a block without
 * touching whatever the client wrote around it.
 */
function siite_bridge_css_get() {
	$css = function_exists( 'wp_get_custom_css' ) ? (string) wp_get_custom_css() : '';
	preg_match_all( '#/\* siite:start ([A-Za-z0-9_-]+) \*/#', $css, $m );
	$bak = get_option( SIITE_BRIDGE_CSS_BAK );
	$bak = is_array( $bak ) ? $bak : [];
	return [
		'css'      => $css,
		'bytes'    => strlen( $css ),
		'sections' => $m[1],
		'theme'    => get_stylesheet(),
		'backups'  => array_values( array_map( function ( $x ) { return $x['stamp']; }, $bak ) ),
		'where'    => 'Appearance > Customize > Additional CSS',
	];
}

function siite_bridge_css_set( $req ) {
	if ( ! function_exists( 'wp_update_custom_css_post' ) ) {
		return new WP_Error( 'siite_css_api', 'This WordPress has no Additional CSS', [ 'status' => 501 ] );
	}
	$b       = (array) $req->get_json_params();
	$current = (string) wp_get_custom_css();
	$bak     = get_option( SIITE_BRIDGE_CSS_BAK );
	$bak     = is_array( $bak ) ? $bak : [];
	$section = isset( $b['section'] ) ? (string) $b['section'] : null;

	if ( isset( $b['restore'] ) ) {
		$hit = null;
		foreach ( $bak as $row ) { if ( $row['stamp'] === (string) $b['restore'] ) { $hit = $row; } }
		if ( ! $hit ) {
			return new WP_Error( 'siite_no_backup', 'No CSS backup with that stamp. Available: '
				. implode( ', ', array_column( $bak, 'stamp' ) ), [ 'status' => 404 ] );
		}
		$new = (string) $hit['css'];
	} else {
		if ( ! isset( $b['css'] ) || ! is_string( $b['css'] ) ) {
			return new WP_Error( 'siite_css_args', 'Send "css" (and "section" to own one named block)',
				[ 'status' => 400 ] );
		}
		$css = str_replace( "\r\n", "\n", $b['css'] );
		if ( strpos( $css, '<' ) !== false ) {
			return new WP_Error( 'siite_css_unsafe',
				'CSS may not contain "<". It is printed inside a <style> tag on every page, and "<" is '
				. 'how a style block is closed from the inside.', [ 'status' => 422 ] );
		}
		if ( strlen( $css ) > SIITE_BRIDGE_CSS_MAX ) {
			return new WP_Error( 'siite_css_size', 'CSS is larger than 300 kB', [ 'status' => 413 ] );
		}
		if ( $section !== null ) {
			if ( ! preg_match( '/^[A-Za-z0-9_-]{1,40}$/', $section ) ) {
				return new WP_Error( 'siite_css_args', 'A section name is 1-40 letters, digits, - or _',
					[ 'status' => 400 ] );
			}
			$start   = "/* siite:start $section */";
			$end     = "/* siite:end $section */";
			$block   = trim( $css ) === '' ? '' : $start . "\n" . trim( $css ) . "\n" . $end;
			$pattern = '#\n*' . preg_quote( $start, '#' ) . '.*?' . preg_quote( $end, '#' ) . '\n?#s';
			if ( preg_match( $pattern, $current ) ) {
				$new = preg_replace_callback( $pattern, function () use ( $block ) {
					return $block === '' ? "\n" : "\n\n" . $block . "\n";
				}, $current, 1 );
			} else {
				$new = $block === '' ? $current
					: ( trim( $current ) === '' ? '' : rtrim( $current ) . "\n\n" ) . $block . "\n";
			}
			$new = ltrim( $new, "\n" );
		} else {
			$new = $css;
		}
	}

	if ( $new === $current ) {
		return [ 'saved' => false, 'why' => 'no-change', 'bytes' => strlen( $current ) ];
	}
	if ( ! empty( $b['dry_run'] ) ) {
		return [ 'saved' => false, 'why' => 'dry-run', 'bytes_now' => strlen( $current ),
				 'bytes_new' => strlen( $new ), 'section' => $section ];
	}

	$stamp = gmdate( 'Ymd-His' );
	$taken = array_column( $bak, 'stamp' );
	for ( $n = 2, $base = $stamp; in_array( $stamp, $taken, true ) && $n < 60; $n++ ) { $stamp = $base . '-' . $n; }
	$bak[] = [ 'stamp' => $stamp, 'css' => $current ];
	$bak   = array_slice( $bak, -SIITE_BRIDGE_CSS_KEEP );
	update_option( SIITE_BRIDGE_CSS_BAK, $bak, false );

	// The account has no unfiltered_html, so WordPress runs kses over the post
	// it stores the CSS in, and kses turns "a > b" into "a &gt; b". The "<"
	// refusal above is what keeps this safe; the readback is what proves it.
	$kses = ! current_user_can( 'unfiltered_html' );
	if ( $kses ) { kses_remove_filters(); }
	try {
		$r = wp_update_custom_css_post( $new );
	} finally {
		if ( $kses ) { kses_init_filters(); }
	}
	if ( is_wp_error( $r ) ) { return $r; }

	$back = (string) wp_get_custom_css();
	preg_match_all( '#/\* siite:start ([A-Za-z0-9_-]+) \*/#', $back, $m );
	siite_bridge_ledger_add( [ 'post' => 0, 'route' => 'css', 'created' => [],
		'note' => 'additional css ' . ( $section ? "section $section" : 'replaced' ) . " (backup $stamp)" ] );
	return [ 'saved' => true, 'bytes' => strlen( $back ), 'sections' => $m[1], 'backup' => $stamp,
			 'verified' => $back === $new, 'caches' => siite_bridge_flush( 0 ) ];
}

/* ---------------------------------------------------------------- flush --- */

/** Regenerate Elementor's CSS and purge page caches — one post, or the site. */
function siite_bridge_flush_route( $req ) {
	$post = (int) ( ( (array) $req->get_json_params() )['post'] ?? 0 );
	if ( $post ) {
		$p = get_post( $post );
		if ( ! $p ) { return new WP_Error( 'siite_no_post', "Post $post does not exist", [ 'status' => 404 ] ); }
		if ( ! current_user_can( 'edit_post', $post ) ) { return siite_bridge_forbidden( $p ); }
	}
	return [ 'flushed' => true, 'post' => $post ?: null, 'done' => siite_bridge_flush( $post ) ];
}

/* --------------------------------------------------------------- upload --- */

const SIITE_BRIDGE_UPLOAD_VIDEO_MAX = 104857600;  // 100 MB, only reachable in chunks
const SIITE_BRIDGE_CHUNK_MAX        = 8388608;    // one decoded chunk: 8 MB

function siite_bridge_mime_for( $ext ) {
	foreach ( SIITE_BRIDGE_UPLOAD_MIME as $exts => $type ) {
		if ( in_array( $ext, explode( '|', $exts ), true ) ) { return $type; }
	}
	return null;
}

function siite_bridge_ext_for( $mime ) {
	foreach ( SIITE_BRIDGE_UPLOAD_MIME as $exts => $type ) {
		if ( $type === $mime ) { return explode( '|', $exts )[0]; }
	}
	return null;
}

function siite_bridge_upload_exts() {
	return array_map( function ( $e ) { return explode( '|', $e )[0]; }, array_keys( SIITE_BRIDGE_UPLOAD_MIME ) );
}

/** One file in one call: base64 "data" in a JSON body, up to 20 MB. */
function siite_bridge_upload( $req ) {
	$body = (array) $req->get_json_params();
	$b64  = (string) ( $body['data'] ?? '' );
	if ( (string) ( $body['filename'] ?? '' ) === '' || $b64 === '' ) {
		return new WP_Error( 'siite_upload_args',
			'Body must carry "filename" and base64 "data"', [ 'status' => 400 ] );
	}
	$data = base64_decode( $b64, true );
	if ( $data === false ) {
		return new WP_Error( 'siite_upload_data', 'data is not valid base64', [ 'status' => 400 ] );
	}
	return siite_bridge_store_file( (string) $body['filename'], $data, $body );
}

/**
 * The same file, in pieces.
 *
 * A base64 JSON body is a third bigger than the file, and a host's
 * post_max_size is often 8-32 MB — so a hero video could not go through the
 * bridge at all. PowerCurve's three hero MP4s (17, 7 and 9 MB) went to
 * wp/v2/media with an administrator password instead. Chunks keep every
 * request small; the pieces are joined in a folder under uploads that denies
 * direct access, and the joined file goes through the same checks as /upload.
 *
 * Start with index 0 and a filename; the answer carries an upload_id for the
 * rest. Send "final": true with the last chunk.
 */
function siite_bridge_upload_chunk( $req ) {
	$b     = (array) $req->get_json_params();
	$index = isset( $b['index'] ) ? (int) $b['index'] : -1;
	$chunk = base64_decode( (string) ( $b['data'] ?? '' ), true );
	if ( $index < 0 || $chunk === false || $chunk === '' ) {
		return new WP_Error( 'siite_chunk_args', 'Send "index" and base64 "data"', [ 'status' => 400 ] );
	}
	if ( strlen( $chunk ) > SIITE_BRIDGE_CHUNK_MAX ) {
		return new WP_Error( 'siite_chunk_size', 'A chunk is at most 8 MB', [ 'status' => 413 ] );
	}
	$up  = wp_upload_dir( null, false );
	$dir = trailingslashit( $up['basedir'] ) . 'siite-bridge-tmp';
	if ( ! is_dir( $dir ) ) {
		wp_mkdir_p( $dir );
		@file_put_contents( $dir . '/index.php', "<?php // Silence.\n" );
		@file_put_contents( $dir . '/.htaccess', "Require all denied\nDeny from all\n" );
	}

	if ( $index === 0 ) {
		foreach ( (array) glob( $dir . '/*.part' ) as $old ) {
			if ( is_string( $old ) && @filemtime( $old ) < time() - HOUR_IN_SECONDS ) { @unlink( $old ); }
		}
		$filename = sanitize_file_name( (string) ( $b['filename'] ?? '' ) );
		if ( $filename === '' ) {
			return new WP_Error( 'siite_chunk_args', 'The first chunk carries "filename"', [ 'status' => 400 ] );
		}
		if ( ! siite_bridge_mime_for( strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) ) ) {
			return new WP_Error( 'siite_upload_type', 'Not on the allowlist. Allowed: '
				. implode( ', ', siite_bridge_upload_exts() ) . '.', [ 'status' => 415 ] );
		}
		$id    = strtolower( wp_generate_password( 24, false ) );
		$state = [ 'filename' => $filename, 'next' => 0, 'bytes' => 0, 'user' => get_current_user_id() ];
	} else {
		$id    = preg_replace( '/[^a-z0-9]/', '', strtolower( (string) ( $b['upload_id'] ?? '' ) ) );
		$state = $id ? get_transient( 'siite_bridge_up_' . $id ) : false;
		if ( ! is_array( $state ) ) {
			return new WP_Error( 'siite_chunk_unknown', 'Unknown or expired upload_id — start again with index 0',
				[ 'status' => 404 ] );
		}
		if ( (int) $state['user'] !== get_current_user_id() ) {
			return new WP_Error( 'siite_chunk_owner', 'That upload belongs to another account', [ 'status' => 403 ] );
		}
	}
	if ( $index !== (int) $state['next'] ) {
		return new WP_Error( 'siite_chunk_order', "Expected chunk {$state['next']}, got $index",
			[ 'status' => 409, 'next' => (int) $state['next'], 'upload_id' => $id ] );
	}
	$path = $dir . '/' . $id . '.part';
	if ( $state['bytes'] + strlen( $chunk ) > SIITE_BRIDGE_UPLOAD_VIDEO_MAX ) {
		@unlink( $path );
		delete_transient( 'siite_bridge_up_' . $id );
		return new WP_Error( 'siite_upload_size', 'File is larger than 100 MB', [ 'status' => 413 ] );
	}
	if ( file_put_contents( $path, $chunk, FILE_APPEND | LOCK_EX ) === false ) {
		return new WP_Error( 'siite_chunk_write', 'Could not write the chunk', [ 'status' => 500 ] );
	}
	$state['next']++;
	$state['bytes'] += strlen( $chunk );

	if ( empty( $b['final'] ) ) {
		set_transient( 'siite_bridge_up_' . $id, $state, HOUR_IN_SECONDS );
		return [ 'upload_id' => $id, 'next' => $state['next'], 'bytes' => $state['bytes'], 'done' => false ];
	}
	$data = (string) file_get_contents( $path );
	@unlink( $path );
	delete_transient( 'siite_bridge_up_' . $id );
	$res = siite_bridge_store_file( $state['filename'], $data, $b );
	if ( is_wp_error( $res ) ) { return $res; }
	return array_merge( $res, [ 'upload_id' => $id, 'chunks' => $state['next'], 'done' => true ] );
}

/**
 * Checks and stores one file. Shared by /upload and /upload-chunk.
 *
 * SVG is accepted only through Elementor's own sanitiser — Elementor inlines an
 * SVG icon's markup into the page, so an unsanitised file is a script on every
 * page that shows the icon. No sanitiser, no SVG.
 *
 * "fix_extension": true stores an image under the extension its bytes have. A
 * repo full of .png files that are really JPEG is common, and refusing them
 * one by one helps nobody; anything that is not an image still has to match.
 */
function siite_bridge_store_file( $filename, $data, $body ) {
	$filename = sanitize_file_name( (string) $filename );
	$ext      = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
	$mime     = siite_bridge_mime_for( $ext );
	if ( ! $mime ) {
		return new WP_Error( 'siite_upload_type',
			"'.$ext' is not on the allowlist. Allowed: " . implode( ', ', siite_bridge_upload_exts() ) . '.',
			[ 'status' => 415 ] );
	}
	$max = strpos( $mime, 'video/' ) === 0 ? SIITE_BRIDGE_UPLOAD_VIDEO_MAX : SIITE_BRIDGE_UPLOAD_MAX;
	if ( strlen( $data ) > $max ) {
		return new WP_Error( 'siite_upload_size',
			'File is larger than ' . ( $max / 1048576 ) . ' MB', [ 'status' => 413 ] );
	}

	$renamed   = null;
	$sanitised = false;
	if ( $mime === 'image/svg+xml' ) {
		if ( ! class_exists( '\Elementor\Core\Utils\Svg\Svg_Sanitizer' ) ) {
			return new WP_Error( 'siite_upload_svg_unsafe',
				"SVG needs Elementor's own sanitiser (Elementor 3.16 or newer), and it is not available "
				. 'here, so the file was refused rather than stored unchecked.', [ 'status' => 415 ] );
		}
		$clean = ( new \Elementor\Core\Utils\Svg\Svg_Sanitizer() )->sanitize( $data );
		if ( ! is_string( $clean ) || $clean === '' ) {
			return new WP_Error( 'siite_upload_svg_invalid', 'The SVG could not be parsed and sanitised',
				[ 'status' => 415 ] );
		}
		$data      = $clean;
		$sanitised = true;
	} elseif ( function_exists( 'finfo_open' ) ) {
		// What the bytes actually are, not what the name claims.
		$fi   = finfo_open( FILEINFO_MIME_TYPE );
		$real = finfo_buffer( $fi, $data );
		finfo_close( $fi );
		if ( $real && $real !== $mime && ! ( $mime === 'image/jpeg' && $real === 'image/jpg' ) ) {
			$real_ext = siite_bridge_ext_for( $real );
			if ( ! empty( $body['fix_extension'] ) && $real_ext
				&& strpos( $real, 'image/' ) === 0 && strpos( $mime, 'image/' ) === 0 ) {
				$renamed  = $filename;
				$filename = pathinfo( $filename, PATHINFO_FILENAME ) . '.' . $real_ext;
				$mime     = $real;
			} else {
				return new WP_Error( 'siite_upload_mismatch',
					"The file is $real, not $mime as the name says."
					. ( $real_ext ? " Name it .$real_ext, or send \"fix_extension\": true." : '' ),
					[ 'status' => 415, 'real' => $real ] );
			}
		}
	}

	if ( ! empty( $body['dry_run'] ) ) {
		return [ 'uploaded' => false, 'why' => 'dry-run', 'filename' => $filename,
				 'mime' => $mime, 'bytes' => strlen( $data ), 'renamed_from' => $renamed ];
	}

	// The capability, for this call only.
	$grant = function ( $caps, $cap, $user_id, $args ) {
		if ( in_array( 'upload_files', (array) $cap, true ) ) { $caps['upload_files'] = true; }
		return $caps;
	};
	// WordPress's own type check does not know SVG; the sanitiser above does.
	$svg_ok = function ( $types, $file, $name ) use ( $mime ) {
		if ( $mime === 'image/svg+xml' && empty( $types['type'] )
			&& strtolower( pathinfo( (string) $name, PATHINFO_EXTENSION ) ) === 'svg' ) {
			return [ 'ext' => 'svg', 'type' => 'image/svg+xml', 'proper_filename' => false ];
		}
		return $types;
	};
	add_filter( 'user_has_cap', $grant, PHP_INT_MAX, 4 );
	add_filter( 'wp_check_filetype_and_ext', $svg_ok, PHP_INT_MAX, 3 );
	try {
		// Each file on its own check (1.14.4): on sandspedition.dk another
		// plugin had loaded file.php but not image.php, so the old single
		// check skipped all three and wp_generate_attachment_metadata() was a
		// fatal error — attachment created, no sizes, the request a 500.
		if ( ! function_exists( 'wp_handle_sideload' ) ) { require_once ABSPATH . 'wp-admin/includes/file.php'; }
		if ( ! function_exists( 'media_handle_sideload' ) ) { require_once ABSPATH . 'wp-admin/includes/media.php'; }
		if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) { require_once ABSPATH . 'wp-admin/includes/image.php'; }
		$tmp = wp_tempnam( $filename );
		if ( ! $tmp || file_put_contents( $tmp, $data ) === false ) {
			return new WP_Error( 'siite_upload_tmp', 'Could not write a temporary file',
				[ 'status' => 500 ] );
		}
		// By reference: wp_handle_sideload() takes $file as &$file and unsets
		// the temp path as it moves it, so a literal array is a fatal error.
		$file = [ 'name' => $filename, 'type' => $mime, 'tmp_name' => $tmp,
				  'error' => 0, 'size' => strlen( $data ) ];
		$sideload = wp_handle_sideload( $file,
			[ 'test_form' => false, 'mimes' => SIITE_BRIDGE_UPLOAD_MIME ] );
		if ( ! empty( $sideload['error'] ) ) {
			@unlink( $tmp );
			return new WP_Error( 'siite_upload_failed', $sideload['error'], [ 'status' => 500 ] );
		}

		$id = wp_insert_attachment( [
			'post_mime_type' => $sideload['type'],
			'post_title'     => sanitize_text_field( (string) ( $body['title'] ?? pathinfo( $filename, PATHINFO_FILENAME ) ) ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		], $sideload['file'], 0, true );
		if ( is_wp_error( $id ) ) { return $id; }

		wp_update_attachment_metadata( $id,
			wp_generate_attachment_metadata( $id, $sideload['file'] ) );
		if ( ! empty( $body['alt'] ) ) {
			update_post_meta( $id, '_wp_attachment_image_alt',
				sanitize_text_field( (string) $body['alt'] ) );
		}
	} finally {
		remove_filter( 'user_has_cap', $grant, PHP_INT_MAX );
		remove_filter( 'wp_check_filetype_and_ext', $svg_ok, PHP_INT_MAX );
	}

	siite_bridge_ledger_add( [ 'post' => (int) $id, 'route' => 'upload', 'created' => [],
							   'note' => "uploaded $filename" ] );

	$url = wp_get_attachment_url( $id );
	return [
		'uploaded'     => true,
		'id'           => (int) $id,
		'url'          => $url,
		'filename'     => $url ? basename( $url ) : $filename,
		'mime'         => $sideload['type'],
		'bytes'        => strlen( $data ),
		'renamed_from' => $renamed,
		'sanitised'    => $sanitised,
		// Ready to drop straight into an Elementor image control.
		'set'          => [ 'id' => (int) $id, 'url' => $url ],
	];
}

/* -------------------------------------------------------------- replace --- */

/**
 * Write a whole element tree to one document.
 *
 * A page that was not built with Elementor gets the three meta keys that make
 * it one. Without them the tree is stored, reads back correctly, and never
 * renders — PowerCurve: "wrote 15 sections", and an empty page.
 */
function siite_bridge_replace( $req ) {
	$id   = (int) $req['id'];
	$tree = $req->get_json_params()['data'] ?? null;
	if ( ! is_array( $tree ) || ! $tree ) {
		return new WP_Error( 'siite_bad_tree', 'Body must carry a non-empty "data" array', [ 'status' => 400 ] );
	}
	$stamp = siite_bridge_backup( $id );
	$made  = siite_bridge_make_elementor( $id );
	$wrote = siite_bridge_write_data( $id, $tree );
	if ( is_wp_error( $wrote ) ) { return $wrote; }
	if ( ! $wrote['ok'] ) {
		siite_bridge_restore_stamp( $id, $stamp );
		return new WP_Error( 'siite_verify_failed', 'Readback mismatch; the backup was restored', [ 'status' => 500 ] );
	}
	return [ 'id' => $id, 'written' => true, 'backup' => $stamp,
			 'kept_code' => $wrote['kept_code'], 'made_elementor' => $made,
			 'missing_media' => siite_bridge_missing_media( $tree ),
			 'caches' => siite_bridge_flush( $id ) ];
}

/** Mark a page or post as an Elementor document, if it is not one yet. */
function siite_bridge_make_elementor( $id ) {
	$post = get_post( $id );
	if ( ! $post || get_post_meta( $id, '_elementor_edit_mode', true ) === 'builder' ) { return false; }
	if ( $post->post_type === 'elementor_library' ) {
		update_post_meta( $id, '_elementor_edit_mode', 'builder' );
		return true;
	}
	$types = [ 'page' => 'wp-page', 'post' => 'wp-post' ];
	if ( ! isset( $types[ $post->post_type ] ) ) { return false; }
	update_post_meta( $id, '_elementor_edit_mode', 'builder' );
	if ( ! get_post_meta( $id, '_elementor_template_type', true ) ) {
		update_post_meta( $id, '_elementor_template_type', $types[ $post->post_type ] );
	}
	if ( defined( 'ELEMENTOR_VERSION' ) ) { update_post_meta( $id, '_elementor_version', ELEMENTOR_VERSION ); }
	return true;
}

/**
 * Media ids in a tree that are not attachments on THIS site.
 *
 * Elementor looks an image or an SVG icon up by attachment id. A tree built
 * against one site and written to another stores fine and renders an empty
 * circle — PowerCurve's live icons pointed at the local ids 186-207.
 */
function siite_bridge_missing_media( $tree, $limit = 25 ) {
	$missing = [];
	$seen    = [];
	$walk    = function ( $node ) use ( &$walk, &$missing, &$seen, $limit ) {
		if ( ! is_array( $node ) || count( $missing ) >= $limit ) { return; }
		if ( isset( $node['id'], $node['url'] ) && is_string( $node['url'] ) && $node['url'] !== ''
			&& ( is_int( $node['id'] ) || ( is_string( $node['id'] ) && ctype_digit( $node['id'] ) ) )
			&& (int) $node['id'] > 0 ) {
			$aid = (int) $node['id'];
			if ( ! isset( $seen[ $aid ] ) ) {
				$seen[ $aid ] = true;
				$p = get_post( $aid );
				if ( ! $p || $p->post_type !== 'attachment' ) {
					$missing[] = [ 'id' => $aid, 'url' => $node['url'] ];
				}
			}
		}
		foreach ( $node as $child ) {
			if ( is_array( $child ) ) { $walk( $child ); }
		}
	};
	$walk( $tree );
	return $missing;
}

/* ================================================================ 1.14.0 ===
 *
 * Bridge 1.14.0, 15 September 2026. Measured before it was written:
 *
 * - Every write took a local copy of the whole site first, one HTTP call per
 *   document. On PowerCurve (60 documents) that was ~21 seconds before each
 *   change. /export hands the documents over in pages of up to 50.
 * - Real requests on the request board include "hide this subpage", "don't
 *   show it on Google" and moving an old address to a new one. None of those
 *   were reachable without wp-admin. /status, /seo and /redirects are.
 */

/* --------------------------------------------------------------- export --- */

/**
 * GET /export?offset=0&limit=25 — the site's Elementor documents with their
 * trees, in pages. The client stitches the pages into its local snapshot.
 *
 * Its own id query rather than siite_bridge_inventory(), which flattens every
 * tree to count widgets and would do the whole site's work on every page.
 */
function siite_bridge_export( $req ) {
	global $wpdb;
	$offset = max( 0, (int) $req->get_param( 'offset' ) );
	$limit  = (int) $req->get_param( 'limit' );
	$limit  = $limit > 0 ? min( 50, $limit ) : 25;

	$ids = array_map( 'intval', $wpdb->get_col(
		"SELECT p.ID FROM {$wpdb->postmeta} m
		   JOIN {$wpdb->posts} p ON p.ID = m.post_id
		  WHERE m.meta_key = '_elementor_data'
		    AND p.post_status IN ('publish','draft','private','pending')
		  ORDER BY p.ID"
	) );
	$ids   = array_values( array_unique( $ids ) );
	$total = count( $ids );

	$docs = [];
	$skipped = [];
	foreach ( array_slice( $ids, $offset, $limit ) as $id ) {
		$tree = siite_bridge_tree( $id );
		if ( ! $tree ) {
			$skipped[] = [ 'id' => $id, 'why' => 'no-data' ];
			continue;
		}
		if ( ! current_user_can( 'edit_post', $id ) ) {
			$skipped[] = [ 'id' => $id, 'why' => 'forbidden' ];
			continue;
		}
		$docs[] = [
			'id'            => $id,
			'type'          => get_post_type( $id ),
			'status'        => get_post_status( $id ),
			'title'         => get_the_title( $id ),
			'url'           => get_permalink( $id ),
			'modified'      => get_post_field( 'post_modified_gmt', $id ),
			'data'          => $tree,
			'page_settings' => get_post_meta( $id, '_elementor_page_settings', true ),
		];
	}
	$next = $offset + $limit;
	return [
		'total'   => $total,
		'offset'  => $offset,
		'limit'   => $limit,
		'docs'    => $docs,
		'skipped' => $skipped,
		'next'    => $next < $total ? $next : null,
	];
}

/* --------------------------------------------------------------- status --- */

/**
 * POST /status/<id> { "status": "draft" | "private" | "publish", "dry_run" }
 *
 * "Gem underside væk" is an ordinary request, and until now it was a trip to
 * wp-admin. Only pages and posts: a template's status decides whether it is
 * applied site-wide, which is a different question.
 *
 * The front page, the posts page and the privacy policy page are refused unless
 * "allow_special": true — hiding the front page takes the whole site down.
 * The answer names the menus that link to the page, because WordPress quietly
 * drops a menu item whose page is no longer public, and the published children,
 * whose addresses still run through this page.
 */
function siite_bridge_status_set( $req ) {
	$id   = (int) $req['id'];
	$post = get_post( $id );
	$b    = (array) $req->get_json_params();
	$want = (string) ( $b['status'] ?? '' );

	if ( ! in_array( $want, [ 'publish', 'draft', 'private' ], true ) ) {
		return new WP_Error( 'siite_status_value', 'status is "publish", "draft" or "private"', [ 'status' => 400 ] );
	}
	if ( ! in_array( $post->post_type, [ 'page', 'post' ], true ) ) {
		return new WP_Error( 'siite_status_type',
			"Post $id is a {$post->post_type}. Only pages and posts are hidden or published here.",
			[ 'status' => 422 ] );
	}
	if ( $want === 'publish' && ! current_user_can( 'publish_post', $id ) ) {
		return siite_bridge_forbidden( $post );
	}

	$was = $post->post_status;
	$url = get_permalink( $id );
	$special = [];
	if ( (int) get_option( 'page_on_front' ) === $id )              { $special[] = 'front page'; }
	if ( (int) get_option( 'page_for_posts' ) === $id )             { $special[] = 'posts page'; }
	if ( (int) get_option( 'wp_page_for_privacy_policy' ) === $id ) { $special[] = 'privacy policy page'; }
	if ( $want !== 'publish' && $special && empty( $b['allow_special'] ) ) {
		return new WP_Error( 'siite_status_special',
			"Post $id is the site's " . implode( ' and ', $special ) . '. Hiding it breaks the site for '
			. 'every visitor. Send "allow_special": true if that is really intended.',
			[ 'status' => 409, 'special' => $special ] );
	}

	$menus = [];
	$items = get_posts( [
		'post_type'   => 'nav_menu_item',
		'numberposts' => 50,
		'post_status' => 'any',
		'meta_query'  => [
			[ 'key' => '_menu_item_object_id', 'value' => (string) $id ],
			[ 'key' => '_menu_item_type', 'value' => 'post_type' ],
		],
	] );
	foreach ( $items as $item ) {
		foreach ( (array) wp_get_object_terms( $item->ID, 'nav_menu' ) as $term ) {
			if ( is_object( $term ) ) {
				$menus[] = [ 'menu' => (int) $term->term_id, 'name' => $term->name, 'item' => (int) $item->ID ];
			}
		}
	}
	$children = array_map( function ( $c ) {
		return [ 'id' => (int) $c->ID, 'title' => $c->post_title, 'url' => get_permalink( $c ) ];
	}, get_posts( [ 'post_type' => $post->post_type, 'post_parent' => $id, 'post_status' => 'publish',
	                'numberposts' => 50 ] ) );

	$out = [ 'post' => $id, 'title' => $post->post_title, 'was' => $was, 'url' => $url,
	         'menus' => $menus, 'children' => $children, 'special' => $special ];
	if ( $was === $want ) {
		return $out + [ 'changed' => false, 'why' => 'no-change', 'now' => $was ];
	}
	if ( ! empty( $b['dry_run'] ) ) {
		return $out + [ 'changed' => false, 'why' => 'dry-run', 'would' => $want ];
	}

	$done = wp_update_post( [ 'ID' => $id, 'post_status' => $want ], true );
	if ( is_wp_error( $done ) ) { return $done; }
	clean_post_cache( $id );
	$now = get_post_status( $id );

	siite_bridge_ledger_add( [ 'post' => $id, 'route' => 'status', 'created' => [],
	                           'note' => "status $was -> $now" ] );
	return $out + [ 'changed' => true, 'now' => $now, 'verified' => $now === $want,
	                'url_now' => get_permalink( $id ), 'caches' => siite_bridge_flush( 0 ) ];
}

/* ------------------------------------------------------------------ seo --- */

/**
 * GET/POST /seo/<id> — the page's search title, meta description and noindex,
 * written where the site's own SEO plugin reads them.
 *
 * Measured across 626 client sites on 15 September 2026: SEOPress on 375,
 * RankMath on 205, Yoast on 21. On a site with none of them only noindex can be
 * set, through WordPress's own wp_robots filter below.
 */
const SIITE_BRIDGE_SEO_KEYS = [
	'seopress' => [ 'title' => '_seopress_titles_title', 'description' => '_seopress_titles_desc' ],
	'rankmath' => [ 'title' => 'rank_math_title',        'description' => 'rank_math_description' ],
	'yoast'    => [ 'title' => '_yoast_wpseo_title',     'description' => '_yoast_wpseo_metadesc' ],
];

function siite_bridge_seo_plugins() {
	$have = [];
	if ( defined( 'SEOPRESS_VERSION' ) )  { $have[] = 'seopress'; }
	if ( defined( 'RANK_MATH_VERSION' ) ) { $have[] = 'rankmath'; }
	if ( defined( 'WPSEO_VERSION' ) )     { $have[] = 'yoast'; }
	return $have;
}

function siite_bridge_seo_read( $id, $plugin ) {
	$keys = SIITE_BRIDGE_SEO_KEYS[ $plugin ] ?? null;
	switch ( $plugin ) {
		case 'seopress': $noindex = get_post_meta( $id, '_seopress_robots_index', true ) === 'yes'; break;
		case 'rankmath': $noindex = in_array( 'noindex', (array) get_post_meta( $id, 'rank_math_robots', true ), true ); break;
		case 'yoast':    $noindex = (string) get_post_meta( $id, '_yoast_wpseo_meta-robots-noindex', true ) === '1'; break;
		default:         $noindex = get_post_meta( $id, '_siite_noindex', true ) === '1';
	}
	return [
		'title'       => $keys ? (string) get_post_meta( $id, $keys['title'], true ) : null,
		'description' => $keys ? (string) get_post_meta( $id, $keys['description'], true ) : null,
		'noindex'     => $noindex,
	];
}

/**
 * Why the SEO plugin prints nothing, when that can be known from here.
 *
 * RankMath loads no front end at all until the site is connected to a RankMath
 * account or registration is skipped (Helper::is_invalid_registration()).
 * Measured in the sandbox 15 September 2026: the meta was stored and read back,
 * and the page's <head> had no RankMath title, description or robots. A site in
 * that state has had no RankMath SEO since it was installed.
 */
function siite_bridge_seo_warning( $plugin ) {
	if ( $plugin === 'rankmath' && class_exists( '\RankMath\Helper' )
		&& method_exists( '\RankMath\Helper', 'is_invalid_registration' )
		&& \RankMath\Helper::is_invalid_registration() ) {
		return 'RankMath is not registered on this site (no account connected, registration not '
			. 'skipped), so it prints no SEO tags at all. Values are stored but not shown until '
			. 'someone completes or skips the RankMath setup in wp-admin.';
	}
	return null;
}

function siite_bridge_seo_get( $req ) {
	$id   = (int) $req['id'];
	$have = siite_bridge_seo_plugins();
	$plugin = $have[0] ?? 'bridge';
	return [ 'post' => $id, 'title_of_page' => get_the_title( $id ), 'url' => get_permalink( $id ),
	         'plugin' => $plugin, 'plugins' => $have, 'warning' => siite_bridge_seo_warning( $plugin ) ]
	       + siite_bridge_seo_read( $id, $plugin );
}

function siite_bridge_seo_set( $req ) {
	$id   = (int) $req['id'];
	$b    = (array) $req->get_json_params();
	$have = siite_bridge_seo_plugins();
	$plugin = $have[0] ?? 'bridge';
	if ( ! empty( $b['plugin'] ) ) {
		if ( ! in_array( $b['plugin'], $have, true ) ) {
			return new WP_Error( 'siite_seo_plugin', "{$b['plugin']} is not active here. Active: "
				. ( $have ? implode( ', ', $have ) : 'none' ), [ 'status' => 409 ] );
		}
		$plugin = $b['plugin'];
	}
	$want = array_intersect_key( $b, array_flip( [ 'title', 'description', 'noindex' ] ) );
	if ( ! $want ) {
		return new WP_Error( 'siite_nothing', 'Send title, description and/or noindex', [ 'status' => 400 ] );
	}
	if ( $plugin === 'bridge' && ( isset( $want['title'] ) || isset( $want['description'] ) ) ) {
		return new WP_Error( 'siite_no_seo_plugin',
			'No SEO plugin (SEOPress, RankMath, Yoast) is active, so there is nowhere a search title or '
			. 'description would be read from. noindex can still be set.', [ 'status' => 409 ] );
	}
	foreach ( [ 'title', 'description' ] as $k ) {
		if ( isset( $want[ $k ] ) ) {
			if ( ! is_string( $want[ $k ] ) || mb_strlen( $want[ $k ] ) > 400 ) {
				return new WP_Error( 'siite_seo_value', "$k is a string of at most 400 characters", [ 'status' => 400 ] );
			}
			$want[ $k ] = trim( wp_strip_all_tags( $want[ $k ] ) );
		}
	}
	if ( isset( $want['noindex'] ) ) { $want['noindex'] = (bool) $want['noindex']; }

	$was = siite_bridge_seo_read( $id, $plugin );
	$would = array_merge( $was, $want );
	$out = [ 'post' => $id, 'plugin' => $plugin, 'was' => $was, 'url' => get_permalink( $id ),
	         'warning' => siite_bridge_seo_warning( $plugin ) ];
	if ( $would == $was ) {
		return $out + [ 'changed' => false, 'why' => 'no-change', 'now' => $was ];
	}
	if ( ! empty( $b['dry_run'] ) ) {
		return $out + [ 'changed' => false, 'why' => 'dry-run', 'would' => $would ];
	}

	$keys = SIITE_BRIDGE_SEO_KEYS[ $plugin ] ?? null;
	foreach ( [ 'title', 'description' ] as $k ) {
		if ( ! isset( $want[ $k ] ) || ! $keys ) { continue; }
		if ( $want[ $k ] === '' ) {
			delete_post_meta( $id, $keys[ $k ] );       // back to the plugin's own default
		} else {
			update_post_meta( $id, $keys[ $k ], wp_slash( $want[ $k ] ) );
		}
	}
	if ( isset( $want['noindex'] ) ) {
		$on = $want['noindex'];
		switch ( $plugin ) {
			case 'seopress':
				$on ? update_post_meta( $id, '_seopress_robots_index', 'yes' ) : delete_post_meta( $id, '_seopress_robots_index' );
				break;
			case 'rankmath':
				// RankMath keeps "index" and "noindex" in the same array and treats
				// them as opposites; leaving both in gives an undefined result.
				$robots = array_values( array_filter( (array) get_post_meta( $id, 'rank_math_robots', true ) ) );
				$robots = array_values( array_diff( $robots, [ 'index', 'noindex' ] ) );
				$robots[] = $on ? 'noindex' : 'index';
				update_post_meta( $id, 'rank_math_robots', $robots );
				break;
			case 'yoast':
				$on ? update_post_meta( $id, '_yoast_wpseo_meta-robots-noindex', '1' )
				    : delete_post_meta( $id, '_yoast_wpseo_meta-robots-noindex' );
				break;
			default:
				$on ? update_post_meta( $id, '_siite_noindex', '1' ) : delete_post_meta( $id, '_siite_noindex' );
		}
	}

	$now = siite_bridge_seo_read( $id, $plugin );
	siite_bridge_ledger_add( [ 'post' => $id, 'route' => 'seo', 'created' => [],
	                           'note' => "seo ($plugin) " . wp_json_encode( $was ) . ' -> ' . wp_json_encode( $now ) ] );
	return $out + [ 'changed' => true, 'now' => $now, 'verified' => $now == $would,
	                'caches' => siite_bridge_flush( $id ) ];
}

/** noindex on a site without an SEO plugin. Only ever set through /seo. */
add_filter( 'wp_robots', function ( $robots ) {
	if ( is_singular() && get_post_meta( get_queried_object_id(), '_siite_noindex', true ) === '1' ) {
		unset( $robots['index'] );
		$robots['noindex'] = true;
	}
	return $robots;
} );

/* ------------------------------------------------------------ redirects --- */

/**
 * GET/POST /redirects — 301s owned by the bridge, stored in one option.
 *
 * Not the SEO plugin's redirect module: RankMath and SEOPress each keep theirs
 * in a different shape, some only in the paid version, and a hidden page needs
 * its old address to go somewhere on every site. The list is visible through
 * GET, and GET also names any redirect plugin already on the site, so two
 * systems are never fighting over one address without it being said.
 */
const SIITE_BRIDGE_REDIRECTS     = 'siite_bridge_redirects';
const SIITE_BRIDGE_REDIRECTS_MAX = 500;

/** "/Om-os/?x=1#y" and "https://site.dk/om-os" both become "/om-os". '' = not a path we redirect. */
function siite_bridge_redirect_path( $raw ) {
	$path = (string) wp_parse_url( (string) $raw, PHP_URL_PATH );
	$home = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( $home !== '' && strpos( $path, $home ) === 0 ) { $path = substr( $path, strlen( $home ) ); }
	$path = '/' . trim( strtolower( rawurldecode( $path ) ), '/' );
	return $path;
}

function siite_bridge_redirects_all() {
	$list = get_option( SIITE_BRIDGE_REDIRECTS );
	return is_array( $list ) ? array_values( $list ) : [];
}

add_action( 'template_redirect', function () {
	$list = siite_bridge_redirects_all();
	if ( ! $list ) { return; }
	$path = siite_bridge_redirect_path( $_SERVER['REQUEST_URI'] ?? '' );
	foreach ( $list as $r ) {
		if ( ( $r['from'] ?? '' ) !== $path ) { continue; }
		$to = (string) $r['to'];
		if ( strpos( $to, '/' ) === 0 ) { $to = home_url( $to ); }
		$query = (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_QUERY );
		if ( $query !== '' && strpos( $to, '?' ) === false ) { $to .= '?' . $query; }
		wp_redirect( $to, (int) ( $r['code'] ?? 301 ), 'Siite Bridge' );
		exit;
	}
}, 0 );

function siite_bridge_redirect_others() {
	$other = [];
	if ( defined( 'REDIRECTION_VERSION' ) ) { $other[] = 'redirection'; }
	if ( defined( 'RANK_MATH_VERSION' ) && class_exists( '\RankMath\Helper' )
		&& method_exists( '\RankMath\Helper', 'is_module_active' )
		&& \RankMath\Helper::is_module_active( 'redirections' ) ) {
		$other[] = 'rankmath-redirections';
	}
	if ( defined( 'SEOPRESS_VERSION' ) ) {
		global $wpdb;
		$n = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta}
		                             WHERE meta_key = '_seopress_redirections_enabled' AND meta_value = 'yes'" );
		if ( $n ) { $other[] = "seopress-per-page ($n)"; }
	}
	return $other;
}

function siite_bridge_redirects_get() {
	$list = siite_bridge_redirects_all();
	return [ 'redirects' => $list, 'count' => count( $list ), 'other' => siite_bridge_redirect_others() ];
}

function siite_bridge_redirects_set( $req ) {
	$b    = (array) $req->get_json_params();
	$list = siite_bridge_redirects_all();
	$was  = $list;

	if ( isset( $b['remove'] ) ) {
		$from = siite_bridge_redirect_path( $b['remove'] );
		$left = array_values( array_filter( $list, function ( $r ) use ( $from ) { return $r['from'] !== $from; } ) );
		if ( count( $left ) === count( $list ) ) {
			return [ 'changed' => false, 'why' => 'not-found', 'from' => $from ];
		}
		if ( ! empty( $b['dry_run'] ) ) {
			return [ 'changed' => false, 'why' => 'dry-run', 'would_remove' => $from ];
		}
		update_option( SIITE_BRIDGE_REDIRECTS, $left, false );
		siite_bridge_ledger_add( [ 'post' => 0, 'route' => 'redirects', 'created' => [], 'note' => "redirect removed $from" ] );
		return [ 'changed' => true, 'removed' => $from, 'count' => count( $left ),
		         'verified' => count( siite_bridge_redirects_all() ) === count( $left ),
		         'caches' => siite_bridge_flush( 0 ) ];
	}

	$add = (array) ( $b['add'] ?? [] );
	$from = siite_bridge_redirect_path( $add['from'] ?? '' );
	$to_raw = trim( (string) ( $add['to'] ?? '' ) );
	$code = (int) ( $add['code'] ?? 301 );

	if ( ! isset( $add['from'] ) || $to_raw === '' ) {
		return new WP_Error( 'siite_redirect_args', 'Send "add": {"from": "/gammel/", "to": "/ny/"} or "remove": "/gammel/"',
			[ 'status' => 400 ] );
	}
	if ( $from === '/' ) {
		return new WP_Error( 'siite_redirect_front', 'The front page is never redirected.', [ 'status' => 422 ] );
	}
	if ( preg_match( '#^/(wp-admin|wp-login\.php|wp-json|wp-content|wp-includes|xmlrpc\.php)(/|$)#', $from ) ) {
		return new WP_Error( 'siite_redirect_reserved', "$from belongs to WordPress itself.", [ 'status' => 422 ] );
	}
	if ( ! in_array( $code, [ 301, 302 ], true ) ) {
		return new WP_Error( 'siite_redirect_code', 'code is 301 or 302', [ 'status' => 400 ] );
	}
	$external = false;
	if ( strpos( $to_raw, '/' ) === 0 ) {
		$to = '/' . ltrim( (string) wp_parse_url( $to_raw, PHP_URL_PATH ), '/' );
		$q  = (string) wp_parse_url( $to_raw, PHP_URL_QUERY );
		if ( $q !== '' ) { $to .= '?' . $q; }
	} elseif ( preg_match( '#^https?://#i', $to_raw ) ) {
		$host = strtolower( (string) wp_parse_url( $to_raw, PHP_URL_HOST ) );
		$mine = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		if ( $host === $mine ) {
			$to = '/' . ltrim( siite_bridge_redirect_path( $to_raw ), '/' );
			$q  = (string) wp_parse_url( $to_raw, PHP_URL_QUERY );
			if ( $q !== '' ) { $to .= '?' . $q; }
		} else {
			$to = esc_url_raw( $to_raw );
			$external = true;
		}
	} else {
		return new WP_Error( 'siite_redirect_target', '"to" is a path starting with / or a full https:// address',
			[ 'status' => 400 ] );
	}

	// A loop is a page that never loads. Follow the chain from the target.
	if ( ! $external ) {
		$by = [];
		foreach ( $list as $r ) { $by[ $r['from'] ] = $r['to']; }
		$by[ $from ] = $to;
		$seen = [];
		$at = $from;
		while ( isset( $by[ $at ] ) ) {
			if ( isset( $seen[ $at ] ) ) {
				return new WP_Error( 'siite_redirect_loop', "That makes a loop: " . implode( ' -> ', array_keys( $seen ) ) . " -> $at",
					[ 'status' => 409 ] );
			}
			$seen[ $at ] = true;
			$next = $by[ $at ];
			if ( preg_match( '#^https?://#i', $next ) ) { break; }
			$at = siite_bridge_redirect_path( $next );
		}
	}

	$replaced = null;
	$list = array_values( array_filter( $list, function ( $r ) use ( $from, &$replaced ) {
		if ( $r['from'] === $from ) { $replaced = $r; return false; }
		return true;
	} ) );
	if ( count( $list ) >= SIITE_BRIDGE_REDIRECTS_MAX ) {
		return new WP_Error( 'siite_redirect_full', 'At most 500 bridge redirects', [ 'status' => 413 ] );
	}

	$shadows = url_to_postid( home_url( $from . '/' ) );
	$entry = [ 'from' => $from, 'to' => $to, 'code' => $code, 'external' => $external,
	           'stamp' => gmdate( 'Ymd-His' ), 'actor' => wp_get_current_user()->user_login,
	           'note' => mb_substr( (string) ( $add['note'] ?? '' ), 0, 200 ) ];
	$out = [ 'redirect' => $entry, 'replaced' => $replaced,
	         'shadows' => $shadows ? [ 'post' => $shadows, 'title' => get_the_title( $shadows ),
	                                   'status' => get_post_status( $shadows ) ] : null ];
	if ( $replaced && $replaced['to'] === $to && (int) $replaced['code'] === $code ) {
		return $out + [ 'changed' => false, 'why' => 'no-change' ];
	}
	if ( ! empty( $b['dry_run'] ) ) {
		return $out + [ 'changed' => false, 'why' => 'dry-run' ];
	}
	$list[] = $entry;
	update_option( SIITE_BRIDGE_REDIRECTS, $list, false );
	$verified = in_array( $from, array_column( siite_bridge_redirects_all(), 'from' ), true );
	siite_bridge_ledger_add( [ 'post' => 0, 'route' => 'redirects', 'created' => [],
	                           'note' => "redirect $from -> $to ($code)" ] );
	return $out + [ 'changed' => true, 'verified' => $verified, 'count' => count( $list ),
	                'caches' => siite_bridge_flush( 0 ) ];
}

/* ------------------------------------------------------------------ cli --- */

/**
 * wp siite-bridge enroll [--login=<login>] [--email=<email>] [--app=<name>]
 *
 * --login, not --user: --user is wp-cli's own global flag for the account a
 * command runs as, so wp-cli consumes it before the command ever sees it and
 * answers "Invalid user ID, email or login".
 *
 * The Siite Bridge user and an application password, printed as one JSON line,
 * for a site where wp-cli is at hand (a local or dev WordPress). Client sites
 * are still set up by a person in wp-admin. PowerCurve's local password was
 * copied out of wp-cli output that PHP deprecation notices had polluted; one
 * JSON line cannot be misread that way.
 */
if ( defined( 'WP_CLI' ) && WP_CLI ) {
	WP_CLI::add_command( 'siite-bridge enroll', 'siite_bridge_cli_enroll', [
		'shortdesc' => 'Create the Siite Bridge user and an application password; print them as JSON.',
	] );
}

function siite_bridge_cli_enroll( $args, $assoc ) {
	$login = sanitize_user( (string) ( $assoc['login'] ?? 'siite-bridge' ), true );
	if ( $login === '' || $login === 'siite' ) {
		WP_CLI::error( "Pick another --login. 'siite' is the login that gets handed to clients, and the "
			. 'bridge needs an account nobody else logs into.' );
	}
	remove_role( SIITE_BRIDGE_ROLE );
	add_role( SIITE_BRIDGE_ROLE, 'Siite Bridge', siite_bridge_role_caps() );
	update_option( 'siite_bridge_role_ver', SIITE_BRIDGE_ROLE_VER, false );

	$user = get_user_by( 'login', $login );
	if ( $user && ! in_array( SIITE_BRIDGE_ROLE, (array) $user->roles, true ) ) {
		WP_CLI::error( "User '$login' exists with the role(s) " . implode( ', ', (array) $user->roles )
			. '. The bridge account must be dedicated; pick another --login.' );
	}
	if ( ! $user ) {
		$email = (string) ( $assoc['email'] ?? '' );
		if ( $email === '' ) {
			$host  = wp_parse_url( home_url(), PHP_URL_HOST ) ?: 'example.invalid';
			$email = $login . '@' . ( strpos( $host, '.' ) === false ? $host . '.invalid' : $host );
		}
		$uid = wp_insert_user( [ 'user_login' => $login, 'user_pass' => wp_generate_password( 32, true, true ),
								 'user_email' => $email, 'role' => SIITE_BRIDGE_ROLE,
								 'display_name' => 'Siite Bridge' ] );
		if ( is_wp_error( $uid ) ) { WP_CLI::error( $uid->get_error_message() ); }
		$user = get_user_by( 'id', $uid );
	}
	if ( ! class_exists( 'WP_Application_Passwords' ) ) {
		WP_CLI::error( 'Application Passwords are not available on this WordPress.' );
	}
	$made = WP_Application_Passwords::create_new_application_password( $user->ID,
		[ 'name' => (string) ( $assoc['app'] ?? 'claude' ) ] );
	if ( is_wp_error( $made ) ) { WP_CLI::error( $made->get_error_message() ); }
	WP_CLI::line( wp_json_encode( [
		'url'    => home_url(),
		'user'   => $login,
		'pass'   => $made[0],
		'role'   => SIITE_BRIDGE_ROLE,
		'bridge' => SIITE_BRIDGE_VERSION,
		'app_passwords_available' => function_exists( 'wp_is_application_passwords_available' )
			? wp_is_application_passwords_available() : true,
	] ) );
}
